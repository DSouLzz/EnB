"""
Earth & Beyond Drop Logger — Automatic Edition
OpenOffice/LibreOffice compatible. Microsoft Excel is NOT required.

NORMAL GAMEPLAY:
  No keys needed. Once calibrated, the logger follows target changes,
  zone/sector changes, and new loot automatically.

ONE-TIME / MAINTENANCE HOTKEYS:
  F5  Guided calibration (target -> loot -> zone)
  F6  Recalibrate target
  F7  Recalibrate loot
  F9  Recalibrate zone/sector
  F10 Toggle automatic logging
  F12 Quit

The program uses screen OCR only. It does not read EnB memory, inject code,
or intercept network traffic.
"""
from __future__ import annotations
import json, re, time, hashlib
from datetime import datetime
from pathlib import Path

import cv2
import mss
import numpy as np
import pytesseract
import pygetwindow as gw
import keyboard
from openpyxl import load_workbook

BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config.json"
CAPTURE_DIR = BASE / "captures"
CAPTURE_DIR.mkdir(exist_ok=True)

with CFG_PATH.open("r", encoding="utf-8") as f:
    cfg = json.load(f)

pytesseract.pytesseract.tesseract_cmd = cfg["ocr"]["tesseract_cmd"]

running = True
auto_enabled = bool(cfg["behavior"].get("automatic", True))

# Stable state
current_target = ""
current_target_cl = ""
current_zone = ""
last_target_seen_at = 0.0

candidate_target = ""
candidate_target_cl = ""
candidate_target_reads = 0

candidate_zone = ""
candidate_zone_reads = 0

candidate_loot_text = ""
candidate_loot_reads = 0
last_logged_loot_hash = ""
last_log_time = 0.0

def nowstr():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def save_config():
    CFG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

def find_window():
    needle = cfg["window_title_contains"].lower()
    wins = [
        w for w in gw.getAllWindows()
        if needle in (w.title or "").lower() and w.width > 0 and w.height > 0
    ]
    return wins[0] if wins else None

def grab(region):
    # mss() is the modern API; avoids the deprecated mss.mss warning.
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

def absolute_region(win, name):
    r = cfg["regions"].get(name)
    if not r:
        return None
    return {
        "left": int(win.left + r["left"]),
        "top": int(win.top + r["top"]),
        "width": max(1, int(r["width"])),
        "height": max(1, int(r["height"])),
    }

def prep(img, scale=2):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3, 3), 0)
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 31, 9
    )

def ocr(img, psm):
    txt = pytesseract.image_to_string(prep(img), config=f"--psm {psm}")
    return "\n".join(x.strip() for x in txt.splitlines() if x.strip())

def normalize_text(s):
    return re.sub(r"\s+", " ", s or "").strip(" |[]-:")

def parse_target(text):
    clean = normalize_text(text)
    if not clean:
        return "", ""

    cl = ""
    m = re.search(r"\b(?:CL|Combat\s*Level|Combat)\s*[:\-]?\s*(\d{1,3})\b", clean, re.I)
    if m:
        cl = m.group(1)
        clean = normalize_text(clean[:m.start()] + " " + clean[m.end():])

    # Remove common UI labels, but do not over-clean names.
    clean = re.sub(r"\b(?:Target|Hull|Shield)\b\s*:?", "", clean, flags=re.I)
    clean = normalize_text(clean)

    # Reject obvious non-target OCR.
    if len(clean) < 2 or len(clean) > 80:
        return "", cl
    return clean, cl

def parse_zone(text):
    clean = normalize_text(text)
    clean = re.sub(r"^(?:Sector|Zone|Location)\s*[:\-]\s*", "", clean, flags=re.I)
    # Reject obvious noise; sector names are normally short-ish text.
    if len(clean) < 2 or len(clean) > 80:
        return ""
    return clean

def parse_loot(text):
    rows = []
    seen = set()

    for raw in text.splitlines():
        line = normalize_text(raw)
        if len(line) < 2:
            continue

        # Ignore common UI-only strings.
        if re.search(
            r"\b(?:loot|cargo|close|take all|inventory|credits?|capacity|free space)\b",
            line, re.I
        ):
            continue

        qty = 1
        item = line

        m = re.match(r"^(\d+)\s*[xX]\s+(.+)$", line)
        if m:
            qty = int(m.group(1))
            item = m.group(2)
        else:
            m = re.match(r"^(.+?)\s+[xX]\s*(\d+)$", line)
            if m:
                item = m.group(1)
                qty = int(m.group(2))

        item = normalize_text(item)
        key = item.lower()

        if item and key not in seen:
            seen.add(key)
            rows.append((item[:120], qty))

    return rows

def calibrate(name, prompt):
    win = find_window()
    if not win:
        print("Earth & Beyond window not found. Start the game first.")
        return False

    whole = grab({
        "left": win.left, "top": win.top,
        "width": win.width, "height": win.height
    })

    x, y, w, h = cv2.selectROI(prompt, whole, False, False)
    cv2.destroyAllWindows()

    if w <= 0 or h <= 0:
        print(f"{name} calibration cancelled.")
        return False

    cfg["regions"][name] = {
        "left": int(x), "top": int(y),
        "width": int(w), "height": int(h)
    }
    save_config()
    print(f"Saved {name} region.")
    return True

def guided_calibration():
    print("")
    print("GUIDED CALIBRATION")
    print("1/3 Select only the mob/target name area.")
    if not calibrate("target", "1/3 Select TARGET / MOB NAME area, then press ENTER"):
        return

    print("2/3 Select only the list where corpse loot item names appear.")
    if not calibrate("loot", "2/3 Select LOOT ITEM LIST area, then press ENTER"):
        return

    print("3/3 Select the screen area that shows the current sector/zone name.")
    if not calibrate("zone", "3/3 Select ZONE / SECTOR NAME area, then press ENTER"):
        return

    print("")
    print("Calibration complete. Automatic logging is ON.")
    print("You should not need to press anything while playing.")

def calibration_complete():
    return all(cfg["regions"].get(x) for x in ("target", "loot", "zone"))

def save_capture(target_img, loot_img, zone_img, mob):
    if not cfg["behavior"].get("save_capture_on_log", True):
        return ""

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_mob = re.sub(r"[^A-Za-z0-9_-]+", "_", mob or "unknown")[:40]
    path = CAPTURE_DIR / f"{stamp}_{safe_mob}.png"

    imgs = [zone_img, target_img, loot_img]
    imgs = [i for i in imgs if i is not None]

    h = max(i.shape[0] for i in imgs)
    w = sum(i.shape[1] for i in imgs)
    canvas = np.zeros((h, w, 3), dtype=np.uint8)

    x = 0
    for img in imgs:
        canvas[:img.shape[0], x:x+img.shape[1]] = img
        x += img.shape[1]

    cv2.imwrite(str(path), canvas)
    return str(path)

def rebuild_summary(wb):
    ws_d = wb["Drops"]
    ws_k = wb["Kills"]
    ws_s = wb["Summary"]

    kills = {}
    for row in ws_k.iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        if mob:
            kills[mob] = kills.get(mob, 0) + 1

    agg = {}
    for row in ws_d.iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        item = str(row[4] or "").strip()
        try:
            qty = int(row[5] or 1)
        except Exception:
            qty = 1

        if mob and item:
            key = (mob, item)
            rec = agg.setdefault(key, {"events": 0, "qty": 0})
            rec["events"] += 1
            rec["qty"] += qty

    # Replace the generated summary area cleanly. The starter workbook has
    # merged instruction rows below row 2; writing to those MergedCell objects
    # raises "value is read-only" in openpyxl. Unmerge/remove that area first.
    for merged in list(ws_s.merged_cells.ranges):
        if merged.min_row >= 3:
            ws_s.unmerge_cells(str(merged))
    if ws_s.max_row >= 3:
        ws_s.delete_rows(3, ws_s.max_row - 2)

    for (mob, item), rec in sorted(agg.items(), key=lambda x: (x[0][0].lower(), x[0][1].lower())):
        kc = kills.get(mob, 0)
        pct = rec["events"] / kc if kc else 0
        ws_s.append([mob, item, rec["events"], kc, pct, rec["qty"], "Observed sample"])
        ws_s.cell(ws_s.max_row, 5).number_format = "0.0%"

def append_observation(kill_row, drop_rows):
    path = (BASE / cfg["excel_file"]).resolve()

    if not path.exists():
        print("ERROR: EnB_Drop_Database.xlsx is missing from the logger folder.")
        return False

    try:
        wb = load_workbook(path)
    except PermissionError:
        print("DATABASE IS OPEN. Close EnB_Drop_Database.xlsx in OpenOffice Calc.")
        return False

    try:
        wb["Kills"].append(kill_row)
        for row in drop_rows:
            wb["Drops"].append(row)
        rebuild_summary(wb)
        wb.save(path)
        return True
    except PermissionError:
        print("SAVE FAILED: Close EnB_Drop_Database.xlsx in OpenOffice Calc.")
        return False
    finally:
        wb.close()

def read_screen(win):
    images = {}
    texts = {}

    for name, psm_key in (
        ("target", "target_psm"),
        ("loot", "loot_psm"),
        ("zone", "zone_psm")
    ):
        reg = absolute_region(win, name)
        if reg:
            images[name] = grab(reg)
            texts[name] = ocr(images[name], cfg["ocr"][psm_key])
        else:
            images[name] = None
            texts[name] = ""

    return images, texts

def update_target(raw_text):
    global candidate_target, candidate_target_cl, candidate_target_reads
    global current_target, current_target_cl, last_target_seen_at

    mob, cl = parse_target(raw_text)
    if not mob:
        return

    if mob == candidate_target:
        candidate_target_reads += 1
        if cl:
            candidate_target_cl = cl
    else:
        candidate_target = mob
        candidate_target_cl = cl
        candidate_target_reads = 1

    needed = int(cfg["behavior"].get("stable_target_reads", 2))
    if candidate_target_reads >= needed and mob != current_target:
        old = current_target
        current_target = mob
        current_target_cl = candidate_target_cl
        last_target_seen_at = time.time()
        if old:
            print(f"Target: {old} -> {current_target}")
        else:
            print(f"Target: {current_target}")

    elif mob == current_target:
        if cl:
            current_target_cl = cl
        last_target_seen_at = time.time()

def update_zone(raw_text):
    global candidate_zone, candidate_zone_reads, current_zone

    zone = parse_zone(raw_text)
    if not zone:
        return

    if zone == candidate_zone:
        candidate_zone_reads += 1
    else:
        candidate_zone = zone
        candidate_zone_reads = 1

    needed = int(cfg["behavior"].get("stable_zone_reads", 2))
    if candidate_zone_reads >= needed and zone != current_zone:
        old = current_zone
        current_zone = zone
        if old:
            print(f"Zone/Sector: {old} -> {current_zone}")
        else:
            print(f"Zone/Sector: {current_zone}")

def loot_signature(items):
    normalized = "\n".join(
        f"{normalize_text(item).lower()}|{qty}"
        for item, qty in items
    )
    return hashlib.sha1(normalized.encode("utf-8", errors="ignore")).hexdigest()

def process_loot(raw_text, images):
    global candidate_loot_text, candidate_loot_reads
    global last_logged_loot_hash, last_log_time

    items = parse_loot(raw_text)
    if not items:
        candidate_loot_text = ""
        candidate_loot_reads = 0
        return

    # Make sure the same loot OCR result is seen more than once before recording.
    normalized = "\n".join(f"{i}|{q}" for i, q in items)

    if normalized == candidate_loot_text:
        candidate_loot_reads += 1
    else:
        candidate_loot_text = normalized
        candidate_loot_reads = 1

    needed = int(cfg["behavior"].get("loot_stable_reads", 2))
    if candidate_loot_reads < needed:
        return

    sig = loot_signature(items)
    now = time.time()

    if sig == last_logged_loot_hash:
        return

    cooldown = float(cfg["behavior"].get("loot_event_cooldown_seconds", 2.0))
    if now - last_log_time < cooldown:
        return

    # Use the most recently stable target. This is important because some games
    # clear/change the target immediately when a mob dies.
    memory = float(cfg["behavior"].get("recent_target_memory_seconds", 20.0))
    mob = current_target if (now - last_target_seen_at) <= memory else current_target

    if not mob:
        print("Loot detected, but no stable mob target is known yet. Not logged.")
        return

    ts = nowstr()
    screenshot = save_capture(
        images.get("target"), images.get("loot"), images.get("zone"), mob
    )

    kill_row = [
        ts,
        current_zone,
        mob,
        current_target_cl,
        len(items),
        screenshot,
        "Automatic target/zone/loot detection"
    ]

    drop_rows = [
        [
            ts,
            current_zone,
            mob,
            current_target_cl,
            item,
            qty,
            "Review",
            "automatic",
            "OCR; screenshot saved for verification"
        ]
        for item, qty in items
    ]

    if append_observation(kill_row, drop_rows):
        print(
            f"LOGGED [{current_zone or '?'}] {mob} "
            f"(CL {current_target_cl or '?'}) -> "
            + ", ".join(f"{item} x{qty}" for item, qty in items)
        )
        last_logged_loot_hash = sig
        last_log_time = now

def automatic_tick():
    win = find_window()
    if not win:
        return

    images, texts = read_screen(win)
    update_zone(texts["zone"])
    update_target(texts["target"])
    process_loot(texts["loot"], images)

def toggle_auto():
    global auto_enabled
    auto_enabled = not auto_enabled
    print("Automatic logging:", "ON" if auto_enabled else "OFF")

def stop():
    global running
    running = False

keyboard.add_hotkey("f5", guided_calibration)
keyboard.add_hotkey("f6", lambda: calibrate("target", "Select TARGET / MOB NAME area, ENTER to save"))
keyboard.add_hotkey("f7", lambda: calibrate("loot", "Select LOOT ITEM LIST area, ENTER to save"))
keyboard.add_hotkey("f9", lambda: calibrate("zone", "Select ZONE / SECTOR NAME area, ENTER to save"))
keyboard.add_hotkey("f10", toggle_auto)
keyboard.add_hotkey("f12", stop)

print("Earth & Beyond Drop Logger — AUTOMATIC")
print("Microsoft Excel is NOT required. OpenOffice Calc is supported.")
print("")
print("NORMAL GAMEPLAY: no hotkeys needed.")
print("The logger follows target, zone/sector, and loot automatically.")
print("")
print("Maintenance: F5 guided calibration | F10 auto on/off | F12 quit")
print("Keep EnB_Drop_Database.xlsx CLOSED while logging.")

if not calibration_complete():
    print("")
    print("FIRST RUN: calibration is required.")
    print("Earth & Beyond must be visible.")
    time.sleep(1)
    guided_calibration()

while running:
    try:
        if auto_enabled and calibration_complete():
            automatic_tick()
    except Exception as e:
        print("Scan error:", e)

    time.sleep(float(cfg.get("scan_interval_seconds", 0.6)))

print("Stopped.")

@echo off
cd /d "%~dp0"
start "" pythonw enb_drop_logger_tray.py
exit

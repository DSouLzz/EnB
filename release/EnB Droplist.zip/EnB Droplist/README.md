# EnB Droplist

Current version: **1.1.4**

This is the automatic Earth & Beyond drop logger.

## Permanent download filename

Every public release should be uploaded to:

`/EnB/Download/EnB Droplist.zip`

Do **not** change the ZIP filename between versions.

Expected public URL:

`https://soulbound.se/EnB/Download/EnB%20Droplist.zip`

## Auto updater

On startup the program checks:

`https://soulbound.se/EnB/Download/version.json`

If `version.json` contains a newer version, the logger:

1. downloads `EnB Droplist.zip`;
2. verifies the SHA-256 checksum when one is supplied;
3. exits the current tray logger;
4. backs up the old program files to `_previous_version`;
5. preserves `EnB_Drop_Database.xlsx`, `config.json`, `captures/`, and `logger_status.txt`;
6. installs the new files;
7. restarts itself.

There is also a **Check for Updates** item in the tray menu.

## Updating a release on soulbound.se

Upload these two files into `/EnB/Download/`:

- `EnB Droplist.zip`
- `version.json`

The filenames remain the same for every release. Only the version number, checksum,
release date and release notes inside `version.json` change.

## OpenOffice

Microsoft Excel is not required. Keep `EnB_Drop_Database.xlsx` closed while logging,
then open it with Apache OpenOffice Calc after the logger is stopped or paused.


## Guided calibration prompts

Calibration no longer captures the screen immediately.

Before every step, EnB Droplist tells you what to prepare and waits for you:

- **Target:** select a mob and make its name / combat level visible.
- **Loot:** kill a mob, open its corpse, and leave the loot item list visible.
- **Zone / Sector:** open the in-game **Map** and make the current zone / sector name visible.

Click **OK / Ready** only after the required game UI is visible. The logger then
brings Earth & Beyond forward, takes the calibration image, and asks you to draw
the rectangle.

This also applies when using an individual **Recalibrate Target / Loot / Zone**
command from the tray menu.

## 1.1.4 fixes

- HTTPS update checks now use the current `certifi` CA bundle while keeping certificate verification enabled.
- Fixed Summary rebuilding when the starter workbook contains merged instruction rows (OpenOffice `MergedCell` error).


## Version 1.1.4

- **Check for Update** now always gives visible tray feedback.
- Shows "Checking for updates..." immediately.
- Shows "You already have the latest version" when current.
- Shows the discovered version and release notes when an update is found.
- Shows the actual exception text if the update check fails.
- HTTPS update checks continue to use `certifi` with certificate verification enabled.


## 1.1.5
- Update installs now require a Yes/No confirmation.
- Background update checks never install automatically.
- A success dialog appears after an update restarts the app.
- Added **OCR Status / Test** in the tray menu.
- OCR Status shows raw and parsed Mob, CL/Lvl, Zone and Items.
- Broader Combat Level parsing.
- Loot/corpse events can create a Kill row even if zero item lines are parsed.
- Missing zones are written as `Unknown / not read` instead of blank.


## 1.1.6
- Fixed critical workbook save bug: `ws` was undefined in Summary rebuild.
  This prevented Kills/Drops from being saved at all.
- Fixed internal updater version so the app no longer offers the version it already installed.
- Rejects obvious browser/privacy/email OCR text as mob/zone data.
- Reminder: screen OCR requires the Earth & Beyond window to remain visible and unobstructed.


## 1.1.7
- Added movable always-on-top live overlay.
- Global **F8** toggles overlay visibility.
- Overlay shows only **Zone**, **Kills**, and **Last drop**.
- Kill counter resets when the detected zone changes.
- Overlay remembers its last screen position.


## 1.1.8
- **M-map driven Zone/Area**: pressing M is observed passively; the logger does not steal the key.
- After M is pressed, the calibrated map-zone area is OCR-read for 4 seconds and the last stable Zone is retained.
- Ordinary gameplay no longer overwrites Zone with random UI/browser-looking text.
- Target/Loot scan interval is now 0.45 seconds for faster live feedback.
- Live overlay increments Kills and updates Last drop **only after the XLSX row was saved and read back successfully**.
- `logger_status.txt` now writes `XLSX SAVED+VERIFIED` and `LIVE+XLSX OK` for successful events.
- Recalibration wording now explicitly says to open the map with M before selecting the Map Zone area.

### Important
Do not keep `EnB_Drop_Database.xlsx` open in Excel/OpenOffice while logging; those applications may lock the file.
Use the F8 live overlay during gameplay instead.


## 1.1.9
### Hover-tooltip loot recognition
- Loot item icons are **no longer parsed as item text**.
- The logger never moves the mouse.
- When **you hover a loot slot**, EnB's tooltip is OCR-read automatically.
- The first real tooltip line becomes the item name.
- Metadata such as `Structure 100%`, `Quality 100%`, percentages, durability and similar UI text is ignored.
- Two matching tooltip reads are required before an item is accepted.
- The F8 overlay updates `Last drop` as soon as a stable tooltip item is recognised.
- Excel writes item names from the hover tooltip, never the icon-grid OCR garbage.
- One kill is logged per loot-window session after at least one real hovered item is recognised.
- If Target OCR is unavailable, Excel records `Unknown mob / target not read` rather than losing the loot event.

### Map / Zone
- Press M normally in EnB. The logger passively samples the calibrated map-zone text for four seconds.
- Zone remains cached after the map is closed.

### Diagnostics
- `OCR Status / Test` now shows `HOVER TOOLTIP RAW` and `PARSED HOVER ITEM`.
- For the test, keep your mouse hovering the item while opening/running OCR Status.


## 1.1.10
- Fixed `OCR Status failed: '<=' not supported between instances of 'str' and 'int'`.
- Fixed hover-tooltip image preprocessing for the actual cv2 image type.
- Zone changes now immediately update the F8 overlay and reset the per-zone Kill counter.
- M-map OCR now has a broad fallback that can find clean map titles such as `Earth`
  even when the manually calibrated Zone rectangle misses the title.
- Target OCR now has a lower-right EnB fallback that looks specifically for
  `Corpse of ...` labels.
- OCR Status/Test shows both calibrated OCR and fallback OCR so calibration problems
  can be diagnosed without crashing.


## 1.1.11
### Deterministic EnB title OCR
- Removed the broad screen-search fallback that was accidentally reading chat/UI noise.
- **Zone** now reads a narrow map-title strip where EnB displays names such as `Earth`.
- **Target/Mob** now reads a narrow lower-right target-title strip where EnB displays names such as
  `Corporate Park` or `Corpse of Infiniti - Go Bot`.
- Calibrated OCR remains available only as a secondary fallback.
- Zone parsing now rejects symbol-heavy garbage such as `com ~`.
- `OCR Status / Test` labels the exact title-strip OCR so it is easier to diagnose scaling issues.

### Loot
- User-hover tooltip OCR from 1.1.9 remains unchanged; the logger never moves your mouse.


## 1.1.12
- The same map-title OCR that correctly reads `Earth` in OCR Status is now the direct live Zone path.
- F8 overlay is updated immediately once that stable map title is accepted.
- Target panel is split into two deterministic OCR strips:
  - target/mob name
  - `Level / Lvl / CL` line
- This prevents `Level 9` from being mixed into the mob name.
- Deterministic target-panel OCR is now preferred over the old calibrated Target region.
- Added clearer diagnostic log lines:
  - `MAP LIVE OK`
  - `TARGET LIVE OK`


## 1.1.13
- Map heading OCR moved onto the actual `Earth` / `Jupiter` title position.
- Zone changes now require 4 genuine identical OCR scans; no synthetic double-read.
- Added zone sanity filtering so uppercase multi-word OCR garbage such as `PENNE WS SS`
  cannot become the live zone.
- Target name strip widened for full names such as `Dionysian Spore Cluster`.
- Level is read from a separate lower strip, with a wider fallback for `Level 4`, etc.


## 1.1.14
- OCR regions now scale from the actual EnB client area rather than the outer window frame.
- Map title and target/Level strips were realigned to the actual screenshots.
- Added target fallback from both `Dest: <target>` and the reticle label.
- Zone changes require 5 stable reads and stricter one-word capitalization checks.


## 1.1.15
- Live Zone polls the same proven map-title strip as OCR Status/Test on every scan.
- Zone no longer depends on detecting the M-key timing.
- Three genuine stable reads confirm the Zone.
- Target name/Level strips realigned for the lower-right target card.


## 1.1.16
- Zone title OCR now runs multiple preprocessing/PSM passes and chooses a consensus reading.
- Similar OCR variants reinforce one another across scans instead of resetting Zone detection.
- This specifically improves names such as `Yasuragi Area` when individual reads lose/alter a letter.
- `Dest: <target>` is now the primary target-name source.
- Target card remains useful for enriching `Level N`.


## 1.1.17
- Live F8 Zone now mirrors the exact accepted `current_zone` produced by the same
  multipass/fuzzy OCR used by OCR Status/Test.
- Added `MAP LIVE SAMPLE` diagnostics with OCR title, candidate, stable-read count,
  accepted current zone and overlay value.
- `Dest:` OCR moved onto the actual bright white Dest line.
- Two tight Dest strips are sampled for scaling tolerance.
- `Corpse of Cybertronic Wight` is normalized to `Cybertronic Wight` before
  live display, Excel logging and diagnostics.
- Target card/reticle remain fallback/enrichment sources only.


## 1.1.18
### Monster detection from filled HP/shield bars
- Mob classification now uses **filled horizontal bar length**, not merely the
  presence of red/blue pixels or the target-card frame.
- A combat target must have a meaningful filled **red HP** segment and **blue shield**
  segment.
- Empty navpoint/gate/station target bars are ignored.
- `OCR Status / Test` now shows:
  - `COMBAT BARS: YES/NO`
  - red fill percentage
  - blue fill percentage
- Loot is associated with the most recent confirmed combat target for up to 45 seconds,
  because bars naturally disappear once the mob is dead.


## 1.1.19
### EnB alien/humanoid combat rules
- A living combat target now requires **red HP OR blue shield fill**.
- This supports alien mobs that never show a filled red HP bar.
- Mechanical/humanoid mobs still work with red and/or blue fill.
- Navpoints/gates/stations with empty red+blue frames remain non-combat.
- `Corpse of ...` is treated as a separate strong post-death signal, because
  a corpse naturally has no filled combat bars.
- OCR Status now reports both the bar-fill result and the corpse signal.


## 1.1.20
### Final enemy classification rule
- A **filled blue shield bar** is now the authoritative signal that the selected target is an enemy.
- Red HP fill is diagnostic only and is no longer required for combat classification.
- This supports alien enemies that never show a filled red HP bar.
- Navpoints, gates, stations and similar objects with an empty blue bar remain non-combat.
- `Corpse of ...` remains the post-death signal after the blue shield bar disappears.
- OCR Status/Test now reports:
  - `COMBAT TARGET: YES/NO`
  - blue shield fill percentage
  - red HP fill percentage (diagnostic only)


## 1.1.21
### Combat-card OCR
- Once blue shield fill confirms an enemy, the logger reads only the lower-right
  target card for mob name and Level.
- Generic target OCR no longer gets to override a confirmed combat-card result.
- Name and Level are OCR'd separately with multiple preprocessing/PSM passes.
- Similar name readings are clustered and the best repeated full title is chosen.
- OCR Status/Test now shows `COMBAT CARD OCR RAW` for direct diagnostics.


## 1.1.22
- Fixed OCR Status/Test crash: missing `title_similarity()` helper.
- Keeps the 1.1.21 blue-shield combat-target and target-card OCR logic.


## 1.1.23
- Restored missing `zone_title_multipass()` used by OCR Status/Test.
- Retains `title_similarity()` from 1.1.22.
- Added build-time static scan for unresolved function-call names.
- Retains blue-shield enemy detection and combat-card mob/level OCR.

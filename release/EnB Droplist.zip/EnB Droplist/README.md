# EnB Droplist

Current version: **1.1.4**

This is the automatic Earth & Beyond drop logger.

## Permanent download filename

Every public release should be uploaded to:

`/EnB/Download/EnB Droplist.zip`

Do **not** change the ZIP filename between versions.

Expected public URL:

`https://soulbound.se/EnB/Download/EnB%20Droplist.zip`

## Auto updater

On startup the program checks:

`https://soulbound.se/EnB/Download/version.json`

If `version.json` contains a newer version, the logger:

1. downloads `EnB Droplist.zip`;
2. verifies the SHA-256 checksum when one is supplied;
3. exits the current tray logger;
4. backs up the old program files to `_previous_version`;
5. preserves `EnB_Drop_Database.xlsx`, `config.json`, `captures/`, and `logger_status.txt`;
6. installs the new files;
7. restarts itself.

There is also a **Check for Updates** item in the tray menu.

## Updating a release on soulbound.se

Upload these two files into `/EnB/Download/`:

- `EnB Droplist.zip`
- `version.json`

The filenames remain the same for every release. Only the version number, checksum,
release date and release notes inside `version.json` change.

## OpenOffice

Microsoft Excel is not required. Keep `EnB_Drop_Database.xlsx` closed while logging,
then open it with Apache OpenOffice Calc after the logger is stopped or paused.


## Guided calibration prompts

Calibration no longer captures the screen immediately.

Before every step, EnB Droplist tells you what to prepare and waits for you:

- **Target:** select a mob and make its name / combat level visible.
- **Loot:** kill a mob, open its corpse, and leave the loot item list visible.
- **Zone / Sector:** open the in-game **Map** and make the current zone / sector name visible.

Click **OK / Ready** only after the required game UI is visible. The logger then
brings Earth & Beyond forward, takes the calibration image, and asks you to draw
the rectangle.

This also applies when using an individual **Recalibrate Target / Loot / Zone**
command from the tray menu.

## 1.1.4 fixes

- HTTPS update checks now use the current `certifi` CA bundle while keeping certificate verification enabled.
- Fixed Summary rebuilding when the starter workbook contains merged instruction rows (OpenOffice `MergedCell` error).


## Version 1.1.4

- **Check for Update** now always gives visible tray feedback.
- Shows "Checking for updates..." immediately.
- Shows "You already have the latest version" when current.
- Shows the discovered version and release notes when an update is found.
- Shows the actual exception text if the update check fails.
- HTTPS update checks continue to use `certifi` with certificate verification enabled.


## 1.1.5
- Update installs now require a Yes/No confirmation.
- Background update checks never install automatically.
- A success dialog appears after an update restarts the app.
- Added **OCR Status / Test** in the tray menu.
- OCR Status shows raw and parsed Mob, CL/Lvl, Zone and Items.
- Broader Combat Level parsing.
- Loot/corpse events can create a Kill row even if zero item lines are parsed.
- Missing zones are written as `Unknown / not read` instead of blank.


## 1.1.6
- Fixed critical workbook save bug: `ws` was undefined in Summary rebuild.
  This prevented Kills/Drops from being saved at all.
- Fixed internal updater version so the app no longer offers the version it already installed.
- Rejects obvious browser/privacy/email OCR text as mob/zone data.
- Reminder: screen OCR requires the Earth & Beyond window to remain visible and unobstructed.


## 1.1.7
- Added movable always-on-top live overlay.
- Global **F8** toggles overlay visibility.
- Overlay shows only **Zone**, **Kills**, and **Last drop**.
- Kill counter resets when the detected zone changes.
- Overlay remembers its last screen position.


## 1.1.8
- **M-map driven Zone/Area**: pressing M is observed passively; the logger does not steal the key.
- After M is pressed, the calibrated map-zone area is OCR-read for 4 seconds and the last stable Zone is retained.
- Ordinary gameplay no longer overwrites Zone with random UI/browser-looking text.
- Target/Loot scan interval is now 0.45 seconds for faster live feedback.
- Live overlay increments Kills and updates Last drop **only after the XLSX row was saved and read back successfully**.
- `logger_status.txt` now writes `XLSX SAVED+VERIFIED` and `LIVE+XLSX OK` for successful events.
- Recalibration wording now explicitly says to open the map with M before selecting the Map Zone area.

### Important
Do not keep `EnB_Drop_Database.xlsx` open in Excel/OpenOffice while logging; those applications may lock the file.
Use the F8 live overlay during gameplay instead.


## 1.1.9
### Hover-tooltip loot recognition
- Loot item icons are **no longer parsed as item text**.
- The logger never moves the mouse.
- When **you hover a loot slot**, EnB's tooltip is OCR-read automatically.
- The first real tooltip line becomes the item name.
- Metadata such as `Structure 100%`, `Quality 100%`, percentages, durability and similar UI text is ignored.
- Two matching tooltip reads are required before an item is accepted.
- The F8 overlay updates `Last drop` as soon as a stable tooltip item is recognised.
- Excel writes item names from the hover tooltip, never the icon-grid OCR garbage.
- One kill is logged per loot-window session after at least one real hovered item is recognised.
- If Target OCR is unavailable, Excel records `Unknown mob / target not read` rather than losing the loot event.

### Map / Zone
- Press M normally in EnB. The logger passively samples the calibrated map-zone text for four seconds.
- Zone remains cached after the map is closed.

### Diagnostics
- `OCR Status / Test` now shows `HOVER TOOLTIP RAW` and `PARSED HOVER ITEM`.
- For the test, keep your mouse hovering the item while opening/running OCR Status.


## 1.1.10
- Fixed `OCR Status failed: '<=' not supported between instances of 'str' and 'int'`.
- Fixed hover-tooltip image preprocessing for the actual cv2 image type.
- Zone changes now immediately update the F8 overlay and reset the per-zone Kill counter.
- M-map OCR now has a broad fallback that can find clean map titles such as `Earth`
  even when the manually calibrated Zone rectangle misses the title.
- Target OCR now has a lower-right EnB fallback that looks specifically for
  `Corpse of ...` labels.
- OCR Status/Test shows both calibrated OCR and fallback OCR so calibration problems
  can be diagnosed without crashing.

# EnB Droplist

Current version: **1.1.1**

This is the automatic Earth & Beyond drop logger.

## Permanent download filename

Every public release should be uploaded to:

`/EnB/Download/EnB Droplist.zip`

Do **not** change the ZIP filename between versions.

Expected public URL:

`https://soulbound.se/EnB/Download/EnB%20Droplist.zip`

## Auto updater

On startup the program checks:

`https://soulbound.se/EnB/Download/version.json`

If `version.json` contains a newer version, the logger:

1. downloads `EnB Droplist.zip`;
2. verifies the SHA-256 checksum when one is supplied;
3. exits the current tray logger;
4. backs up the old program files to `_previous_version`;
5. preserves `EnB_Drop_Database.xlsx`, `config.json`, `captures/`, and `logger_status.txt`;
6. installs the new files;
7. restarts itself.

There is also a **Check for Updates** item in the tray menu.

## Updating a release on soulbound.se

Upload these two files into `/EnB/Download/`:

- `EnB Droplist.zip`
- `version.json`

The filenames remain the same for every release. Only the version number, checksum,
release date and release notes inside `version.json` change.

## OpenOffice

Microsoft Excel is not required. Keep `EnB_Drop_Database.xlsx` closed while logging,
then open it with Apache OpenOffice Calc after the logger is stopped or paused.

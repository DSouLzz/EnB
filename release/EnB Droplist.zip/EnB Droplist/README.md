# EnB Droplist

Current version: **1.1.4**

This is the automatic Earth & Beyond drop logger.

## Permanent download filename

Every public release should be uploaded to:

`/EnB/Download/EnB Droplist.zip`

Do **not** change the ZIP filename between versions.

Expected public URL:

`https://soulbound.se/EnB/Download/EnB%20Droplist.zip`

## Auto updater

On startup the program checks:

`https://soulbound.se/EnB/Download/version.json`

If `version.json` contains a newer version, the logger:

1. downloads `EnB Droplist.zip`;
2. verifies the SHA-256 checksum when one is supplied;
3. exits the current tray logger;
4. backs up the old program files to `_previous_version`;
5. preserves `EnB_Drop_Database.xlsx`, `config.json`, `captures/`, and `logger_status.txt`;
6. installs the new files;
7. restarts itself.

There is also a **Check for Updates** item in the tray menu.

## Updating a release on soulbound.se

Upload these two files into `/EnB/Download/`:

- `EnB Droplist.zip`
- `version.json`

The filenames remain the same for every release. Only the version number, checksum,
release date and release notes inside `version.json` change.

## OpenOffice

Microsoft Excel is not required. Keep `EnB_Drop_Database.xlsx` closed while logging,
then open it with Apache OpenOffice Calc after the logger is stopped or paused.


## Guided calibration prompts

Calibration no longer captures the screen immediately.

Before every step, EnB Droplist tells you what to prepare and waits for you:

- **Target:** select a mob and make its name / combat level visible.
- **Loot:** kill a mob, open its corpse, and leave the loot item list visible.
- **Zone / Sector:** open the in-game **Map** and make the current zone / sector name visible.

Click **OK / Ready** only after the required game UI is visible. The logger then
brings Earth & Beyond forward, takes the calibration image, and asks you to draw
the rectangle.

This also applies when using an individual **Recalibrate Target / Loot / Zone**
command from the tray menu.

## 1.1.4 fixes

- HTTPS update checks now use the current `certifi` CA bundle while keeping certificate verification enabled.
- Fixed Summary rebuilding when the starter workbook contains merged instruction rows (OpenOffice `MergedCell` error).


## Version 1.1.4

- **Check for Update** now always gives visible tray feedback.
- Shows "Checking for updates..." immediately.
- Shows "You already have the latest version" when current.
- Shows the discovered version and release notes when an update is found.
- Shows the actual exception text if the update check fails.
- HTTPS update checks continue to use `certifi` with certificate verification enabled.


## 1.1.5
- Update installs now require a Yes/No confirmation.
- Background update checks never install automatically.
- A success dialog appears after an update restarts the app.
- Added **OCR Status / Test** in the tray menu.
- OCR Status shows raw and parsed Mob, CL/Lvl, Zone and Items.
- Broader Combat Level parsing.
- Loot/corpse events can create a Kill row even if zero item lines are parsed.
- Missing zones are written as `Unknown / not read` instead of blank.


## 1.1.6
- Fixed critical workbook save bug: `ws` was undefined in Summary rebuild.
  This prevented Kills/Drops from being saved at all.
- Fixed internal updater version so the app no longer offers the version it already installed.
- Rejects obvious browser/privacy/email OCR text as mob/zone data.
- Reminder: screen OCR requires the Earth & Beyond window to remain visible and unobstructed.

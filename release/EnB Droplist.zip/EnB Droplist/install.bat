@echo off
setlocal
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo Background/tray logger packages installed.
echo Start the game, then double-click run_logger_tray.bat
echo.
pause

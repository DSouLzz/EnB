from __future__ import annotations
import os, sys, time, shutil, zipfile, subprocess
from pathlib import Path

PRESERVE = {
    "EnB_Drop_Database.xlsx",
    "config.json",
    "logger_status.txt",
}
PRESERVE_DIRS = {"captures", "data"}

def wait_for_pid(pid: int, timeout=30):
    end = time.time() + timeout
    while time.time() < end:
        try:
            os.kill(pid, 0)
            time.sleep(0.4)
        except OSError:
            return
    time.sleep(1)

def copy_tree(src: Path, dst: Path):
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        if not rel.parts:
            continue
        if rel.parts[0] in PRESERVE_DIRS:
            continue
        if len(rel.parts) == 1 and rel.name in PRESERVE:
            continue
        target = dst / rel
        if p.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, target)

def main():
    if len(sys.argv) < 6:
        return 2
    pid = int(sys.argv[1])
    zip_path = Path(sys.argv[2])
    install_dir = Path(sys.argv[3])
    restart_bat = Path(sys.argv[4])
    new_version = sys.argv[5]

    wait_for_pid(pid)

    temp_extract = zip_path.parent / "enb_update_extract"
    if temp_extract.exists():
        shutil.rmtree(temp_extract, ignore_errors=True)
    temp_extract.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(temp_extract)

    # ZIP contains a single top-level package folder.
    roots = [p for p in temp_extract.iterdir() if p.is_dir()]
    payload = roots[0] if len(roots) == 1 else temp_extract

    # Backup current program files, while preserving user data separately.
    backup = install_dir / "_previous_version"
    if backup.exists():
        shutil.rmtree(backup, ignore_errors=True)
    backup.mkdir(parents=True, exist_ok=True)

    for p in install_dir.iterdir():
        if p.name in PRESERVE or p.name in PRESERVE_DIRS or p.name == "_previous_version":
            continue
        try:
            if p.is_dir():
                shutil.copytree(p, backup / p.name, dirs_exist_ok=True)
            else:
                shutil.copy2(p, backup / p.name)
        except Exception:
            pass

    copy_tree(payload, install_dir)

    try:
        zip_path.unlink(missing_ok=True)
        shutil.rmtree(temp_extract, ignore_errors=True)
    except Exception:
        pass

    try:
        import json
        (install_dir / "update_completed.json").write_text(json.dumps({"version": new_version}), encoding="utf-8")
    except Exception:
        pass

    # Restart tray app.
    subprocess.Popen(
        ["cmd", "/c", "start", "", str(restart_bat)],
        cwd=str(install_dir),
        shell=False
    )
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

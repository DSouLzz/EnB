@echo off
cd /d "%~dp0"
python enb_drop_logger.py
pause

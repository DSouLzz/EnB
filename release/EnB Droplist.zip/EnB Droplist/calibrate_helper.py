"""
Standalone calibration helper for EnB Drop Logger.
Runs independently from the tray process so OpenCV GUI cannot freeze the tray app.
"""
from __future__ import annotations
import json, sys, time
from pathlib import Path

import cv2
import mss
import numpy as np
import pygetwindow as gw

BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config.json"

def find_window(cfg):
    needle = cfg["window_title_contains"].lower()
    wins = [
        w for w in gw.getAllWindows()
        if needle in (w.title or "").lower() and w.width > 0 and w.height > 0
    ]
    return wins[0] if wins else None

def grab(region):
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

def main():
    if len(sys.argv) < 3:
        return 2

    name = sys.argv[1]
    prompt = sys.argv[2]

    with CFG_PATH.open("r", encoding="utf-8") as f:
        cfg = json.load(f)

    win = find_window(cfg)
    if not win:
        return 3

    try:
        win.restore()
        win.activate()
        time.sleep(0.7)
    except Exception:
        pass

    img = grab({
        "left": win.left,
        "top": win.top,
        "width": win.width,
        "height": win.height
    })

    x, y, w, h = cv2.selectROI(prompt, img, False, False)
    cv2.destroyAllWindows()

    if w <= 0 or h <= 0:
        return 4

    cfg["regions"][name] = {
        "left": int(x),
        "top": int(y),
        "width": int(w),
        "height": int(h)
    }

    CFG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

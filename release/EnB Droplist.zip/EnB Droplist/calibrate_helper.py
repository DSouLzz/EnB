"""
Standalone calibration helper for EnB Droplist.

Each calibration first shows a preparation prompt and waits for the player.
Only after clicking Ready does it capture the game screen and open the
rectangle-selection overlay.
"""
from __future__ import annotations
import json, sys, time, ctypes
from pathlib import Path

import cv2
import mss
import numpy as np
import pygetwindow as gw

BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config.json"

MB_OKCANCEL = 0x00000001
MB_ICONINFORMATION = 0x00000040
IDOK = 1

PREP_TEXT = {
    "target": (
        "TARGET CALIBRATION\n\n"
        "1. Return to Earth & Beyond.\n"
        "2. Select a mob so its target name is clearly visible.\n"
        "3. If Combat Level is shown beside the name, make sure that is visible too.\n\n"
        "When the game is ready, click OK.\n"
        "You will then draw a box around ONLY the target name / CL area."
    ),
    "loot": (
        "LOOT CALIBRATION\n\n"
        "1. Return to Earth & Beyond.\n"
        "2. Kill a mob or use a corpse that has loot.\n"
        "3. Open the loot window and leave the item names visible.\n\n"
        "When the loot list is ready, click OK.\n"
        "You will then draw a box around ONLY the loot item list."
    ),
    "zone": (
        "ZONE / SECTOR CALIBRATION\n\n"
        "1. Return to Earth & Beyond.\n"
        "2. Open the MAP.\n"
        "3. Make sure the current zone / sector name is visible on the map.\n\n"
        "When the map is open and the zone name is visible, click OK.\n"
        "You will then draw a box around ONLY the zone / sector name."
    ),
}

def message(text, title="EnB Droplist Calibration"):
    return ctypes.windll.user32.MessageBoxW(
        None, text, title, MB_OKCANCEL | MB_ICONINFORMATION
    )

def find_window(cfg):
    needle = cfg["window_title_contains"].lower()
    wins = [
        w for w in gw.getAllWindows()
        if needle in (w.title or "").lower() and w.width > 0 and w.height > 0
    ]
    return wins[0] if wins else None

def grab(region):
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

def main():
    if len(sys.argv) < 3:
        return 2

    name = sys.argv[1]
    prompt = sys.argv[2]

    with CFG_PATH.open("r", encoding="utf-8") as f:
        cfg = json.load(f)

    # Crucially: prompt FIRST, before taking a screenshot.
    prep = PREP_TEXT.get(
        name,
        f"Prepare Earth & Beyond for {name} calibration, then click OK."
    )
    if message(prep) != IDOK:
        return 4

    win = find_window(cfg)
    if not win:
        ctypes.windll.user32.MessageBoxW(
            None,
            "Earth & Beyond window was not found.\n\nStart or restore the game and try again.",
            "EnB Droplist Calibration",
            MB_ICONINFORMATION
        )
        return 3

    try:
        win.restore()
        win.activate()
        time.sleep(0.8)
    except Exception:
        pass

    # Screenshot is taken AFTER the player has prepared the game.
    img = grab({
        "left": win.left,
        "top": win.top,
        "width": win.width,
        "height": win.height
    })

    x, y, w, h = cv2.selectROI(prompt, img, False, False)
    cv2.destroyAllWindows()

    if w <= 0 or h <= 0:
        return 4

    cfg["regions"][name] = {
        "left": int(x),
        "top": int(y),
        "width": int(w),
        "height": int(h)
    }

    CFG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

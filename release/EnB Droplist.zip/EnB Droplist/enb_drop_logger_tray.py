"""
EnB Droplist — Background Tray Edition v2

Fixes:
- Calibration runs in a separate process, so OpenCV selection cannot freeze the tray app.
- Successful loot captures show a tray notification.
"""
from __future__ import annotations
import json, re, time, hashlib, threading, subprocess, sys, ctypes
from datetime import datetime
from pathlib import Path

import cv2
import mss
import numpy as np
import pytesseract
import tkinter as tk
from ctypes import wintypes
import pygetwindow as gw
from openpyxl import load_workbook
from PIL import Image, ImageDraw
import pystray
import auto_updater

BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config.json"
LOG_PATH = BASE / "logger_status.txt"
CAPTURE_DIR = BASE / "captures"
CAPTURE_DIR.mkdir(exist_ok=True)

with CFG_PATH.open("r", encoding="utf-8") as f:
    cfg = json.load(f)

pytesseract.pytesseract.tesseract_cmd = cfg["ocr"]["tesseract_cmd"]

running = True
auto_enabled = bool(cfg["behavior"].get("automatic", True))
calibrating = False
state_lock = threading.Lock()

current_target = ""
current_target_cl = ""
current_zone = ""
last_target_seen_at = 0.0

candidate_target = ""
candidate_target_cl = ""
candidate_target_reads = 0
candidate_zone = ""
candidate_zone_reads = 0
candidate_loot_text = ""
candidate_loot_reads = 0
last_logged_loot_hash = ""
last_log_time = 0.0
last_ocr_texts = {"target":"","loot":"","zone":""}
last_ocr_items = []
last_scan_error = ""

live_overlay = {
    "zone": "Unknown / not read",
    "kills": 0,
    "last_drop": "—",
}
overlay_toggle_requested = threading.Event()
overlay_stop_requested = threading.Event()

# Pressing M in-game does not get intercepted. We only observe the key state,
# then OCR the calibrated map-zone title for a few seconds while the map is open.
map_zone_capture_until = 0.0

# User-hover tooltip OCR state. The logger never moves the mouse.
hover_item_candidate = ""
hover_item_reads = 0
hover_items_seen = []
loot_session_active = False
loot_session_last_seen = 0.0
loot_session_logged = False

def reload_config():
    global cfg
    try:
        with CFG_PATH.open("r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as e:
        log(f"Config reload error: {e!r}")

def log(msg):
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(f"[{stamp}] {msg}\n")
    except Exception:
        pass

def notify(title, msg):
    try:
        icon.notify(msg, title)
    except Exception as e:
        log(f"Notification error: {e!r}")
    log(f"{title}: {msg}")

def message_box(title, text, flags=0x00000040):
    try:
        return ctypes.windll.user32.MessageBoxW(None, str(text), str(title), flags)
    except Exception as e:
        log(f"MessageBox error: {e!r}")
        notify(title, text)
        return 0

def ask_yes_no(title, text):
    return message_box(title, text, 0x00000004 | 0x00000020) == 6

def show_update_complete_if_needed():
    marker = BASE / "update_completed.json"
    if not marker.exists():
        return
    try:
        info = json.loads(marker.read_text(encoding="utf-8"))
        ver = info.get("version", auto_updater.CURRENT_VERSION)
        marker.unlink(missing_ok=True)
        message_box("EnB Droplist updated",
                    f"Update {ver} was installed successfully.\n\n"
                    "Your calibration, config, captures and drop database were preserved.")
    except Exception as e:
        log(f"Update completion marker error: {e!r}")

def find_window():
    needle = cfg["window_title_contains"].lower()
    wins = [
        w for w in gw.getAllWindows()
        if needle in (w.title or "").lower() and w.width > 0 and w.height > 0
    ]
    return wins[0] if wins else None

def grab(region):
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

def absolute_region(win, name):
    r = cfg["regions"].get(name)
    if not r:
        return None
    return {
        "left": int(win.left + r["left"]),
        "top": int(win.top + r["top"]),
        "width": max(1, int(r["width"])),
        "height": max(1, int(r["height"]))
    }

def prep(img, scale=2):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 31, 9
    )

def ocr(img, psm):
    txt = pytesseract.image_to_string(prep(img), config=f"--psm {psm}")
    return "\n".join(x.strip() for x in txt.splitlines() if x.strip())

def norm(s):
    return re.sub(r"\s+", " ", s or "").strip(" |[]-:")

def parse_target(text):
    clean = norm(text)
    if not clean:
        return "", ""
    cl = ""
    for pat in (
        r"\b(?:CL|Combat\s*Level|Combat|Level|Lvl)\s*[:#\-]?\s*(\d{1,3})\b",
        r"\[\s*(?:CL\s*)?(\d{1,3})\s*\]",
    ):
        m = re.search(pat, clean, re.I)
        if m:
            cl = m.group(1)
            clean = norm(clean[:m.start()] + " " + clean[m.end():])
            break
    clean = re.sub(r"\b(?:Target|Hull|Shield|Structure|Range|Distance)\b\s*:?", "",
                   clean, flags=re.I)
    clean = norm(clean)
    if not (2 <= len(clean) <= 80) or re.fullmatch(r"[\d\s%./]+", clean):
        return "", cl
    if re.search(r"\b(?:privacy|personal information|cookie|email address|unsubscribe|http|www\.)\b", clean, re.I):
        return "", cl
    return clean[:80], cl

def parse_zone(text):
    clean = norm(text)
    if not clean:
        return ""
    clean = re.sub(
        r"^(?:Current\s*)?(?:Sector|Zone|Location|System|Area)\s*[:\-]?\s*",
        "", clean, flags=re.I)
    clean = norm(clean)
    if not (2 <= len(clean) <= 80) or re.fullmatch(r"[\d\s%./]+", clean):
        return ""
    if re.search(r"\b(?:privacy|personal information|cookie|email address|unsubscribe|http|www\.)\b", clean, re.I):
        return ""
    # A map title must be overwhelmingly ordinary title characters.
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9 '\-]{1,79}", clean):
        return ""
    if len(re.findall(r"[A-Za-z]", clean)) < 2:
        return ""
    return clean

def parse_loot(text):
    rows, seen = [], set()
    for raw in text.splitlines():
        line = norm(raw)
        if len(line) < 2:
            continue
        if re.search(
            r"\b(?:loot|cargo|close|take all|inventory|credits?|capacity|free space)\b",
            line, re.I
        ):
            continue
        qty, item = 1, line
        m = re.match(r"^(\d+)\s*[xX]\s+(.+)$", line)
        if m:
            qty, item = int(m.group(1)), m.group(2)
        else:
            m = re.match(r"^(.+?)\s+[xX]\s*(\d+)$", line)
            if m:
                item, qty = m.group(1), int(m.group(2))
        item = norm(item)
        if item and item.lower() not in seen:
            seen.add(item.lower())
            rows.append((item[:120], qty))
    return rows

def loot_panel_present(raw_text, items):
    if items:
        return True
    raw = norm(raw_text)
    if not raw:
        return False
    return bool(re.search(r"\b(?:loot|corpse|cargo|take\s*all|no\s*loot|nothing|empty)\b",
                          raw, re.I))


def calibration_complete():
    return all(cfg["regions"].get(x) for x in ("target","loot","zone"))

def run_calibration_step(name, prompt):
    global calibrating
    with state_lock:
        if calibrating:
            notify("EnB Drop Logger", "Calibration is already running.")
            return False
        calibrating = True

    try:
        notify("Calibration", f"Select the {name} area in Earth & Beyond.")
        python_exe = sys.executable

        # When the tray runs under pythonw.exe, launch helper with python.exe
        # so OpenCV's window has a normal GUI-capable child process.
        if python_exe.lower().endswith("pythonw.exe"):
            candidate = python_exe[:-5] + ".exe"
            if Path(candidate).exists():
                python_exe = candidate

        result = subprocess.run(
            [python_exe, str(BASE / "calibrate_helper.py"), name, prompt],
            cwd=str(BASE),
            timeout=300,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )

        if result.returncode == 0:
            reload_config()
            notify("Calibration saved", f"{name.title()} area saved.")
            return True
        elif result.returncode == 3:
            notify("Calibration failed", "Earth & Beyond window was not found.")
        elif result.returncode == 4:
            notify("Calibration cancelled", f"{name.title()} selection was cancelled.")
        else:
            notify("Calibration failed", f"{name.title()} helper returned code {result.returncode}.")
        return False

    except subprocess.TimeoutExpired:
        notify("Calibration cancelled", "Calibration timed out after 5 minutes.")
        return False
    except Exception as e:
        log(f"Calibration helper error: {e!r}")
        notify("Calibration failed", "See logger_status.txt for details.")
        return False
    finally:
        with state_lock:
            calibrating = False

def guided_calibration(*_):
    def work():
        if not run_calibration_step("target", "1/3 TARGET: select mob name / CL, ENTER to save"):
            return
        if not run_calibration_step("loot", "2/3 LOOT: select corpse item list, ENTER to save"):
            return
        if not run_calibration_step("zone", "3/3 MAP ZONE: press M first, then select the zone/sector name, ENTER to save"):
            return
        notify("EnB Drop Logger", "Calibration complete. Automatic logging resumed.")
    threading.Thread(target=work, daemon=True).start()

def single_calibration(name, prompt):
    threading.Thread(
        target=lambda: run_calibration_step(name, prompt),
        daemon=True
    ).start()

def save_capture(images, mob):
    if not cfg["behavior"].get("save_capture_on_log", True):
        return ""
    imgs = [images.get("zone"), images.get("target"), images.get("loot")]
    imgs = [x for x in imgs if x is not None]
    if not imgs:
        return ""
    h = max(x.shape[0] for x in imgs)
    w = sum(x.shape[1] for x in imgs)
    canvas = np.zeros((h,w,3), dtype=np.uint8)
    pos = 0
    for im in imgs:
        canvas[:im.shape[0], pos:pos+im.shape[1]] = im
        pos += im.shape[1]
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^A-Za-z0-9_-]+","_",mob or "unknown")[:40]
    p = CAPTURE_DIR / f"{stamp}_{safe}.png"
    cv2.imwrite(str(p), canvas)
    return str(p)

def rebuild_summary(wb):
    ws = wb["Summary"]
    kd, agg = {}, {}
    for row in wb["Kills"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        if mob:
            kd[mob] = kd.get(mob, 0) + 1

    for row in wb["Drops"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        item = str(row[4] or "").strip()
        try:
            qty = int(row[5] or 1)
        except Exception:
            qty = 1
        if mob and item:
            rec = agg.setdefault((mob,item), [0,0])
            rec[0] += 1
            rec[1] += qty

    # Replace the generated summary area cleanly. The starter workbook has
    # merged instruction rows below row 2; writing to those MergedCell objects
    # raises "value is read-only" in openpyxl. Unmerge/remove that area first.
    for merged in list(ws.merged_cells.ranges):
        if merged.min_row >= 3:
            ws.unmerge_cells(str(merged))
    if ws.max_row >= 3:
        ws.delete_rows(3, ws.max_row - 2)

    for (mob,item),(events,qty) in sorted(agg.items()):
        kills = kd.get(mob,0)
        ws.append([
            mob, item, events, kills,
            (events/kills if kills else 0),
            qty, "Observed sample"
        ])
        ws.cell(ws.max_row,5).number_format = "0.0%"

def append_rows(kill, drops):
    path = (BASE / cfg["excel_file"]).resolve()
    if not path.exists():
        notify("EnB Drop Logger", "Database XLSX is missing.")
        log(f"XLSX FAIL missing file: {path}")
        return False

    try:
        wb = load_workbook(path)
        kills_ws = wb["Kills"]
        drops_ws = wb["Drops"]

        kills_ws.append(kill)
        kill_row = kills_ws.max_row

        for r in drops:
            drops_ws.append(r)

        rebuild_summary(wb)
        wb.save(path)
        wb.close()

        # Verify the just-written kill row can be read back from disk.
        verify = load_workbook(path, read_only=True, data_only=False)
        ws = verify["Kills"]
        saved_ts = ws.cell(kill_row, 1).value
        saved_zone = ws.cell(kill_row, 2).value
        saved_mob = ws.cell(kill_row, 3).value
        verify.close()

        ok = (
            str(saved_ts or "") == str(kill[0] or "")
            and str(saved_zone or "") == str(kill[1] or "")
            and str(saved_mob or "") == str(kill[2] or "")
        )

        if not ok:
            log(f"XLSX VERIFY FAIL row={kill_row} expected={kill[:3]!r} "
                f"readback={[saved_ts,saved_zone,saved_mob]!r}")
            notify("EnB Drop Logger", "XLSX save verification failed. See logger_status.txt.")
            return False

        log(f"XLSX SAVED+VERIFIED kill_row={kill_row} drop_rows={len(drops)} "
            f"zone={kill[1]!r} mob={kill[2]!r}")
        return True

    except PermissionError:
        notify("Database is open", "Close the XLSX in Excel/OpenOffice while logging.")
        log("XLSX FAIL: file is locked/open in another program.")
        return False
    except Exception as e:
        log(f"Workbook error: {e!r}")
        return False



def client_rect_screen(win):
    try:
        hwnd = int(win._hWnd)
        rect = wintypes.RECT()
        if not ctypes.windll.user32.GetClientRect(hwnd, ctypes.byref(rect)):
            raise RuntimeError("GetClientRect failed")
        pt = wintypes.POINT(rect.left, rect.top)
        if not ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(pt)):
            raise RuntimeError("ClientToScreen failed")
        width = int(rect.right - rect.left)
        height = int(rect.bottom - rect.top)
        if width < 200 or height < 150:
            raise RuntimeError(f"Suspicious client size {width}x{height}")
        return int(pt.x), int(pt.y), width, height
    except Exception as e:
        log(f"Client rect fallback: {e!r}")
        return int(win.left), int(win.top), int(win.width), int(win.height)

def client_region(win, x1, y1, x2, y2):
    left, top, width, height = client_rect_screen(win)
    x1 = float(x1); y1 = float(y1); x2 = float(x2); y2 = float(y2)
    l = left + int(width * x1)
    t = top + int(height * y1)
    r = left + int(width * x2)
    b = top + int(height * y2)
    return {
        "left": l,
        "top": t,
        "width": max(1, r - l),
        "height": max(1, b - t),
    }

def client_sparse_ocr(win, x1, y1, x2, y2, psm=11):
    try:
        return ocr(grab(client_region(win, x1, y1, x2, y2)), psm)
    except Exception as e:
        log(f"Client sparse OCR error: {e!r}")
        return ""

def relative_region(win, x1, y1, x2, y2):
    return client_region(win, x1, y1, x2, y2)

def sparse_ocr_region(win, x1, y1, x2, y2):
    return client_sparse_ocr(win, x1, y1, x2, y2, 11)

def clean_title_line(text):
    """Pick the most plausible short EnB title from a narrow title strip."""
    candidates = []
    for raw in str(text or "").splitlines():
        s = norm(raw)
        if not s:
            continue

        # Remove common title-strip prefixes/noise.
        s = re.sub(r"^(?:Dist(?:ance)?\s*:\s*)", "", s, flags=re.I)
        s = re.sub(r"^[\[\]{}()|:;.,'\"`~_+=*<>!?\\/]+", "", s).strip()
        s = re.sub(r"\s+", " ", s)

        if not (2 <= len(s) <= 90):
            continue
        if re.fullmatch(r"[\d\s%+./:_\-]+", s):
            continue
        if re.search(
            r"\b(?:Chat|Group|Options|Help|Emote|Computer|credits?|"
            r"Structure|Quality|Hull|Shield|Range|Distance|X:|Y:|Z:)\b",
            s, re.I
        ):
            continue

        # Title text should mostly consist of letters/digits/basic punctuation.
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 '\-.:()]{1,89}", s):
            continue

        letters = len(re.findall(r"[A-Za-z]", s))
        if letters < 2:
            continue

        candidates.append(s)

    if not candidates:
        return ""

    # Prefer lines that look like EnB names rather than OCR sentence debris.
    def score(x):
        words = x.split()
        titleish = sum(1 for w in words if w[:1].isupper())
        strange = len(re.findall(r"[^A-Za-z0-9 '\-.:()]", x))
        return (
            strange,
            0 if titleish else 1,
            abs(len(words) - min(len(words), 4)),
            len(x),
        )

    candidates.sort(key=score)
    return candidates[0]


def target_title_from_window(win):
    """Read the visible lower-right EnB target card."""
    name_raw = client_sparse_ocr(win, 0.790, 0.700, 0.990, 0.765, 7)
    name = clean_title_line(name_raw)

    level_raw = client_sparse_ocr(win, 0.825, 0.755, 0.970, 0.825, 7)
    cl = ""
    m = re.search(r"\b(?:Level|Lvl|CL)\s*[:#\-]?\s*(\d{1,3})\b", level_raw, re.I)
    if m:
        cl = m.group(1)

    if not name:
        raw2 = client_sparse_ocr(win, 0.775, 0.680, 0.998, 0.790, 11)
        for line in [norm(x) for x in raw2.splitlines() if norm(x)]:
            if re.search(r"\b(?:Level|Lvl|CL)\s*\d", line, re.I):
                continue
            candidate = clean_title_line(line)
            if candidate:
                name = candidate
                break
        name_raw += "\n" + raw2

    if not cl:
        raw2 = client_sparse_ocr(win, 0.800, 0.735, 0.990, 0.845, 11)
        m = re.search(r"\b(?:Level|Lvl|CL)\s*[:#\-]?\s*(\d{1,3})\b",
                      level_raw + "\n" + raw2, re.I)
        if m:
            cl = m.group(1)
        level_raw += "\n" + raw2

    return name, cl, f"NAME:\n{name_raw}\nLEVEL:\n{level_raw}"

def map_title_from_window(win):
    """
    Read the M-map title only (Earth/Jupiter).
    """
    raw = client_sparse_ocr(win, 0.255, 0.250, 0.350, 0.320, 7)
    title = clean_title_line(raw)

    if not title:
        raw2 = client_sparse_ocr(win, 0.235, 0.235, 0.385, 0.335, 11)
        title = clean_title_line(raw2)
        raw = raw + "\n" + raw2

    if title and len(title) < 4:
        title = ""

    return title, raw

def main_view_target_from_window(win):
    """
    Secondary confirmation from target reticle / Dest line.
    """
    raw_reticle = client_sparse_ocr(win, 0.405, 0.355, 0.625, 0.465, 11)
    raw_dest = client_sparse_ocr(win, 0.205, 0.765, 0.500, 0.845, 7)

    for raw in (raw_dest, raw_reticle):
        lines = [norm(x) for x in raw.splitlines() if norm(x)]
        for line in lines:
            line = re.sub(r"^Dest\s*:\s*", "", line, flags=re.I)
            m = re.match(r"(.+?)\s*\((\d{1,3})\)\s*$", line)
            cl = ""
            if m:
                line = norm(m.group(1))
                cl = m.group(2)

            candidate = clean_title_line(line)
            if candidate and 3 <= len(candidate) <= 80:
                raw_all = "RETICLE:\n" + raw_reticle + "\nDEST:\n" + raw_dest
                return candidate, cl, raw_all

    raw_all = "RETICLE:\n" + raw_reticle + "\nDEST:\n" + raw_dest
    return "", "", raw_all

def target_fallback_from_window(win):
    name, cl, raw = target_title_from_window(win)
    if name:
        return name, cl, raw

    name2, cl2, raw2 = main_view_target_from_window(win)
    return name2, (cl or cl2), raw + "\nMAIN VIEW:\n" + raw2


def map_zone_fallback_from_window(win):
    # Backwards-compatible wrapper used elsewhere in the logger.
    return map_title_from_window(win)


def update_target(text, fallback_mob="", fallback_cl=""):
    global candidate_target,candidate_target_cl,candidate_target_reads
    global current_target,current_target_cl,last_target_seen_at

    mob, cl = parse_target(text)
    if not mob and fallback_mob:
        mob, cl = fallback_mob, fallback_cl
    if not mob:
        return

    if mob == candidate_target:
        candidate_target_reads += 1
        if cl:
            candidate_target_cl = cl
    else:
        candidate_target = mob
        candidate_target_cl = cl
        candidate_target_reads = 1

    if candidate_target_reads >= int(cfg["behavior"].get("stable_target_reads",2)):
        if mob != current_target:
            log(f"Target changed: {current_target!r} -> {mob!r}")
            current_target = mob
        if candidate_target_cl:
            current_target_cl = candidate_target_cl
        last_target_seen_at = time.time()

def plausible_zone_title(zone):
    zone = norm(zone)
    if not zone or not (4 <= len(zone) <= 40):
        return False
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9 '\-]{3,39}", zone):
        return False

    words = zone.split()
    if len(words) > 4:
        return False

    if re.search(
        r"\b(?:chat|group|options|help|emote|computer|credits|level|dist|"
        r"target|structure|quality)\b",
        zone, re.I
    ):
        return False

    if len(words) > 1 and zone.isupper():
        return False

    if len(words) == 1 and not (zone[0].isupper() and zone[1:].islower()):
        return False

    return True

def update_zone(text):
    global candidate_zone,candidate_zone_reads,current_zone

    zone = parse_zone(text)
    if not zone or not plausible_zone_title(zone):
        return

    if zone == candidate_zone:
        candidate_zone_reads += 1
    else:
        candidate_zone = zone
        candidate_zone_reads = 1

    if (
        candidate_zone_reads >= int(cfg["behavior"].get("stable_zone_reads",2))
        and zone != current_zone
    ):
        log(f"Zone changed: {current_zone!r} -> {zone!r}")
        current_zone = zone
        live_overlay["zone"] = current_zone
        live_overlay["kills"] = 0

def tick():
    global candidate_loot_text,candidate_loot_reads,last_logged_loot_hash,last_log_time
    global last_ocr_texts,last_ocr_items,last_scan_error
    global loot_session_active, loot_session_last_seen, loot_session_logged
    global hover_items_seen

    win = find_window()
    if not win:
        last_scan_error = "Earth & Beyond window not found."
        return

    images, texts = {}, {}

    # Target + loot area are sampled continuously.
    for name,key in (("target","target_psm"),("loot","loot_psm")):
        reg = absolute_region(win,name)
        if not reg:
            last_scan_error = f"{name.title()} is not calibrated."
            return
        images[name] = grab(reg)
        texts[name] = ocr(images[name], cfg["ocr"][key])

    # Deterministic EnB target title strip.
    fallback_mob, fallback_cl, target_fallback_raw = target_fallback_from_window(win)
    texts["target_title_raw"] = target_fallback_raw

    # Live Zone: always sample the exact same proven map-title strip used
    # by OCR Status/Test. This removes dependence on catching the M key.
    map_title, map_raw = map_title_from_window(win)
    texts["zone_title_raw"] = map_raw

    if map_title and plausible_zone_title(map_title):
        update_zone(map_title)
        if current_zone == map_title:
            live_overlay["zone"] = current_zone
            log(f"MAP LIVE OK title={map_title!r} overlay_zone={live_overlay['zone']!r}")
    elif map_zone_capture_active():
        reg = absolute_region(win, "zone")
        if reg:
            images["zone"] = grab(reg)
            texts["zone"] = ocr(images["zone"], cfg["ocr"]["zone_psm"])
            primary_zone = parse_zone(texts["zone"])
            if primary_zone and plausible_zone_title(primary_zone):
                update_zone(primary_zone)
        else:
            texts["zone"] = "<MAP ZONE NOT CALIBRATED>"
    else:
        texts["zone"] = "<map title not visible>"

    last_ocr_texts = dict(texts)
    last_scan_error = ""
    # Prefer the deterministic target-panel title/level. Calibrated OCR is secondary.
    if fallback_mob:
        update_target("", fallback_mob, fallback_cl)
    else:
        update_target(texts["target"])

    # User-hover tooltip is the authoritative item name source.
    hovered = update_hover_item(win)
    if hovered:
        last_ocr_items = [(name, 1) for name in hover_items_seen]

    raw_loot_active = loot_region_has_activity(texts["loot"])
    now = time.time()

    if raw_loot_active or hovered:
        loot_session_last_seen = now
        if not loot_session_active:
            loot_session_active = True
            loot_session_logged = False
            hover_items_seen = [hovered] if hovered else []
            log("Loot session opened.")
    elif loot_session_active and now - loot_session_last_seen > 1.25:
        # Corpse window disappeared. The next corpse becomes a fresh kill.
        log("Loot session closed.")
        reset_loot_session()
        return
    else:
        return

    # We log one kill per loot-session. Prefer waiting briefly for at least one
    # user-hovered tooltip, but zero-item kills remain possible after a delay.
    session_age = max(0.0, now - loot_session_last_seen)
    have_real_items = bool(hover_items_seen)

    if loot_session_logged:
        return

    if not have_real_items:
        # Do not use OCR garbage from the icon grid as drops.
        return

    if not current_target:
        # Excel can still retain the event without inventing a mob name.
        mob_value = "Unknown mob / target not read"
        cl_value = current_target_cl or ""
    else:
        mob_value = current_target
        cl_value = current_target_cl

    zone_value = current_zone or "Unknown / press M"
    items = [(name, 1) for name in hover_items_seen]
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    shot = save_capture(images,mob_value)

    kill = [
        ts, zone_value, mob_value, cl_value,
        len(items), shot,
        "User-hover tooltip OCR"
    ]
    drops = [
        [
            ts, zone_value, mob_value, cl_value,
            item, qty, "Review", "hover-tooltip",
            "Item name read from user-hover tooltip"
        ]
        for item,qty in items
    ]

    if append_rows(kill,drops):
        loot_session_logged = True
        last_log_time = now

        live_overlay["zone"] = zone_value
        live_overlay["kills"] = int(live_overlay.get("kills", 0)) + 1
        live_overlay["last_drop"] = ", ".join(name for name,_ in items[:3])

        log(
            f"LIVE+XLSX OK hover-tooltip zone={zone_value!r} "
            f"kills={live_overlay['kills']} mob={mob_value!r} "
            f"CL={cl_value!r} items={items!r}"
        )
        notify(
            "Loot logged",
            f"{zone_value} | Kill {live_overlay['kills']} | "
            f"{live_overlay['last_drop']}"
        )

def worker():
    global running
    while running:
        try:
            with state_lock:
                busy = calibrating
            if auto_enabled and not busy and calibration_complete():
                tick()
        except Exception as e:
            log(f"Scan error: {e!r}")
        time.sleep(float(cfg.get("scan_interval_seconds",0.6)))

def show_ocr_status(*_):
    try:
        win = find_window()
        if not win:
            message_box("EnB Droplist OCR Status", "Earth & Beyond window was not found.")
            return
        raw = {}
        for name,key in (("target","target_psm"),("loot","loot_psm"),("zone","zone_psm")):
            reg = absolute_region(win,name)
            raw[name] = "<NOT CALIBRATED>" if not reg else ocr(grab(reg), cfg["ocr"][key])

        fallback_mob, fallback_cl, target_fallback_raw = target_fallback_from_window(win)
        if fallback_mob:
            mob, cl = fallback_mob, fallback_cl
        else:
            mob, cl = parse_target(raw.get("target",""))

        zone = parse_zone(raw.get("zone",""))
        fallback_zone, map_fallback_raw = map_title_from_window(win)
        if not zone and fallback_zone:
            zone = fallback_zone

        hover_item, hover_raw = read_hover_item(win)
        # Icon-grid OCR is diagnostic only in 1.1.9.
        items = [(hover_item, 1)] if hover_item else []
        item_text = "\n".join(f"- {n} x{q}" for n,q in items[:8]) if items else "<no item lines parsed>"

        text = (
            f"TARGET RAW:\n{raw.get('target') or '<blank>'}\n\n"
            f"PARSED MOB: {mob or '<none>'}\n"
            f"PARSED CL/LVL: {cl or '<none>'}\n"
            f"TARGET TITLE STRIP RAW:\n{target_fallback_raw or '<blank>'}\n\n"
            f"ZONE RAW:\n{raw.get('zone') or '<blank>'}\n"
            f"MAP TITLE STRIP RAW:\n{map_fallback_raw or '<blank>'}\n\n"
            f"PARSED ZONE: {zone or '<none>'}\n\n"
            f"LOOT SLOT RAW (diagnostic only):\n{raw.get('loot') or '<blank>'}\n\n"
            f"HOVER TOOLTIP RAW:\n{hover_raw or '<hover a loot item first>'}\n\n"
            f"PARSED HOVER ITEM:\n{hover_item or '<none>'}\n\n"
            "For Zone: press M and leave the map open, then run this test. "
            "If a RAW section is blank or wrong, recalibrate that area."
        )
        log(f"OCR TEST target={raw.get('target')!r} mob={mob!r} cl={cl!r} "
            f"zone={raw.get('zone')!r} parsed_zone={zone!r} "
            f"loot_grid={raw.get('loot')!r} hover_raw={hover_raw!r} hover_item={hover_item!r}")
        message_box("EnB Droplist OCR Status / Test", text)
    except Exception as e:
        log(f"OCR status error: {e!r}")
        message_box("OCR Status failed", f"{type(e).__name__}: {e}")


def load_overlay_position():
    try:
        pos = cfg.get("overlay", {})
        return int(pos.get("x", 40)), int(pos.get("y", 40))
    except Exception:
        return 40, 40

def save_overlay_position(x, y):
    try:
        cfg.setdefault("overlay", {})
        cfg["overlay"]["x"] = int(x)
        cfg["overlay"]["y"] = int(y)
        CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"Overlay position save error: {e!r}")

def overlay_thread():
    try:
        root = tk.Tk()
        root.title("EnB Droplist Live")
        root.attributes("-topmost", True)
        root.overrideredirect(True)

        x, y = load_overlay_position()
        root.geometry(f"300x112+{x}+{y}")

        frame = tk.Frame(root, bd=1, relief="solid")
        frame.pack(fill="both", expand=True)

        zone_var = tk.StringVar(value="Zone: Unknown / not read")
        kills_var = tk.StringVar(value="Kills: 0")
        drop_var = tk.StringVar(value="Last drop: —")

        tk.Label(frame, textvariable=zone_var, anchor="w", font=("Segoe UI", 10, "bold")).pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(frame, textvariable=kills_var, anchor="w", font=("Segoe UI", 10)).pack(fill="x", padx=10, pady=2)
        tk.Label(frame, textvariable=drop_var, anchor="w", font=("Segoe UI", 10), wraplength=275, justify="left").pack(fill="x", padx=10, pady=(2, 8))

        drag = {"x": 0, "y": 0}
        visible = {"value": True}

        def drag_start(event):
            drag["x"] = event.x_root - root.winfo_x()
            drag["y"] = event.y_root - root.winfo_y()

        def drag_move(event):
            nx = event.x_root - drag["x"]
            ny = event.y_root - drag["y"]
            root.geometry(f"+{nx}+{ny}")

        def drag_end(_event):
            save_overlay_position(root.winfo_x(), root.winfo_y())

        for widget in (root, frame):
            widget.bind("<ButtonPress-1>", drag_start)
            widget.bind("<B1-Motion>", drag_move)
            widget.bind("<ButtonRelease-1>", drag_end)

        def poll():
            if overlay_stop_requested.is_set():
                save_overlay_position(root.winfo_x(), root.winfo_y())
                root.destroy()
                return

            if overlay_toggle_requested.is_set():
                overlay_toggle_requested.clear()
                visible["value"] = not visible["value"]
                if visible["value"]:
                    root.deiconify()
                    root.attributes("-topmost", True)
                else:
                    root.withdraw()

            zone_var.set(f"Zone: {live_overlay.get('zone') or 'Unknown / not read'}")
            kills_var.set(f"Kills: {int(live_overlay.get('kills', 0))}")
            drop_var.set(f"Last drop: {live_overlay.get('last_drop') or '—'}")
            root.after(250, poll)

        poll()
        root.mainloop()
    except Exception as e:
        log(f"Overlay error: {e!r}")

def toggle_overlay(*_):
    overlay_toggle_requested.set()

def hotkey_thread():
    try:
        user32 = ctypes.windll.user32
        hotkey_id = 0xB17
        vk_f8 = 0x77

        if not user32.RegisterHotKey(None, hotkey_id, 0, vk_f8):
            log("Overlay hotkey F8 could not be registered.")
            return

        msg = wintypes.MSG()
        wm_hotkey = 0x0312

        while running:
            result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if result <= 0:
                break
            if msg.message == wm_hotkey and msg.wParam == hotkey_id:
                overlay_toggle_requested.set()

        user32.UnregisterHotKey(None, hotkey_id)
    except Exception as e:
        log(f"Hotkey error: {e!r}")




def cursor_pos():
    try:
        pt = wintypes.POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return int(pt.x), int(pt.y)
    except Exception:
        return None

def point_in_region(pt, reg):
    if not pt or not reg:
        return False
    try:
        x, y = int(pt[0]), int(pt[1])
        if isinstance(reg, dict):
            left = int(reg["left"])
            top = int(reg["top"])
            right = left + int(reg["width"])
            bottom = top + int(reg["height"])
        else:
            left, top, right, bottom = [int(v) for v in reg]
        return left <= x <= right and top <= y <= bottom
    except Exception as e:
        log(f"point_in_region error: {e!r} pt={pt!r} reg={reg!r}")
        return False

def tooltip_capture_region(win):
    """
    Capture around the user's cursor while it is over the calibrated loot slots.
    EnB draws the item tooltip adjacent to the hovered icon.
    """
    pt = cursor_pos()
    if not pt:
        return None

    x, y = pt
    try:
        # pygetwindow coordinates are screen coordinates.
        sw = ctypes.windll.user32.GetSystemMetrics(0)
        sh = ctypes.windll.user32.GetSystemMetrics(1)
    except Exception:
        sw, sh = 1920, 1080

    left = max(0, x - 35)
    top = max(0, y - 85)
    right = min(sw, x + 330)
    bottom = min(sh, y + 155)
    if right - left < 80 or bottom - top < 50:
        return None
    return (left, top, right, bottom)

def preprocess_tooltip(img):
    """
    Tooltip text is green/bright on dark. grab() returns a cv2/numpy BGR image.
    """
    if img is None:
        return None
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    gray = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX)
    _, bw = cv2.threshold(gray, 105, 255, cv2.THRESH_BINARY)
    return bw

def ocr_tooltip(img):
    try:
        proc = preprocess_tooltip(img)
        return norm(pytesseract.image_to_string(proc, config="--psm 6"))
    except Exception as e:
        log(f"Tooltip OCR error: {e!r}")
        return ""

def parse_tooltip_item(text):
    """
    Extract the item name from an EnB hover tooltip.

    Example:
      Nova Go-Gel
      Structure 100%
      Quality 100%
    => Nova Go-Gel
    """
    raw_lines = [norm(x) for x in str(text or "").replace("\r", "\n").split("\n")]
    lines = [x for x in raw_lines if x]

    reject = re.compile(
        r"^(?:"
        r"structure|quality|durability|condition|range|damage|energy|"
        r"reload|capacity|level|tech\s*level|manufacturer|race|class|"
        r"tradable|stack|value|credits?|required|restriction"
        r")\b",
        re.I,
    )

    for line in lines:
        line = re.sub(r"^[\[\]{}()|:;.,'\"`~_+=*<>!?\\/\-]+\s*", "", line)
        line = re.sub(r"\s+", " ", line).strip()

        if not line or reject.search(line):
            continue
        if re.fullmatch(r"[\d\s%+./:_\-]+", line):
            continue
        if re.search(r"\b(?:100%|0%|structure|quality)\b", line, re.I):
            continue
        # Real names need at least two letters.
        if len(re.findall(r"[A-Za-z]", line)) < 2:
            continue
        # Reject OCR icon garbage with too many symbols.
        alnum = len(re.findall(r"[A-Za-z0-9]", line))
        if alnum / max(len(line), 1) < 0.55:
            continue
        return line[:100]

    return ""

def read_hover_item(win):
    """
    Only reads a tooltip while the user's own mouse is inside the calibrated
    loot region. No cursor movement/clicking is performed.
    """
    loot_reg = absolute_region(win, "loot")
    pt = cursor_pos()
    if not point_in_region(pt, loot_reg):
        return "", ""

    cap = tooltip_capture_region(win)
    if not cap:
        return "", ""

    img = grab(cap)
    raw = ocr_tooltip(img)
    return parse_tooltip_item(raw), raw

def update_hover_item(win):
    global hover_item_candidate, hover_item_reads, hover_items_seen

    item, raw = read_hover_item(win)
    if not item:
        hover_item_candidate = ""
        hover_item_reads = 0
        return ""

    if item == hover_item_candidate:
        hover_item_reads += 1
    else:
        hover_item_candidate = item
        hover_item_reads = 1

    # Two agreeing reads suppress one-frame tooltip noise.
    if hover_item_reads < 2:
        return ""

    if item not in hover_items_seen:
        hover_items_seen.append(item)
        log(f"HOVER ITEM: {item!r} raw={raw!r}")

    # Live means live: show the stable item as soon as it is recognised.
    live_overlay["last_drop"] = item
    return item

def reset_loot_session():
    global hover_item_candidate, hover_item_reads, hover_items_seen
    global loot_session_active, loot_session_logged
    hover_item_candidate = ""
    hover_item_reads = 0
    hover_items_seen = []
    loot_session_active = False
    loot_session_logged = False

def loot_region_has_activity(raw_text):
    """
    The slots themselves are image-heavy, so their OCR is not used as item text.
    We only use a loose non-empty signal to tell whether a corpse/loot window is
    probably present. Tooltip recognition is the authoritative item source.
    """
    s = norm(raw_text)
    if not s:
        return False
    # Require at least a small amount of visible OCR signal.
    return len(re.sub(r"\s+", "", s)) >= 2


def map_key_thread():
    """Passively watch the M key without stealing it from Earth & Beyond."""
    global map_zone_capture_until
    try:
        user32 = ctypes.windll.user32
        VK_M = 0x4D
        was_down = False

        while running:
            down = bool(user32.GetAsyncKeyState(VK_M) & 0x8000)
            if down and not was_down:
                # Give the game a moment to render the map. Keep sampling for
                # several seconds, so slow map animation/OCR still works.
                map_zone_capture_until = time.time() + 4.0
                log("M key detected: map-zone OCR window opened for 4 seconds.")
            was_down = down
            time.sleep(0.03)
    except Exception as e:
        log(f"Map key watcher error: {e!r}")

def map_zone_capture_active():
    return time.time() <= map_zone_capture_until


def toggle_pause(icon_obj=None,item=None):
    global auto_enabled
    auto_enabled = not auto_enabled
    notify(
        "EnB Drop Logger",
        "Automatic logging resumed." if auto_enabled else "Automatic logging paused."
    )

def open_folder(*_):
    subprocess.Popen(["explorer", str(BASE)])

def exit_app(icon_obj=None,item=None):
    global running
    running = False
    try:
        icon.stop()
    except Exception:
        pass


def install_update(manifest):
    global running
    try:
        ver = manifest.get("version", "?")
        message_box("EnB Droplist",
                    f"Downloading and installing update {ver}.\n\n"
                    "EnB Droplist will close and restart automatically.")
        auto_updater.launch_install(manifest, BASE, BASE / "run_logger_tray.bat")
        running = False
        try:
            icon.stop()
        except Exception:
            pass
    except Exception as e:
        log(f"Update install error: {e!r}")
        message_box("Update failed", f"{type(e).__name__}: {e}\n\nSee logger_status.txt.")

def check_updates(manual=False):
    def work():
        try:
            manifest = auto_updater.check_for_update()
            if not manifest:
                msg = f"You already have the latest version ({auto_updater.CURRENT_VERSION})."
                log(msg)
                if manual:
                    message_box("EnB Droplist - Update", msg)
                return

            ver = str(manifest.get("version", "?"))
            notes = str(manifest.get("release_notes", "")).strip()
            log(f"Update available: {ver}")

            if not manual:
                notify("EnB Droplist update available",
                       f"Version {ver} is available. Use Check for Update to install.")
                return

            prompt = (f"EnB Droplist {ver} is available.\n\n"
                      f"Current version: {auto_updater.CURRENT_VERSION}\n\n")
            if notes:
                prompt += f"What's new:\n{notes[:600]}\n\n"
            prompt += "Install this update now?"

            if ask_yes_no("EnB Droplist - Update available", prompt):
                install_update(manifest)
            else:
                log(f"User postponed update {ver}.")
                message_box("EnB Droplist", "Update postponed.")
        except Exception as e:
            log(f"Update check error: {e!r}")
            if manual:
                message_box("Update check failed",
                            f"Could not check soulbound.se.\n\n{type(e).__name__}: {e}")
    threading.Thread(target=work, daemon=True).start()

def icon_image():
    im = Image.new("RGB",(64,64),(20,35,55))
    d = ImageDraw.Draw(im)
    d.ellipse((8,8,56,56), outline=(220,230,240), width=4)
    d.text((18,20),"E&B",fill=(255,255,255))
    return im

menu = pystray.Menu(
    pystray.MenuItem("Pause / Resume", toggle_pause),
    pystray.MenuItem("OCR Status / Test", show_ocr_status),
    pystray.MenuItem("Live Overlay (F8)", toggle_overlay),
    pystray.MenuItem("Guided Calibration", guided_calibration),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem(
        "Recalibrate Target",
        lambda *_: single_calibration(
            "target",
            "TARGET: select mob name / CL, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Loot",
        lambda *_: single_calibration(
            "loot",
            "LOOT: select corpse item list, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Map Zone",
        lambda *_: single_calibration(
            "zone",
            "MAP ZONE: press M first, then select the zone/sector name, ENTER to save"
        )
    ),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem("Check for Update", lambda *_: check_updates(True)),
    pystray.MenuItem("Open Logger Folder", open_folder),
    pystray.MenuItem("Exit", exit_app)
)

icon = pystray.Icon(
    "EnBDopList",
    icon_image(),
    "EnB Droplist",
    menu
)

log("Tray logger 1.1.15 started.")
threading.Thread(target=map_key_thread, daemon=True).start()
threading.Thread(target=overlay_thread, daemon=True).start()
threading.Thread(target=hotkey_thread, daemon=True).start()
threading.Thread(target=lambda: (time.sleep(1), show_update_complete_if_needed()), daemon=True).start()
threading.Thread(target=worker, daemon=True).start()

def delayed_update_check():
    time.sleep(5)
    check_updates(False)
threading.Thread(target=delayed_update_check, daemon=True).start()

if not calibration_complete():
    def delayed_first_run():
        time.sleep(2)
        notify("EnB Drop Logger", "First run: starting one-time calibration.")
        guided_calibration()
    threading.Thread(target=delayed_first_run, daemon=True).start()

icon.run()
overlay_stop_requested.set()
log("Tray logger 1.1.15 stopped.")

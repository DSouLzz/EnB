"""
EnB Droplist — Background Tray Edition v2

Fixes:
- Calibration runs in a separate process, so OpenCV selection cannot freeze the tray app.
- Successful loot captures show a tray notification.
"""
from __future__ import annotations
import json, re, time, hashlib, threading, subprocess, sys, ctypes
from datetime import datetime
from pathlib import Path

import cv2
import mss
import numpy as np
import pytesseract
import tkinter as tk
from ctypes import wintypes
import pygetwindow as gw
from openpyxl import load_workbook
from PIL import Image, ImageDraw
import pystray
import auto_updater

BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config.json"
LOG_PATH = BASE / "logger_status.txt"
CAPTURE_DIR = BASE / "captures"
CAPTURE_DIR.mkdir(exist_ok=True)

with CFG_PATH.open("r", encoding="utf-8") as f:
    cfg = json.load(f)

pytesseract.pytesseract.tesseract_cmd = cfg["ocr"]["tesseract_cmd"]

running = True
auto_enabled = bool(cfg["behavior"].get("automatic", True))
calibrating = False
state_lock = threading.Lock()

current_target = ""
current_target_cl = ""
current_zone = ""
last_target_seen_at = 0.0

candidate_target = ""
candidate_target_cl = ""
candidate_target_reads = 0
candidate_zone = ""
candidate_zone_reads = 0
candidate_loot_text = ""
candidate_loot_reads = 0
last_logged_loot_hash = ""
last_log_time = 0.0
last_ocr_texts = {"target":"","loot":"","zone":""}
last_ocr_items = []
last_scan_error = ""

live_overlay = {
    "zone": "Unknown / not read",
    "kills": 0,
    "last_drop": "—",
}
overlay_toggle_requested = threading.Event()
overlay_stop_requested = threading.Event()

# Pressing M in-game does not get intercepted. We only observe the key state,
# then OCR the calibrated map-zone title for a few seconds while the map is open.
map_zone_capture_until = 0.0

def reload_config():
    global cfg
    try:
        with CFG_PATH.open("r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as e:
        log(f"Config reload error: {e!r}")

def log(msg):
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(f"[{stamp}] {msg}\n")
    except Exception:
        pass

def notify(title, msg):
    try:
        icon.notify(msg, title)
    except Exception as e:
        log(f"Notification error: {e!r}")
    log(f"{title}: {msg}")

def message_box(title, text, flags=0x00000040):
    try:
        return ctypes.windll.user32.MessageBoxW(None, str(text), str(title), flags)
    except Exception as e:
        log(f"MessageBox error: {e!r}")
        notify(title, text)
        return 0

def ask_yes_no(title, text):
    return message_box(title, text, 0x00000004 | 0x00000020) == 6

def show_update_complete_if_needed():
    marker = BASE / "update_completed.json"
    if not marker.exists():
        return
    try:
        info = json.loads(marker.read_text(encoding="utf-8"))
        ver = info.get("version", auto_updater.CURRENT_VERSION)
        marker.unlink(missing_ok=True)
        message_box("EnB Droplist updated",
                    f"Update {ver} was installed successfully.\n\n"
                    "Your calibration, config, captures and drop database were preserved.")
    except Exception as e:
        log(f"Update completion marker error: {e!r}")

def find_window():
    needle = cfg["window_title_contains"].lower()
    wins = [
        w for w in gw.getAllWindows()
        if needle in (w.title or "").lower() and w.width > 0 and w.height > 0
    ]
    return wins[0] if wins else None

def grab(region):
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

def absolute_region(win, name):
    r = cfg["regions"].get(name)
    if not r:
        return None
    return {
        "left": int(win.left + r["left"]),
        "top": int(win.top + r["top"]),
        "width": max(1, int(r["width"])),
        "height": max(1, int(r["height"]))
    }

def prep(img, scale=2):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 31, 9
    )

def ocr(img, psm):
    txt = pytesseract.image_to_string(prep(img), config=f"--psm {psm}")
    return "\n".join(x.strip() for x in txt.splitlines() if x.strip())

def norm(s):
    return re.sub(r"\s+", " ", s or "").strip(" |[]-:")

def parse_target(text):
    clean = norm(text)
    if not clean:
        return "", ""
    cl = ""
    for pat in (
        r"\b(?:CL|Combat\s*Level|Combat|Level|Lvl)\s*[:#\-]?\s*(\d{1,3})\b",
        r"\[\s*(?:CL\s*)?(\d{1,3})\s*\]",
    ):
        m = re.search(pat, clean, re.I)
        if m:
            cl = m.group(1)
            clean = norm(clean[:m.start()] + " " + clean[m.end():])
            break
    clean = re.sub(r"\b(?:Target|Hull|Shield|Structure|Range|Distance)\b\s*:?", "",
                   clean, flags=re.I)
    clean = norm(clean)
    if not (2 <= len(clean) <= 80) or re.fullmatch(r"[\d\s%./]+", clean):
        return "", cl
    if re.search(r"\b(?:privacy|personal information|cookie|email address|unsubscribe|http|www\.)\b", clean, re.I):
        return "", cl
    return clean[:80], cl

def parse_zone(text):
    clean = norm(text)
    if not clean:
        return ""
    clean = re.sub(
        r"^(?:Current\s*)?(?:Sector|Zone|Location|System|Area)\s*[:\-]?\s*",
        "", clean, flags=re.I)
    clean = norm(clean)
    if not (2 <= len(clean) <= 80) or re.fullmatch(r"[\d\s%./]+", clean):
        return ""
    if re.search(r"\b(?:privacy|personal information|cookie|email address|unsubscribe|http|www\.)\b", clean, re.I):
        return ""
    return clean

def parse_loot(text):
    rows, seen = [], set()
    for raw in text.splitlines():
        line = norm(raw)
        if len(line) < 2:
            continue
        if re.search(
            r"\b(?:loot|cargo|close|take all|inventory|credits?|capacity|free space)\b",
            line, re.I
        ):
            continue
        qty, item = 1, line
        m = re.match(r"^(\d+)\s*[xX]\s+(.+)$", line)
        if m:
            qty, item = int(m.group(1)), m.group(2)
        else:
            m = re.match(r"^(.+?)\s+[xX]\s*(\d+)$", line)
            if m:
                item, qty = m.group(1), int(m.group(2))
        item = norm(item)
        if item and item.lower() not in seen:
            seen.add(item.lower())
            rows.append((item[:120], qty))
    return rows

def loot_panel_present(raw_text, items):
    if items:
        return True
    raw = norm(raw_text)
    if not raw:
        return False
    return bool(re.search(r"\b(?:loot|corpse|cargo|take\s*all|no\s*loot|nothing|empty)\b",
                          raw, re.I))


def calibration_complete():
    return all(cfg["regions"].get(x) for x in ("target","loot","zone"))

def run_calibration_step(name, prompt):
    global calibrating
    with state_lock:
        if calibrating:
            notify("EnB Drop Logger", "Calibration is already running.")
            return False
        calibrating = True

    try:
        notify("Calibration", f"Select the {name} area in Earth & Beyond.")
        python_exe = sys.executable

        # When the tray runs under pythonw.exe, launch helper with python.exe
        # so OpenCV's window has a normal GUI-capable child process.
        if python_exe.lower().endswith("pythonw.exe"):
            candidate = python_exe[:-5] + ".exe"
            if Path(candidate).exists():
                python_exe = candidate

        result = subprocess.run(
            [python_exe, str(BASE / "calibrate_helper.py"), name, prompt],
            cwd=str(BASE),
            timeout=300,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )

        if result.returncode == 0:
            reload_config()
            notify("Calibration saved", f"{name.title()} area saved.")
            return True
        elif result.returncode == 3:
            notify("Calibration failed", "Earth & Beyond window was not found.")
        elif result.returncode == 4:
            notify("Calibration cancelled", f"{name.title()} selection was cancelled.")
        else:
            notify("Calibration failed", f"{name.title()} helper returned code {result.returncode}.")
        return False

    except subprocess.TimeoutExpired:
        notify("Calibration cancelled", "Calibration timed out after 5 minutes.")
        return False
    except Exception as e:
        log(f"Calibration helper error: {e!r}")
        notify("Calibration failed", "See logger_status.txt for details.")
        return False
    finally:
        with state_lock:
            calibrating = False

def guided_calibration(*_):
    def work():
        if not run_calibration_step("target", "1/3 TARGET: select mob name / CL, ENTER to save"):
            return
        if not run_calibration_step("loot", "2/3 LOOT: select corpse item list, ENTER to save"):
            return
        if not run_calibration_step("zone", "3/3 MAP ZONE: press M first, then select the zone/sector name, ENTER to save"):
            return
        notify("EnB Drop Logger", "Calibration complete. Automatic logging resumed.")
    threading.Thread(target=work, daemon=True).start()

def single_calibration(name, prompt):
    threading.Thread(
        target=lambda: run_calibration_step(name, prompt),
        daemon=True
    ).start()

def save_capture(images, mob):
    if not cfg["behavior"].get("save_capture_on_log", True):
        return ""
    imgs = [images.get("zone"), images.get("target"), images.get("loot")]
    imgs = [x for x in imgs if x is not None]
    if not imgs:
        return ""
    h = max(x.shape[0] for x in imgs)
    w = sum(x.shape[1] for x in imgs)
    canvas = np.zeros((h,w,3), dtype=np.uint8)
    pos = 0
    for im in imgs:
        canvas[:im.shape[0], pos:pos+im.shape[1]] = im
        pos += im.shape[1]
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^A-Za-z0-9_-]+","_",mob or "unknown")[:40]
    p = CAPTURE_DIR / f"{stamp}_{safe}.png"
    cv2.imwrite(str(p), canvas)
    return str(p)

def rebuild_summary(wb):
    ws = wb["Summary"]
    kd, agg = {}, {}
    for row in wb["Kills"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        if mob:
            kd[mob] = kd.get(mob, 0) + 1

    for row in wb["Drops"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        item = str(row[4] or "").strip()
        try:
            qty = int(row[5] or 1)
        except Exception:
            qty = 1
        if mob and item:
            rec = agg.setdefault((mob,item), [0,0])
            rec[0] += 1
            rec[1] += qty

    # Replace the generated summary area cleanly. The starter workbook has
    # merged instruction rows below row 2; writing to those MergedCell objects
    # raises "value is read-only" in openpyxl. Unmerge/remove that area first.
    for merged in list(ws.merged_cells.ranges):
        if merged.min_row >= 3:
            ws.unmerge_cells(str(merged))
    if ws.max_row >= 3:
        ws.delete_rows(3, ws.max_row - 2)

    for (mob,item),(events,qty) in sorted(agg.items()):
        kills = kd.get(mob,0)
        ws.append([
            mob, item, events, kills,
            (events/kills if kills else 0),
            qty, "Observed sample"
        ])
        ws.cell(ws.max_row,5).number_format = "0.0%"

def append_rows(kill, drops):
    path = (BASE / cfg["excel_file"]).resolve()
    if not path.exists():
        notify("EnB Drop Logger", "Database XLSX is missing.")
        log(f"XLSX FAIL missing file: {path}")
        return False

    try:
        wb = load_workbook(path)
        kills_ws = wb["Kills"]
        drops_ws = wb["Drops"]

        kills_ws.append(kill)
        kill_row = kills_ws.max_row

        for r in drops:
            drops_ws.append(r)

        rebuild_summary(wb)
        wb.save(path)
        wb.close()

        # Verify the just-written kill row can be read back from disk.
        verify = load_workbook(path, read_only=True, data_only=False)
        ws = verify["Kills"]
        saved_ts = ws.cell(kill_row, 1).value
        saved_zone = ws.cell(kill_row, 2).value
        saved_mob = ws.cell(kill_row, 3).value
        verify.close()

        ok = (
            str(saved_ts or "") == str(kill[0] or "")
            and str(saved_zone or "") == str(kill[1] or "")
            and str(saved_mob or "") == str(kill[2] or "")
        )

        if not ok:
            log(f"XLSX VERIFY FAIL row={kill_row} expected={kill[:3]!r} "
                f"readback={[saved_ts,saved_zone,saved_mob]!r}")
            notify("EnB Drop Logger", "XLSX save verification failed. See logger_status.txt.")
            return False

        log(f"XLSX SAVED+VERIFIED kill_row={kill_row} drop_rows={len(drops)} "
            f"zone={kill[1]!r} mob={kill[2]!r}")
        return True

    except PermissionError:
        notify("Database is open", "Close the XLSX in Excel/OpenOffice while logging.")
        log("XLSX FAIL: file is locked/open in another program.")
        return False
    except Exception as e:
        log(f"Workbook error: {e!r}")
        return False

def update_target(text):
    global candidate_target,candidate_target_cl,candidate_target_reads
    global current_target,current_target_cl,last_target_seen_at

    mob, cl = parse_target(text)
    if not mob:
        return

    if mob == candidate_target:
        candidate_target_reads += 1
        if cl:
            candidate_target_cl = cl
    else:
        candidate_target = mob
        candidate_target_cl = cl
        candidate_target_reads = 1

    if candidate_target_reads >= int(cfg["behavior"].get("stable_target_reads",2)):
        if mob != current_target:
            log(f"Target changed: {current_target!r} -> {mob!r}")
            current_target = mob
        if candidate_target_cl:
            current_target_cl = candidate_target_cl
        last_target_seen_at = time.time()

def update_zone(text):
    global candidate_zone,candidate_zone_reads,current_zone

    zone = parse_zone(text)
    if not zone:
        return

    if zone == candidate_zone:
        candidate_zone_reads += 1
    else:
        candidate_zone = zone
        candidate_zone_reads = 1

    if (
        candidate_zone_reads >= int(cfg["behavior"].get("stable_zone_reads",2))
        and zone != current_zone
    ):
        log(f"Zone changed: {current_zone!r} -> {zone!r}")
        current_zone = zone

def tick():
    global candidate_loot_text,candidate_loot_reads,last_logged_loot_hash,last_log_time
    global last_ocr_texts,last_ocr_items,last_scan_error

    win = find_window()
    if not win:
        last_scan_error = "Earth & Beyond window not found."
        return

    images, texts = {}, {}

    # Target and loot are read continuously for near-realtime logging.
    for name,key in (("target","target_psm"),("loot","loot_psm")):
        reg = absolute_region(win,name)
        if not reg:
            last_scan_error = f"{name.title()} is not calibrated."
            return
        images[name] = grab(reg)
        texts[name] = ocr(images[name], cfg["ocr"][key])

    # Zone is deliberately map-driven. This avoids reading random UI text from
    # the same screen position during ordinary gameplay.
    if map_zone_capture_active():
        reg = absolute_region(win,"zone")
        if reg:
            images["zone"] = grab(reg)
            texts["zone"] = ocr(images["zone"], cfg["ocr"]["zone_psm"])
            update_zone(texts["zone"])
        else:
            texts["zone"] = "<MAP ZONE NOT CALIBRATED>"
    else:
        texts["zone"] = "<waiting for M map>"

    last_ocr_texts = dict(texts)
    last_scan_error = ""

    update_target(texts["target"])

    items = parse_loot(texts["loot"])
    last_ocr_items = list(items)

    if not loot_panel_present(texts["loot"], items):
        candidate_loot_text = ""
        candidate_loot_reads = 0
        return

    canonical = ("\n".join(f"{i}|{q}" for i,q in items)
                 if items else "EMPTY_LOOT|" + norm(texts["loot"]).lower())

    if canonical == candidate_loot_text:
        candidate_loot_reads += 1
    else:
        candidate_loot_text = canonical
        candidate_loot_reads = 1

    if candidate_loot_reads < int(cfg["behavior"].get("loot_stable_reads",2)):
        return

    sig = hashlib.sha1(canonical.lower().encode("utf-8")).hexdigest()
    if sig == last_logged_loot_hash:
        return

    now = time.time()
    if now - last_log_time < float(cfg["behavior"].get("loot_event_cooldown_seconds",2.0)):
        return

    if not current_target:
        last_scan_error = "Loot detected but no stable mob target was recognized."
        log(last_scan_error)
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    shot = save_capture(images,current_target)
    zone_value = current_zone or "Unknown / press M"

    kill = [ts,zone_value,current_target,current_target_cl,len(items),shot,
            "Background automatic OCR" if items else "Loot/corpse detected; zero parsed item lines"]
    drops = [[ts,zone_value,current_target,current_target_cl,item,qty,
              "Review","automatic","OCR; screenshot saved for verification"]
             for item,qty in items]

    result = append_rows(kill,drops)
    if result:
        last_logged_loot_hash = sig
        last_log_time = now

        # The live overlay is updated only AFTER the workbook confirms a save.
        live_overlay["zone"] = zone_value
        live_overlay["kills"] = int(live_overlay.get("kills", 0)) + 1
        if items:
            live_overlay["last_drop"] = ", ".join(
                f"{name} x{qty}" for name, qty in items[:3]
            )
        else:
            live_overlay["last_drop"] = "No parsed drop"

        log(f"LIVE+XLSX OK zone={zone_value!r} kills={live_overlay['kills']} "
            f"mob={current_target!r} CL={current_target_cl!r} items={items!r}")

        if items:
            notify(f"Logged: {current_target}",
                   f"CL {current_target_cl or '?'} | {zone_value} | {len(items)} item types")
        else:
            notify(f"Logged kill: {current_target}",
                   f"CL {current_target_cl or '?'} | {zone_value} | no item lines parsed")

def worker():
    global running
    while running:
        try:
            with state_lock:
                busy = calibrating
            if auto_enabled and not busy and calibration_complete():
                tick()
        except Exception as e:
            log(f"Scan error: {e!r}")
        time.sleep(float(cfg.get("scan_interval_seconds",0.6)))

def show_ocr_status(*_):
    try:
        win = find_window()
        if not win:
            message_box("EnB Droplist OCR Status", "Earth & Beyond window was not found.")
            return
        raw = {}
        for name,key in (("target","target_psm"),("loot","loot_psm"),("zone","zone_psm")):
            reg = absolute_region(win,name)
            raw[name] = "<NOT CALIBRATED>" if not reg else ocr(grab(reg), cfg["ocr"][key])

        mob, cl = parse_target(raw.get("target",""))
        zone = parse_zone(raw.get("zone",""))
        items = parse_loot(raw.get("loot",""))
        item_text = "\n".join(f"- {n} x{q}" for n,q in items[:8]) if items else "<no item lines parsed>"

        text = (
            f"TARGET RAW:\n{raw.get('target') or '<blank>'}\n\n"
            f"PARSED MOB: {mob or '<none>'}\n"
            f"PARSED CL/LVL: {cl or '<none>'}\n\n"
            f"ZONE RAW:\n{raw.get('zone') or '<blank>'}\n\n"
            f"PARSED ZONE: {zone or '<none>'}\n\n"
            f"LOOT RAW:\n{raw.get('loot') or '<blank>'}\n\n"
            f"PARSED ITEMS:\n{item_text}\n\n"
            "For Zone: press M and leave the map open, then run this test. "
            "If a RAW section is blank or wrong, recalibrate that area."
        )
        log(f"OCR TEST target={raw.get('target')!r} mob={mob!r} cl={cl!r} "
            f"zone={raw.get('zone')!r} parsed_zone={zone!r} "
            f"loot={raw.get('loot')!r} items={items!r}")
        message_box("EnB Droplist OCR Status / Test", text)
    except Exception as e:
        log(f"OCR status error: {e!r}")
        message_box("OCR Status failed", f"{type(e).__name__}: {e}")


def load_overlay_position():
    try:
        pos = cfg.get("overlay", {})
        return int(pos.get("x", 40)), int(pos.get("y", 40))
    except Exception:
        return 40, 40

def save_overlay_position(x, y):
    try:
        cfg.setdefault("overlay", {})
        cfg["overlay"]["x"] = int(x)
        cfg["overlay"]["y"] = int(y)
        CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"Overlay position save error: {e!r}")

def overlay_thread():
    try:
        root = tk.Tk()
        root.title("EnB Droplist Live")
        root.attributes("-topmost", True)
        root.overrideredirect(True)

        x, y = load_overlay_position()
        root.geometry(f"300x112+{x}+{y}")

        frame = tk.Frame(root, bd=1, relief="solid")
        frame.pack(fill="both", expand=True)

        zone_var = tk.StringVar(value="Zone: Unknown / not read")
        kills_var = tk.StringVar(value="Kills: 0")
        drop_var = tk.StringVar(value="Last drop: —")

        tk.Label(frame, textvariable=zone_var, anchor="w", font=("Segoe UI", 10, "bold")).pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(frame, textvariable=kills_var, anchor="w", font=("Segoe UI", 10)).pack(fill="x", padx=10, pady=2)
        tk.Label(frame, textvariable=drop_var, anchor="w", font=("Segoe UI", 10), wraplength=275, justify="left").pack(fill="x", padx=10, pady=(2, 8))

        drag = {"x": 0, "y": 0}
        visible = {"value": True}

        def drag_start(event):
            drag["x"] = event.x_root - root.winfo_x()
            drag["y"] = event.y_root - root.winfo_y()

        def drag_move(event):
            nx = event.x_root - drag["x"]
            ny = event.y_root - drag["y"]
            root.geometry(f"+{nx}+{ny}")

        def drag_end(_event):
            save_overlay_position(root.winfo_x(), root.winfo_y())

        for widget in (root, frame):
            widget.bind("<ButtonPress-1>", drag_start)
            widget.bind("<B1-Motion>", drag_move)
            widget.bind("<ButtonRelease-1>", drag_end)

        def poll():
            if overlay_stop_requested.is_set():
                save_overlay_position(root.winfo_x(), root.winfo_y())
                root.destroy()
                return

            if overlay_toggle_requested.is_set():
                overlay_toggle_requested.clear()
                visible["value"] = not visible["value"]
                if visible["value"]:
                    root.deiconify()
                    root.attributes("-topmost", True)
                else:
                    root.withdraw()

            zone_var.set(f"Zone: {live_overlay.get('zone') or 'Unknown / not read'}")
            kills_var.set(f"Kills: {int(live_overlay.get('kills', 0))}")
            drop_var.set(f"Last drop: {live_overlay.get('last_drop') or '—'}")
            root.after(250, poll)

        poll()
        root.mainloop()
    except Exception as e:
        log(f"Overlay error: {e!r}")

def toggle_overlay(*_):
    overlay_toggle_requested.set()

def hotkey_thread():
    try:
        user32 = ctypes.windll.user32
        hotkey_id = 0xB17
        vk_f8 = 0x77

        if not user32.RegisterHotKey(None, hotkey_id, 0, vk_f8):
            log("Overlay hotkey F8 could not be registered.")
            return

        msg = wintypes.MSG()
        wm_hotkey = 0x0312

        while running:
            result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if result <= 0:
                break
            if msg.message == wm_hotkey and msg.wParam == hotkey_id:
                overlay_toggle_requested.set()

        user32.UnregisterHotKey(None, hotkey_id)
    except Exception as e:
        log(f"Hotkey error: {e!r}")



def map_key_thread():
    """Passively watch the M key without stealing it from Earth & Beyond."""
    global map_zone_capture_until
    try:
        user32 = ctypes.windll.user32
        VK_M = 0x4D
        was_down = False

        while running:
            down = bool(user32.GetAsyncKeyState(VK_M) & 0x8000)
            if down and not was_down:
                # Give the game a moment to render the map. Keep sampling for
                # several seconds, so slow map animation/OCR still works.
                map_zone_capture_until = time.time() + 4.0
                log("M key detected: map-zone OCR window opened for 4 seconds.")
            was_down = down
            time.sleep(0.03)
    except Exception as e:
        log(f"Map key watcher error: {e!r}")

def map_zone_capture_active():
    return time.time() <= map_zone_capture_until


def toggle_pause(icon_obj=None,item=None):
    global auto_enabled
    auto_enabled = not auto_enabled
    notify(
        "EnB Drop Logger",
        "Automatic logging resumed." if auto_enabled else "Automatic logging paused."
    )

def open_folder(*_):
    subprocess.Popen(["explorer", str(BASE)])

def exit_app(icon_obj=None,item=None):
    global running
    running = False
    try:
        icon.stop()
    except Exception:
        pass


def install_update(manifest):
    global running
    try:
        ver = manifest.get("version", "?")
        message_box("EnB Droplist",
                    f"Downloading and installing update {ver}.\n\n"
                    "EnB Droplist will close and restart automatically.")
        auto_updater.launch_install(manifest, BASE, BASE / "run_logger_tray.bat")
        running = False
        try:
            icon.stop()
        except Exception:
            pass
    except Exception as e:
        log(f"Update install error: {e!r}")
        message_box("Update failed", f"{type(e).__name__}: {e}\n\nSee logger_status.txt.")

def check_updates(manual=False):
    def work():
        try:
            manifest = auto_updater.check_for_update()
            if not manifest:
                msg = f"You already have the latest version ({auto_updater.CURRENT_VERSION})."
                log(msg)
                if manual:
                    message_box("EnB Droplist - Update", msg)
                return

            ver = str(manifest.get("version", "?"))
            notes = str(manifest.get("release_notes", "")).strip()
            log(f"Update available: {ver}")

            if not manual:
                notify("EnB Droplist update available",
                       f"Version {ver} is available. Use Check for Update to install.")
                return

            prompt = (f"EnB Droplist {ver} is available.\n\n"
                      f"Current version: {auto_updater.CURRENT_VERSION}\n\n")
            if notes:
                prompt += f"What's new:\n{notes[:600]}\n\n"
            prompt += "Install this update now?"

            if ask_yes_no("EnB Droplist - Update available", prompt):
                install_update(manifest)
            else:
                log(f"User postponed update {ver}.")
                message_box("EnB Droplist", "Update postponed.")
        except Exception as e:
            log(f"Update check error: {e!r}")
            if manual:
                message_box("Update check failed",
                            f"Could not check soulbound.se.\n\n{type(e).__name__}: {e}")
    threading.Thread(target=work, daemon=True).start()

def icon_image():
    im = Image.new("RGB",(64,64),(20,35,55))
    d = ImageDraw.Draw(im)
    d.ellipse((8,8,56,56), outline=(220,230,240), width=4)
    d.text((18,20),"E&B",fill=(255,255,255))
    return im

menu = pystray.Menu(
    pystray.MenuItem("Pause / Resume", toggle_pause),
    pystray.MenuItem("OCR Status / Test", show_ocr_status),
    pystray.MenuItem("Live Overlay (F8)", toggle_overlay),
    pystray.MenuItem("Guided Calibration", guided_calibration),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem(
        "Recalibrate Target",
        lambda *_: single_calibration(
            "target",
            "TARGET: select mob name / CL, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Loot",
        lambda *_: single_calibration(
            "loot",
            "LOOT: select corpse item list, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Map Zone",
        lambda *_: single_calibration(
            "zone",
            "MAP ZONE: press M first, then select the zone/sector name, ENTER to save"
        )
    ),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem("Check for Update", lambda *_: check_updates(True)),
    pystray.MenuItem("Open Logger Folder", open_folder),
    pystray.MenuItem("Exit", exit_app)
)

icon = pystray.Icon(
    "EnBDopList",
    icon_image(),
    "EnB Droplist",
    menu
)

log("Tray logger 1.1.8 started.")
threading.Thread(target=map_key_thread, daemon=True).start()
threading.Thread(target=overlay_thread, daemon=True).start()
threading.Thread(target=hotkey_thread, daemon=True).start()
threading.Thread(target=lambda: (time.sleep(1), show_update_complete_if_needed()), daemon=True).start()
threading.Thread(target=worker, daemon=True).start()

def delayed_update_check():
    time.sleep(5)
    check_updates(False)
threading.Thread(target=delayed_update_check, daemon=True).start()

if not calibration_complete():
    def delayed_first_run():
        time.sleep(2)
        notify("EnB Drop Logger", "First run: starting one-time calibration.")
        guided_calibration()
    threading.Thread(target=delayed_first_run, daemon=True).start()

icon.run()
overlay_stop_requested.set()
log("Tray logger 1.1.8 stopped.")

"""
EnB Droplist — Background Tray Edition v2

Fixes:
- Calibration runs in a separate process, so OpenCV selection cannot freeze the tray app.
- Successful loot captures show a tray notification.
"""
from __future__ import annotations
import json, re, time, hashlib, threading, subprocess, sys, ctypes
from datetime import datetime
from pathlib import Path

import cv2
import mss
import numpy as np
import pytesseract
import tkinter as tk
from tkinter import filedialog
from ctypes import wintypes
import pygetwindow as gw
from openpyxl import load_workbook
from PIL import Image, ImageDraw
import pystray
import auto_updater

BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config.json"
LOG_PATH = BASE / "logger_status.txt"
CAPTURE_DIR = BASE / "captures"
CAPTURE_DIR.mkdir(exist_ok=True)

ITEM_IMAGE_DIR = BASE / "item_images"
ITEM_IMAGE_DIR.mkdir(exist_ok=True)

with CFG_PATH.open("r", encoding="utf-8") as f:
    cfg = json.load(f)

pytesseract.pytesseract.tesseract_cmd = cfg["ocr"]["tesseract_cmd"]

running = True
auto_enabled = bool(cfg["behavior"].get("automatic", True))
calibrating = False
state_lock = threading.Lock()

current_target = ""
current_target_cl = ""
last_combat_target = ""
last_combat_target_cl = ""
last_combat_target_seen_at = 0.0
current_zone = ""
last_target_seen_at = 0.0

candidate_target = ""
candidate_target_cl = ""
candidate_target_reads = 0
candidate_zone = ""
candidate_zone_reads = 0
candidate_loot_text = ""
candidate_loot_reads = 0
last_logged_loot_hash = ""
last_log_time = 0.0
last_ocr_texts = {"target":"","loot":"","zone":""}
last_ocr_items = []
last_scan_error = ""

live_overlay = {
    "zone": "Unknown / not read",
    "kills": 0,
    "last_drop": "—",
}
overlay_toggle_requested = threading.Event()
overlay_stop_requested = threading.Event()

# Pressing M in-game does not get intercepted. We only observe the key state,
# then OCR the calibrated map-zone title for a few seconds while the map is open.
map_zone_capture_until = 0.0

# User-hover tooltip OCR state. The logger never moves the mouse.
hover_item_candidate = ""
hover_item_reads = 0
hover_items_seen = []
hover_item_images = {}
loot_session_active = False
loot_session_last_seen = 0.0
loot_session_logged = False
death_candidate_reads=0
kill_counted_for_active_target=False
pending_kill_row=0
pending_kill_ts=""
pending_kill_mob=""
pending_kill_cl=""

def reload_config():
    global cfg
    try:
        with CFG_PATH.open("r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as e:
        log(f"Config reload error: {e!r}")

def log(msg):
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(f"[{stamp}] {msg}\n")
    except Exception:
        pass

def notify(title, msg):
    try:
        icon.notify(msg, title)
    except Exception as e:
        log(f"Notification error: {e!r}")
    log(f"{title}: {msg}")

def message_box(title, text, flags=0x00000040):
    """App-owned translucent dialog.

    Keeps the old MessageBox-style return values used by ask_yes_no:
    IDOK=1, IDYES=6, IDNO=7.
    """
    result = {"value": 0}
    root = None
    try:
        root = tk.Tk()
        root.withdraw()

        dlg = tk.Toplevel(root)
        dlg.title(str(title))
        dlg.attributes("-topmost", True)
        try:
            dlg.attributes("-alpha", float(cfg.get("ui", {}).get("dialog_opacity", 0.82)))
        except Exception:
            dlg.attributes("-alpha", 0.82)
        dlg.configure(bg="#f3f3f3")

        # F8 diagnostics can be very long: use a scrollable text area.
        body = tk.Frame(dlg, bg="#f3f3f3", padx=14, pady=12)
        body.pack(fill="both", expand=True)

        txt = tk.Text(
            body, wrap="word", width=76, height=28,
            font=("Segoe UI", 9), bg="#f3f3f3", fg="#111111",
            relief="flat", borderwidth=0
        )
        scroll = tk.Scrollbar(body, command=txt.yview)
        txt.configure(yscrollcommand=scroll.set)
        txt.insert("1.0", str(text))
        txt.configure(state="disabled")
        txt.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        buttons = tk.Frame(dlg, bg="#f3f3f3", padx=12, pady=(0, 10))
        buttons.pack(fill="x")

        is_yes_no = bool(flags & 0x00000004)

        def finish(value):
            result["value"] = value
            try:
                dlg.grab_release()
            except Exception:
                pass
            dlg.destroy()

        if is_yes_no:
            tk.Button(buttons, text="Yes", width=10, command=lambda: finish(6)).pack(side="right", padx=(6, 0))
            tk.Button(buttons, text="No", width=10, command=lambda: finish(7)).pack(side="right")
            dlg.protocol("WM_DELETE_WINDOW", lambda: finish(7))
        else:
            tk.Button(buttons, text="OK", width=10, command=lambda: finish(1)).pack(side="right")
            dlg.protocol("WM_DELETE_WINDOW", lambda: finish(1))

        dlg.geometry("620x560")
        dlg.update_idletasks()
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        w, h = dlg.winfo_width(), dlg.winfo_height()
        dlg.geometry(f"+{max(0,(sw-w)//2)}+{max(0,(sh-h)//2)}")
        dlg.transient(root)
        dlg.grab_set()
        dlg.focus_force()
        root.wait_window(dlg)
        return result["value"]
    except Exception as e:
        log(f"Transparent dialog error: {e!r}")
        try:
            return ctypes.windll.user32.MessageBoxW(None, str(text), str(title), flags)
        except Exception:
            notify(title, text)
            return 0
    finally:
        try:
            if root is not None:
                root.destroy()
        except Exception:
            pass

def ask_yes_no(title, text):
    return message_box(title, text, 0x00000004 | 0x00000020) == 6

def show_update_complete_if_needed():
    marker = BASE / "update_completed.json"
    if not marker.exists():
        return
    try:
        info = json.loads(marker.read_text(encoding="utf-8"))
        ver = info.get("version", auto_updater.CURRENT_VERSION)
        marker.unlink(missing_ok=True)
        message_box("EnB Droplist updated",
                    f"Update {ver} was installed successfully.\n\n"
                    "Your calibration, config, captures and drop database were preserved.")
    except Exception as e:
        log(f"Update completion marker error: {e!r}")

def find_window():
    needle = cfg["window_title_contains"].lower()
    wins = [
        w for w in gw.getAllWindows()
        if needle in (w.title or "").lower() and w.width > 0 and w.height > 0
    ]
    return wins[0] if wins else None

def grab(region):
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

def absolute_region(win, name):
    r = cfg["regions"].get(name)
    if not r:
        return None
    return {
        "left": int(win.left + r["left"]),
        "top": int(win.top + r["top"]),
        "width": max(1, int(r["width"])),
        "height": max(1, int(r["height"]))
    }

def prep(img, scale=2):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 31, 9
    )

def ocr(img, psm):
    txt = pytesseract.image_to_string(prep(img), config=f"--psm {psm}")
    return "\n".join(x.strip() for x in txt.splitlines() if x.strip())

def norm(s):
    return re.sub(r"\s+", " ", s or "").strip(" |[]-:")

def parse_target(text):
    clean = norm(text)
    if not clean:
        return "", ""
    cl = ""
    for pat in (
        r"\b(?:CL|Combat\s*Level|Combat|Level|Lvl)\s*[:#\-]?\s*(\d{1,3})\b",
        r"\[\s*(?:CL\s*)?(\d{1,3})\s*\]",
    ):
        m = re.search(pat, clean, re.I)
        if m:
            cl = m.group(1)
            clean = norm(clean[:m.start()] + " " + clean[m.end():])
            break
    clean = re.sub(r"\b(?:Target|Hull|Shield|Structure|Range|Distance)\b\s*:?", "",
                   clean, flags=re.I)
    clean = norm(clean)
    if not (2 <= len(clean) <= 80) or re.fullmatch(r"[\d\s%./]+", clean):
        return "", cl
    if re.search(r"\b(?:privacy|personal information|cookie|email address|unsubscribe|http|www\.)\b", clean, re.I):
        return "", cl
    return clean[:80], cl

def parse_zone(text):
    clean = norm(text)
    if not clean:
        return ""
    clean = re.sub(
        r"^(?:Current\s*)?(?:Sector|Zone|Location|System|Area)\s*[:\-]?\s*",
        "", clean, flags=re.I)
    clean = norm(clean)
    if not (2 <= len(clean) <= 80) or re.fullmatch(r"[\d\s%./]+", clean):
        return ""
    if re.search(r"\b(?:privacy|personal information|cookie|email address|unsubscribe|http|www\.)\b", clean, re.I):
        return ""
    # A map title must be overwhelmingly ordinary title characters.
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9 '\-]{1,79}", clean):
        return ""
    if len(re.findall(r"[A-Za-z]", clean)) < 2:
        return ""
    return clean

def parse_loot(text):
    rows, seen = [], set()
    for raw in text.splitlines():
        line = norm(raw)
        if len(line) < 2:
            continue
        if re.search(
            r"\b(?:loot|cargo|close|take all|inventory|credits?|capacity|free space)\b",
            line, re.I
        ):
            continue
        qty, item = 1, line
        m = re.match(r"^(\d+)\s*[xX]\s+(.+)$", line)
        if m:
            qty, item = int(m.group(1)), m.group(2)
        else:
            m = re.match(r"^(.+?)\s+[xX]\s*(\d+)$", line)
            if m:
                item, qty = m.group(1), int(m.group(2))
        item = norm(item)
        if item and item.lower() not in seen:
            seen.add(item.lower())
            rows.append((item[:120], qty))
    return rows

def loot_panel_present(raw_text, items):
    if items:
        return True
    raw = norm(raw_text)
    if not raw:
        return False
    return bool(re.search(r"\b(?:loot|corpse|cargo|take\s*all|no\s*loot|nothing|empty)\b",
                          raw, re.I))


def calibration_complete():
    return all(cfg["regions"].get(x) for x in ("target","loot","zone"))

def run_calibration_step(name, prompt):
    global calibrating
    with state_lock:
        if calibrating:
            notify("EnB Drop Logger", "Calibration is already running.")
            return False
        calibrating = True

    try:
        notify("Calibration", f"Select the {name} area in Earth & Beyond.")
        python_exe = sys.executable

        # When the tray runs under pythonw.exe, launch helper with python.exe
        # so OpenCV's window has a normal GUI-capable child process.
        if python_exe.lower().endswith("pythonw.exe"):
            candidate = python_exe[:-5] + ".exe"
            if Path(candidate).exists():
                python_exe = candidate

        result = subprocess.run(
            [python_exe, str(BASE / "calibrate_helper.py"), name, prompt],
            cwd=str(BASE),
            timeout=300,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )

        if result.returncode == 0:
            reload_config()
            notify("Calibration saved", f"{name.title()} area saved.")
            return True
        elif result.returncode == 3:
            notify("Calibration failed", "Earth & Beyond window was not found.")
        elif result.returncode == 4:
            notify("Calibration cancelled", f"{name.title()} selection was cancelled.")
        else:
            notify("Calibration failed", f"{name.title()} helper returned code {result.returncode}.")
        return False

    except subprocess.TimeoutExpired:
        notify("Calibration cancelled", "Calibration timed out after 5 minutes.")
        return False
    except Exception as e:
        log(f"Calibration helper error: {e!r}")
        notify("Calibration failed", "See logger_status.txt for details.")
        return False
    finally:
        with state_lock:
            calibrating = False

def guided_calibration(*_):
    def work():
        if not run_calibration_step("target", "1/3 TARGET: select mob name / CL, ENTER to save"):
            return
        if not run_calibration_step("loot", "2/3 LOOT: select corpse item list, ENTER to save"):
            return
        if not run_calibration_step("zone", "3/3 MAP ZONE: press M first, then select the zone/sector name, ENTER to save"):
            return
        notify("EnB Drop Logger", "Calibration complete. Automatic logging resumed.")
    threading.Thread(target=work, daemon=True).start()

def single_calibration(name, prompt):
    threading.Thread(
        target=lambda: run_calibration_step(name, prompt),
        daemon=True
    ).start()

def save_capture(images, mob):
    if not cfg["behavior"].get("save_capture_on_log", True):
        return ""
    imgs = [images.get("zone"), images.get("target"), images.get("loot")]
    imgs = [x for x in imgs if x is not None]
    if not imgs:
        return ""
    h = max(x.shape[0] for x in imgs)
    w = sum(x.shape[1] for x in imgs)
    canvas = np.zeros((h,w,3), dtype=np.uint8)
    pos = 0
    for im in imgs:
        canvas[:im.shape[0], pos:pos+im.shape[1]] = im
        pos += im.shape[1]
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^A-Za-z0-9_-]+","_",mob or "unknown")[:40]
    p = CAPTURE_DIR / f"{stamp}_{safe}.png"
    cv2.imwrite(str(p), canvas)
    return str(p)

def rebuild_summary(wb):
    ws = wb["Summary"]
    kd, agg = {}, {}
    for row in wb["Kills"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        if mob:
            kd[mob] = kd.get(mob, 0) + 1

    for row in wb["Drops"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        item = str(row[4] or "").strip()
        try:
            qty = int(row[5] or 1)
        except Exception:
            qty = 1
        if mob and item:
            rec = agg.setdefault((mob,item), [0,0])
            rec[0] += 1
            rec[1] += qty

    # Replace the generated summary area cleanly. The starter workbook has
    # merged instruction rows below row 2; writing to those MergedCell objects
    # raises "value is read-only" in openpyxl. Unmerge/remove that area first.
    for merged in list(ws.merged_cells.ranges):
        if merged.min_row >= 3:
            ws.unmerge_cells(str(merged))
    if ws.max_row >= 3:
        ws.delete_rows(3, ws.max_row - 2)

    for (mob,item),(events,qty) in sorted(agg.items()):
        kills = kd.get(mob,0)
        ws.append([
            mob, item, events, kills,
            (events/kills if kills else 0),
            qty, "Observed sample"
        ])
        ws.cell(ws.max_row,5).number_format = "0.0%"

def append_rows(kill, drops):
    path = (BASE / cfg["excel_file"]).resolve()
    if not path.exists():
        notify("EnB Drop Logger", "Database XLSX is missing.")
        log(f"XLSX FAIL missing file: {path}")
        return False

    try:
        wb = load_workbook(path)
        kills_ws = wb["Kills"]
        drops_ws = wb["Drops"]

        if drops_ws.cell(2, 10).value != "Item Image":
            drops_ws.cell(2, 10).value = "Item Image"

        kills_ws.append(kill)
        kill_row = kills_ws.max_row

        for r in drops:
            drops_ws.append(r)

        rebuild_summary(wb)
        wb.save(path)
        wb.close()

        # Verify the just-written kill row can be read back from disk.
        verify = load_workbook(path, read_only=True, data_only=False)
        ws = verify["Kills"]
        saved_ts = ws.cell(kill_row, 1).value
        saved_zone = ws.cell(kill_row, 2).value
        saved_mob = ws.cell(kill_row, 3).value
        verify.close()

        ok = (
            str(saved_ts or "") == str(kill[0] or "")
            and str(saved_zone or "") == str(kill[1] or "")
            and str(saved_mob or "") == str(kill[2] or "")
        )

        if not ok:
            log(f"XLSX VERIFY FAIL row={kill_row} expected={kill[:3]!r} "
                f"readback={[saved_ts,saved_zone,saved_mob]!r}")
            notify("EnB Drop Logger", "XLSX save verification failed. See logger_status.txt.")
            return False

        log(f"XLSX SAVED+VERIFIED kill_row={kill_row} drop_rows={len(drops)} "
            f"zone={kill[1]!r} mob={kill[2]!r}")
        return True

    except PermissionError:
        notify("Database is open", "Close the XLSX in Excel/OpenOffice while logging.")
        log("XLSX FAIL: file is locked/open in another program.")
        return False
    except Exception as e:
        log(f"Workbook error: {e!r}")
        return False



def append_kill_only(kill):
 path=(BASE/cfg["excel_file"]).resolve()
 try:
  wb=load_workbook(path); ws=wb["Kills"]; ws.append(kill); row=ws.max_row; rebuild_summary(wb); wb.save(path); wb.close(); log(f"XLSX KILL SAVED row={row} mob={kill[2]!r}"); return row
 except Exception as e: log(f"XLSX KILL FAIL: {e!r}"); return 0

def append_drops_to_existing_kill(row,drops):
 if not drops:return True
 path=(BASE/cfg["excel_file"]).resolve()
 try:
  wb=load_workbook(path); kw=wb["Kills"]; dw=wb["Drops"]
  if dw.cell(2,10).value!="Item Image":dw.cell(2,10).value="Item Image"
  for x in drops:dw.append(x)
  if row and 1<=int(row)<=kw.max_row:kw.cell(int(row),5).value=len(drops)
  rebuild_summary(wb); wb.save(path); wb.close(); log(f"XLSX DROPS ATTACHED kill_row={row} drop_rows={len(drops)}"); return True
 except Exception as e:log(f"XLSX DROP ATTACH FAIL: {e!r}"); return False

def register_live_kill(mob,cl):
 global kill_counted_for_active_target,pending_kill_row,pending_kill_ts,pending_kill_mob,pending_kill_cl
 if kill_counted_for_active_target or not mob:return False
 ts=datetime.now().strftime("%Y-%m-%d %H:%M:%S"); zone=current_zone or live_overlay.get("zone") or "Unknown / press M"
 kill_counted_for_active_target=True; live_overlay["zone"]=zone; live_overlay["kills"]=int(live_overlay.get("kills",0))+1
 pending_kill_ts=ts; pending_kill_mob=mob; pending_kill_cl=cl or ""; pending_kill_row=append_kill_only([ts,zone,mob,cl or "",0,"","Live Level-loss death transition; awaiting hovered loot"])
 log(f"LIVE KILL CONFIRMED zone={zone!r} kills={live_overlay['kills']} mob={mob!r} level={cl!r}"); notify("Kill detected",f"{zone} | Kill {live_overlay['kills']} | {mob}"); return True


def client_rect_screen(win):
    try:
        hwnd = int(win._hWnd)
        rect = wintypes.RECT()
        if not ctypes.windll.user32.GetClientRect(hwnd, ctypes.byref(rect)):
            raise RuntimeError("GetClientRect failed")
        pt = wintypes.POINT(rect.left, rect.top)
        if not ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(pt)):
            raise RuntimeError("ClientToScreen failed")
        width = int(rect.right - rect.left)
        height = int(rect.bottom - rect.top)
        if width < 200 or height < 150:
            raise RuntimeError(f"Suspicious client size {width}x{height}")
        return int(pt.x), int(pt.y), width, height
    except Exception as e:
        log(f"Client rect fallback: {e!r}")
        return int(win.left), int(win.top), int(win.width), int(win.height)

def client_region(win, x1, y1, x2, y2):
    left, top, width, height = client_rect_screen(win)
    x1 = float(x1); y1 = float(y1); x2 = float(x2); y2 = float(y2)
    l = left + int(width * x1)
    t = top + int(height * y1)
    r = left + int(width * x2)
    b = top + int(height * y2)
    return {
        "left": l,
        "top": t,
        "width": max(1, r - l),
        "height": max(1, b - t),
    }

def client_sparse_ocr(win, x1, y1, x2, y2, psm=11):
    try:
        return ocr(grab(client_region(win, x1, y1, x2, y2)), psm)
    except Exception as e:
        log(f"Client sparse OCR error: {e!r}")
        return ""

def relative_region(win, x1, y1, x2, y2):
    return client_region(win, x1, y1, x2, y2)

def sparse_ocr_region(win, x1, y1, x2, y2):
    return client_sparse_ocr(win, x1, y1, x2, y2, 11)

def clean_title_line(text):
    """Pick the most plausible short EnB title from a narrow title strip."""
    candidates = []
    for raw in str(text or "").splitlines():
        s = norm(raw)
        if not s:
            continue

        # Remove common title-strip prefixes/noise.
        s = re.sub(r"^(?:Dist(?:ance)?\s*:\s*)", "", s, flags=re.I)
        s = re.sub(r"^[\[\]{}()|:;.,'\"`~_+=*<>!?\\/]+", "", s).strip()
        s = re.sub(r"\s+", " ", s)

        if not (2 <= len(s) <= 90):
            continue
        if re.fullmatch(r"[\d\s%+./:_\-]+", s):
            continue
        if re.search(
            r"\b(?:Chat|Group|Options|Help|Emote|Computer|credits?|"
            r"Structure|Quality|Hull|Shield|Range|Distance|X:|Y:|Z:)\b",
            s, re.I
        ):
            continue

        # Title text should mostly consist of letters/digits/basic punctuation.
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 '\-.:()]{1,89}", s):
            continue

        letters = len(re.findall(r"[A-Za-z]", s))
        if letters < 2:
            continue

        candidates.append(s)

    if not candidates:
        return ""

    # Prefer lines that look like EnB names rather than OCR sentence debris.
    def score(x):
        words = x.split()
        titleish = sum(1 for w in words if w[:1].isupper())
        strange = len(re.findall(r"[^A-Za-z0-9 '\-.:()]", x))
        return (
            strange,
            0 if titleish else 1,
            abs(len(words) - min(len(words), 4)),
            len(x),
        )

    candidates.sort(key=score)
    return candidates[0]



def raw_target_is_corpse(raw_text):
    return bool(re.search(r"\bCorpse\s+of\s+", str(raw_text or ""), re.I))

def target_bar_region(win):
    """
    Target card's HP/shield strip at the top of the lower-right target panel.
    Empty navpoints still have the frames; combat mobs have visibly filled
    red HP and blue shield segments.
    """
    return client_region(win, 0.800, 0.675, 0.990, 0.715)

def _max_horizontal_run(mask):
    """Longest nonzero horizontal run in any row of an 8-bit mask."""
    best = 0
    if mask is None or getattr(mask, "size", 0) == 0:
        return 0
    for row in mask:
        run = 0
        for px in row:
            if px:
                run += 1
                if run > best:
                    best = run
            else:
                run = 0
    return best

def target_combat_bar_metrics(win):
    """
    Detect actual bar FILL, not the decorative/empty bar frame.

    Returns a dict with longest horizontal red and blue runs, both as pixels
    and as a fraction of the sampled strip width.
    """
    img = grab(target_bar_region(win))
    if img is None or getattr(img, "size", 0) == 0:
        return {
            "red_run": 0, "blue_run": 0,
            "red_frac": 0.0, "blue_frac": 0.0,
            "combat": False,
        }

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # Filled red HP.
    red_a = cv2.inRange(hsv, (0, 95, 65), (12, 255, 255))
    red_b = cv2.inRange(hsv, (168, 95, 65), (179, 255, 255))
    red = cv2.bitwise_or(red_a, red_b)

    # Filled blue shield.
    blue = cv2.inRange(hsv, (92, 80, 55), (132, 255, 255))

    # Remove isolated icon/frame pixels; preserve long horizontal fills.
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 1))
    red = cv2.morphologyEx(red, cv2.MORPH_OPEN, kernel)
    blue = cv2.morphologyEx(blue, cv2.MORPH_OPEN, kernel)

    width = max(int(img.shape[1]), 1)
    red_run = _max_horizontal_run(red)
    blue_run = _max_horizontal_run(blue)
    red_frac = red_run / width
    blue_frac = blue_run / width

    # Frames/decoration produce only short fragments. Actual filled bars form
    # much longer horizontal runs.
    #
    # EnB-specific rule confirmed from gameplay:
    # - every enemy has a visibly filled BLUE shield bar
    # - red HP may or may not be filled depending on enemy type
    # - navpoints/gates/stations have empty blue bar frames
    #
    # 1.1.33: bars are diagnostic only. Enemy classification is Level-based.
    combat = (blue_frac >= 0.10)

    return {
        "red_run": red_run,
        "blue_run": blue_run,
        "red_frac": red_frac,
        "blue_frac": blue_frac,
        "combat": combat,
    }

def target_has_combat_bars(win):
    try:
        m = target_combat_bar_metrics(win)
        log(
            "TARGET BAR FILL "
            f"red_run={m['red_run']} ({m['red_frac']:.3f}) "
            f"blue_run={m['blue_run']} ({m['blue_frac']:.3f}) "
            f"combat={m['combat']} (diagnostic only)"
        )
        return bool(m["combat"])
    except Exception as e:
        log(f"Target bar detection error: {e!r}")
        return False

def title_similarity(a, b):
    """Return a tolerant 0..1 similarity score for noisy OCR target titles."""
    import difflib
    def _clean(s):
        s = str(s or "").lower()
        s = re.sub(r"^corpse\s+of\s+", "", s, flags=re.I)
        s = re.sub(r"[^a-z0-9]+", " ", s)
        return re.sub(r"\s+", " ", s).strip()
    aa, bb = _clean(a), _clean(b)
    if not aa or not bb:
        return 0.0
    if aa == bb:
        return 1.0
    return difflib.SequenceMatcher(None, aa, bb).ratio()


def target_title_from_window(win):
    """Read the lower-right EnB target card.

    1.1.33 rule:
    - A target is a mob/enemy ONLY when an explicit Level row is detected.
    - The name is taken from the line immediately above that Level row.
    - No Level row means neutral/object/wreck/navpoint, even if OCR elsewhere
      looks like a plausible name.
    """
    # The target-card header is much higher than the old 1.1.30 bands.
    # Scan two overlapping client-relative header regions to tolerate window
    # chrome/aspect-ratio differences.
    header_regions = [
        # Name is near the top of the target card; Level sits noticeably lower.
        # 1.1.33 extends the lower edge after real screenshots showed Level 10
        # just below the 1.1.31 OCR crop.
        (0.770, 0.575, 0.998, 0.805),
        (0.770, 0.610, 0.998, 0.835),
    ]

    def text_variants(img):
        if img is None or getattr(img, "size", 0) == 0:
            return []
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Target-card title/Level text is bright low-saturation white/gray.
        white = cv2.inRange(hsv, (0, 0, 135), (179, 135, 255))
        white = cv2.morphologyEx(
            white, cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
        )
        masked = cv2.bitwise_and(gray, gray, mask=white)

        out = []
        for base in (white, masked):
            big = cv2.resize(base, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)
            out.extend([
                big,
                cv2.threshold(big, 80, 255, cv2.THRESH_BINARY)[1],
                cv2.threshold(big, 115, 255, cv2.THRESH_BINARY)[1],
                cv2.threshold(big, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1],
            ])
        return out

    def normalize_card_line(raw):
        x = norm(raw)
        x = re.sub(r"^[\[\]{}()|:;.,'\"`~_+=*<>!?\\/]+", "", x).strip()
        x = re.sub(r"\s+", " ", x)
        return x

    # Tolerate common OCR confusions in "Level".
    level_re = re.compile(
        r"\b(?:Level|LeveI|Levei|Lvl|CL)\s*[:#\-]?\s*([0-9]{1,3})\b",
        re.I
    )

    readings = []
    for coords in header_regions:
        try:
            img = grab(client_region(win, *coords))
        except Exception as e:
            log(f"Target-card header grab error: {e!r}")
            continue

        for proc in text_variants(img):
            for psm in (6, 11):
                try:
                    raw = pytesseract.image_to_string(
                        proc,
                        config=f"--psm {psm} -c preserve_interword_spaces=1"
                    )
                    lines = [normalize_card_line(x) for x in raw.splitlines()]
                    lines = [x for x in lines if x]
                    if lines:
                        readings.append((lines, psm, coords))
                except Exception as e:
                    log(f"Target-card OCR variant error: {e!r}")

    candidates = []
    debug_rows = []

    for lines, psm, coords in readings:
        debug_rows.append(
            f"[psm{psm} {coords[1]:.3f}-{coords[3]:.3f}] " + " | ".join(lines)
        )
        for i, line in enumerate(lines):
            m = level_re.search(line)
            if not m:
                continue

            level = m.group(1)
            try:
                n = int(level)
            except Exception:
                continue
            if not (0 <= n <= 99):
                continue

            # The actual target name is the nearest plausible line ABOVE Level.
            name = ""
            for j in range(i - 1, max(-1, i - 4), -1):
                x = lines[j]
                x = re.sub(r"^Corpse\s+of\s+", "", x, flags=re.I).strip()
                x = re.sub(r"[^A-Za-z0-9 '\-]", " ", x)
                x = re.sub(r"\s+", " ", x).strip()

                if not (3 <= len(x) <= 60):
                    continue
                if len(re.findall(r"[A-Za-z]", x)) < 3:
                    continue
                if len(x.split()) > 7:
                    continue
                if re.search(
                    r"\b(?:Dist|Distance|Hull|Shield|Structure|Quality|"
                    r"Chat|Group|Options|Help|Emote|Credits?)\b",
                    x, re.I
                ):
                    continue
                name = x
                break

            if name:
                candidates.append((name, level))

    if not candidates:
        debug = (
            "TARGET CARD HEADER READS (no explicit Level row found):\n"
            + ("\n".join(debug_rows) if debug_rows else "<blank>")
        )
        return "", "", debug

    # Vote by repeated name+level agreement across OCR variants.
    from collections import Counter
    pair_counts = Counter((n.lower(), lv) for n, lv in candidates)
    best_key, best_count = pair_counts.most_common(1)[0]

    matching_names = [n for n, lv in candidates if n.lower() == best_key[0] and lv == best_key[1]]
    best_name = min(matching_names, key=lambda x: (len(x.split()), len(x)))
    best_level = best_key[1]

    debug = (
        "TARGET CARD HEADER READS:\n"
        + ("\n".join(debug_rows) if debug_rows else "<blank>")
        + "\nLEVEL-BOUND CANDIDATES:\n"
        + "\n".join(f"{n} | Level {lv}" for n, lv in candidates)
        + f"\nWINNER: {best_name} | Level {best_level} | votes={best_count}"
    )
    return best_name, best_level, debug

def normalize_zone_candidate(text):
    """Clean noisy OCR into a conservative zone-title candidate."""
    s = norm(text)
    if not s:
        return ""
    s = re.sub(r"\[[^\]]*\]", " ", s)
    s = re.sub(r"[^A-Za-z0-9 '\-]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    # Remove common UI/noise tokens without guessing a zone.
    s = re.sub(r"^(?:Zone|Sector)\s*[:\-]?\s*", "", s, flags=re.I).strip()
    if not (2 <= len(s) <= 60):
        return ""
    if len(re.findall(r"[A-Za-z]", s)) < 2:
        return ""
    return s


def zone_title_multipass(win):
    """
    Multipass OCR for the large map/zone title.

    Key rule in 1.1.33:
    repeated clean short titles beat longer noisy OCR strings.
    Example: several reads of 'Jupiter' beat 'Jupiter a aA S a'.
    """
    reg = client_region(win, 0.18, 0.235, 0.62, 0.335)
    img = grab(reg)
    if img is None:
        return "", "<blank>", []

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    big = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    big = cv2.normalize(big, None, 0, 255, cv2.NORM_MINMAX)

    variants = [
        big,
        cv2.threshold(big, 90, 255, cv2.THRESH_BINARY)[1],
        cv2.threshold(big, 120, 255, cv2.THRESH_BINARY)[1],
        cv2.threshold(big, 150, 255, cv2.THRESH_BINARY)[1],
        cv2.threshold(big, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1],
    ]

    readings = []
    for proc in variants:
        for psm in (7, 11, 13):
            try:
                raw = norm(
                    pytesseract.image_to_string(
                        proc,
                        config=f"--psm {psm} -c preserve_interword_spaces=1"
                    )
                )
                if raw:
                    readings.append((raw, psm))
            except Exception as e:
                log(f"Zone title OCR variant error: {e!r}")

    def plausible_fragment(text):
        """
        Return plausible zone-title fragments from one OCR result.

        Rather than preserving all trailing OCR garbage, examine short prefixes
        and individual lines. This lets 'Jupiter a aA S a' contribute 'Jupiter'.
        """
        text = norm(text)
        if not text:
            return []

        candidates = []

        # Treat each OCR line independently.
        lines = [norm(x) for x in re.split(r"[\r\n]+", text) if norm(x)]
        for line in lines:
            clean = re.sub(r"[^A-Za-z0-9 '\-]", " ", line)
            clean = re.sub(r"\s+", " ", clean).strip()
            if not clean:
                continue

            words = clean.split()

            # Full line can still be useful if already clean.
            if 2 <= len(clean) <= 40 and len(words) <= 4:
                candidates.append(clean)

            # Also consider prefixes of 1..4 words.
            # This is the important protection against trailing OCR junk.
            for n in range(1, min(4, len(words)) + 1):
                prefix = " ".join(words[:n]).strip()
                if 2 <= len(prefix) <= 40:
                    candidates.append(prefix)

        # Conservative filtering.
        out = []
        seen = set()
        noise_words = {
            "chat", "group", "options", "help", "emote", "computer",
            "level", "target", "dist", "credits", "corpse"
        }

        for c in candidates:
            if c.lower() in seen:
                continue

            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9 '\-]{1,39}", c):
                continue

            words = c.split()
            if len(words) > 4:
                continue

            if any(w.lower() in noise_words for w in words):
                continue

            # Do not accept obviously tiny OCR fragments such as "Or", "ss".
            if len(c) < 4:
                continue

            # Single-word zone names should look like normal names, e.g. Jupiter.
            if len(words) == 1:
                w = words[0]
                if not (w[0].isupper() and sum(ch.isalpha() for ch in w) >= 4):
                    continue

            key = c.lower()
            seen.add(key)
            out.append(c)

        return out

    extracted = []
    for raw, psm in readings:
        for candidate in plausible_fragment(raw):
            extracted.append((candidate, raw, psm))

    if not extracted:
        debug = "\n".join(f"{raw} [psm{psm}]" for raw, psm in readings) or "<blank>"
        return "", debug, readings

    # Cluster near-identical candidates.
    clusters = []
    for cand, raw, psm in extracted:
        hit = None
        for cluster in clusters:
            if title_similarity(cand, cluster["rep"]) >= 0.72:
                hit = cluster
                break

        if hit is None:
            clusters.append({
                "rep": cand,
                "items": [(cand, raw, psm)],
                "sources": {(raw, psm)},
            })
        else:
            hit["items"].append((cand, raw, psm))
            hit["sources"].add((raw, psm))

            # Representative should stay the cleanest shortest member.
            all_names = [x[0] for x in hit["items"]]
            hit["rep"] = min(
                all_names,
                key=lambda x: (
                    len(x.split()),
                    len(x),
                )
            )

    # Score by number of independent OCR sources first, then prefer clean/short titles.
    def cluster_score(cluster):
        unique_sources = len(cluster["sources"])
        rep = cluster["rep"]
        words = rep.split()

        # Repeated exact-ish clean title gets a strong bonus.
        exact_support = sum(
            1 for cand, _raw, _psm in cluster["items"]
            if cand.lower() == rep.lower()
        )

        return (
            unique_sources,
            exact_support,
            -len(words),
            -len(rep),
        )

    clusters.sort(key=cluster_score, reverse=True)
    best = clusters[0]

    # Within the winner, pick the shortest plausible title with strongest exact support.
    names = [x[0] for x in best["items"]]
    counts = {}
    for n in names:
        counts[n.lower()] = counts.get(n.lower(), 0) + 1

    unique_names = {}
    for n in names:
        unique_names.setdefault(n.lower(), n)

    final = min(
        unique_names.values(),
        key=lambda n: (
            -counts[n.lower()],
            len(n.split()),
            len(n),
        )
    )

    debug = "\n".join(
        f"{raw} [psm{psm}]"
        for raw, psm in readings
    )

    log(
        f"ZONE VOTE final={final!r} "
        f"support={counts.get(final.lower(), 0)} "
        f"cluster_sources={len(best['sources'])}"
    )

    return final, debug, readings

def map_title_from_window(win):
    title, debug, variants = zone_title_multipass(win)

    title = normalize_zone_candidate(title)
    if title and plausible_zone_title(title):
        return title, debug

    # Tight direct fallback. Do not preserve a noisy multipass title.
    raw = client_sparse_ocr(win, 0.255, 0.250, 0.350, 0.320, 7)
    fallback = normalize_zone_candidate(clean_title_line(raw))

    if fallback and plausible_zone_title(fallback):
        return fallback, raw

    return "", debug or raw

def main_view_target_from_window(win):
    """
    Primary target source: EnB's bright white 'Dest:' line.
    """
    # Tight client-relative strip matching the screenshots.
    raw_dest = client_sparse_ocr(win, 0.185, 0.775, 0.565, 0.825, 7)
    raw_dest2 = client_sparse_ocr(win, 0.165, 0.755, 0.585, 0.845, 11)
    combined = raw_dest + "\n" + raw_dest2

    for line in [norm(x) for x in combined.splitlines() if norm(x)]:
        m = re.search(r"(?:^|\b)Dest\s*:\s*(.+)$", line, re.I)
        if not m:
            continue

        name = norm(m.group(1))
        name = re.sub(r"^Corpse\s+of\s+", "", name, flags=re.I).strip()

        if 3 <= len(name) <= 80:
            return name, "", "DEST:\n" + combined

    # Secondary reticle source.
    raw_reticle = client_sparse_ocr(win, 0.385, 0.350, 0.665, 0.475, 11)

    for line in [norm(x) for x in raw_reticle.splitlines() if norm(x)]:
        cl = ""
        m = re.match(r"(.+?)\s*\((\d{1,3})\)\s*$", line)
        if m:
            line = norm(m.group(1))
            cl = m.group(2)

        line = re.sub(r"^Corpse\s+of\s+", "", line, flags=re.I).strip()
        candidate = clean_title_line(line)

        if candidate and 3 <= len(candidate) <= 80:
            return candidate, cl, "DEST:\n" + combined + "\nRETICLE:\n" + raw_reticle

    return "", "", "DEST:\n" + combined + "\nRETICLE:\n" + raw_reticle

def target_fallback_from_window(win):
    card_name, card_cl, card_raw = target_title_from_window(win)
    if card_name:
        return card_name, card_cl, card_raw

    name, cl, raw = main_view_target_from_window(win)
    if name:
        name = re.sub(r"^Corpse\s+of\s+", "", name, flags=re.I).strip()
        return name, (cl or card_cl), raw + "\nCARD:\n" + card_raw

    return "", card_cl, card_raw + "\nMAIN VIEW:\n" + raw

def map_zone_fallback_from_window(win):
    # Backwards-compatible wrapper used elsewhere in the logger.
    return map_title_from_window(win)


def update_target(text, fallback_mob="", fallback_cl=""):
    global candidate_target,candidate_target_cl,candidate_target_reads
    global current_target,current_target_cl,last_target_seen_at
    global last_combat_target,last_combat_target_cl,last_combat_target_seen_at

    mob, cl = parse_target(text)
    if not mob and fallback_mob:
        mob, cl = fallback_mob, fallback_cl
    if not mob:
        return

    if mob == candidate_target:
        candidate_target_reads += 1
        if cl:
            candidate_target_cl = cl
    else:
        candidate_target = mob
        candidate_target_cl = cl
        candidate_target_reads = 1

    if candidate_target_reads >= int(cfg["behavior"].get("stable_target_reads",2)):
        if mob != current_target:
            log(f"Target changed: {current_target!r} -> {mob!r}")
            current_target = mob
        if candidate_target_cl:
            current_target_cl = candidate_target_cl
        last_target_seen_at = time.time()
        last_combat_target = current_target
        last_combat_target_cl = current_target_cl
        last_combat_target_seen_at = last_target_seen_at
        log(
            f"COMBAT TARGET STABLE mob={last_combat_target!r} "
            f"level={last_combat_target_cl!r}"
        )

def plausible_zone_title(zone):
    zone = norm(zone)
    if not zone or not (4 <= len(zone) <= 40):
        return False
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9 '\-]{3,39}", zone):
        return False

    words = zone.split()
    if len(words) > 4:
        return False

    if re.search(
        r"\b(?:chat|group|options|help|emote|computer|credits|level|dist|"
        r"target|structure|quality)\b",
        zone, re.I
    ):
        return False

    if len(words) > 1 and zone.isupper():
        return False

    if len(words) == 1 and not (zone[0].isupper() and zone[1:].islower()):
        return False

    # Reject ordinary sentence fragments accidentally OCR'd from chat/UI.
    # Real EnB map titles use title-like words; small connector words are allowed.
    connectors = {"of", "the", "to", "and"}
    for i, w in enumerate(words):
        bare = re.sub(r"[^A-Za-z0-9]", "", w)
        if not bare:
            return False
        if bare.lower() in connectors and i > 0:
            continue
        if bare.isdigit():
            continue
        if not bare[0].isupper():
            return False

    return True

def update_zone(text):
    global candidate_zone,candidate_zone_reads,current_zone

    zone = normalize_zone_candidate(parse_zone(text))
    if not zone or not plausible_zone_title(zone):
        return

    if candidate_zone and title_similarity(zone, candidate_zone) >= 0.72:
        candidate_zone_reads += 1
        # Prefer a naturally capitalized version within the same OCR cluster.
        def q(s):
            words = s.split()
            titleish = sum(1 for w in words if w[:1].isupper())
            return (-titleish, len(s))
        if q(zone) < q(candidate_zone):
            candidate_zone = zone
    else:
        candidate_zone = zone
        candidate_zone_reads = 1

    needed = int(cfg["behavior"].get("stable_zone_reads",3))
    if candidate_zone_reads >= needed:
        if current_zone != candidate_zone:
            log(f"Zone changed: {current_zone!r} -> {candidate_zone!r}")
            current_zone = candidate_zone
            live_overlay["zone"] = current_zone
            live_overlay["kills"] = 0
        candidate_zone_reads = needed

def tick():
    global candidate_loot_text,candidate_loot_reads,last_logged_loot_hash,last_log_time
    global last_ocr_texts,last_ocr_items,last_scan_error
    global loot_session_active, loot_session_last_seen, loot_session_logged
    global hover_items_seen, hover_item_images
    global last_combat_target,last_combat_target_cl,last_combat_target_seen_at
    global death_candidate_reads,kill_counted_for_active_target
    global pending_kill_row,pending_kill_ts,pending_kill_mob,pending_kill_cl

    win = find_window()
    if not win:
        last_scan_error = "Earth & Beyond window not found."
        return

    images, texts = {}, {}

    # Target + loot area are sampled continuously.
    for name,key in (("target","target_psm"),("loot","loot_psm")):
        reg = absolute_region(win,name)
        if not reg:
            last_scan_error = f"{name.title()} is not calibrated."
            return
        images[name] = grab(reg)
        texts[name] = ocr(images[name], cfg["ocr"][key])

    # Deterministic EnB target title strip.
    fallback_mob, fallback_cl, target_fallback_raw = target_fallback_from_window(win)
    texts["target_title_raw"] = target_fallback_raw

    combat_metrics = target_combat_bar_metrics(win)
    combat_target = bool(combat_metrics["combat"])
    corpse_target = raw_target_is_corpse(target_fallback_raw)
    texts["combat_target"] = "YES" if combat_target else "NO"
    texts["corpse_target"] = "YES" if corpse_target else "NO"

    log(
        "TARGET BAR FILL "
        f"red={combat_metrics['red_frac']:.3f} "
        f"blue={combat_metrics['blue_frac']:.3f} "
        f"combat={combat_target} corpse={corpse_target}"
    )

    if map_zone_capture_active():
        map_title,map_raw=map_title_from_window(win); texts["zone_title_raw"]=map_raw
        if map_title and plausible_zone_title(map_title): update_zone(map_title); log(f"MAP M-WINDOW SAMPLE title={map_title!r} candidate={candidate_zone!r} reads={candidate_zone_reads} current={current_zone!r}")
    else:
        texts["zone_title_raw"]="<M capture inactive>"; texts["zone"]="<locked to last confirmed zone>"
    if current_zone: live_overlay["zone"]=current_zone

    last_ocr_texts = dict(texts)
    last_scan_error = ""
    card_mob,card_cl,card_raw=target_title_from_window(win); texts["combat_card_raw"]=card_raw; level_target=bool(card_cl); texts["level_target"]="YES" if level_target else "NO"
    if level_target:
        death_candidate_reads=0; chosen_mob=card_mob or fallback_mob
        if kill_counted_for_active_target:
            kill_counted_for_active_target=False; pending_kill_row=0; pending_kill_ts=""; pending_kill_mob=""; pending_kill_cl=""; log("NEW LIVE TARGET CYCLE: kill latch reset.")
        if chosen_mob:update_target("",chosen_mob,card_cl); log(f"LEVEL TARGET confirmed mob={chosen_mob!r} level={card_cl!r} blue={combat_metrics['blue_frac']:.3f} red={combat_metrics['red_frac']:.3f}")
    else:
        nowd=time.time(); recent=bool(last_combat_target) and nowd-float(last_combat_target_seen_at or 0)<=8.0; same=bool(recent and fallback_mob and title_similarity(fallback_mob,last_combat_target)>=0.66); evidence=recent and (same or corpse_target or (not fallback_mob and not combat_target))
        if evidence and not kill_counted_for_active_target:
            death_candidate_reads+=1; log(f"DEATH CANDIDATE {death_candidate_reads}/3 last={last_combat_target!r} fallback={fallback_mob!r}")
            if death_candidate_reads>=3:register_live_kill(last_combat_target,last_combat_target_cl); death_candidate_reads=3
        else:death_candidate_reads=0
        if corpse_target and fallback_mob:
            x=re.sub(r"^Corpse\s+of\s+","",fallback_mob,flags=re.I).strip()
            if x:last_combat_target=x; last_combat_target_cl=fallback_cl or last_combat_target_cl
        elif fallback_mob:log(f"NO-LEVEL TARGET ignored: {fallback_mob!r} red={combat_metrics['red_frac']:.3f} blue={combat_metrics['blue_frac']:.3f}")

    # User-hover tooltip is the authoritative item name source.
    hovered = update_hover_item(win)
    if hovered:
        last_ocr_items = [(name, 1) for name in hover_items_seen]

    raw_loot_active = loot_region_has_activity(texts["loot"])
    now = time.time()

    if raw_loot_active or hovered:
        loot_session_last_seen = now
        if not loot_session_active:
            loot_session_active = True
            loot_session_logged = False
            hover_items_seen = [hovered] if hovered else []
            log("Loot session opened.")
    elif loot_session_active and now - loot_session_last_seen > 1.25:
        # Corpse window disappeared. The next corpse becomes a fresh kill.
        log("Loot session closed.")
        reset_loot_session()
        return
    else:
        return

    # We log one kill per loot-session. Prefer waiting briefly for at least one
    # user-hovered tooltip, but zero-item kills remain possible after a delay.
    session_age = max(0.0, now - loot_session_last_seen)
    have_real_items = bool(hover_items_seen)

    if loot_session_logged:
        return

    if not have_real_items:
        # Do not use OCR garbage from the icon grid as drops.
        return

    # Combat bars disappear after the mob dies, so corpse loot belongs to the
    # most recent confirmed combat target. Never attach loot to a navpoint.
    recent_combat = (
        bool(last_combat_target)
        and (now - float(last_combat_target_seen_at or 0.0)) <= 45.0
    )

    if recent_combat:
        mob_value = last_combat_target
        cl_value = last_combat_target_cl
    else:
        mob_value = "Unknown mob / no recent combat target"
        cl_value = ""

    zone_value = current_zone or "Unknown / press M"
    items = [(name, 1) for name in hover_items_seen]
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # Deduplicated item-image mode: no new event screenshot per kill.
    shot = ""

    kill = [
        ts, zone_value, mob_value, cl_value,
        len(items), shot,
        "User-hover tooltip OCR; event screenshot disabled; canonical item images used"
    ]
    drops = [
        [
            ts, zone_value, mob_value, cl_value,
            item, qty, "Review", "hover-tooltip",
            "Item name read from user-hover tooltip",
            hover_item_images.get(item) or str(canonical_item_image_path(item))
        ]
        for item,qty in items
    ]

    already_counted=kill_counted_for_active_target and bool(pending_kill_mob) and title_similarity(mob_value,pending_kill_mob)>=0.66
    saved=append_drops_to_existing_kill(pending_kill_row,drops) if already_counted and pending_kill_row else append_rows(kill,drops)
    if saved:
        loot_session_logged=True; last_log_time=now; live_overlay["zone"]=zone_value; live_overlay["last_drop"]=", ".join(name for name,_ in items[:3])
        if not already_counted:live_overlay["kills"]=int(live_overlay.get("kills",0))+1; kill_counted_for_active_target=True
        log(f"LIVE+XLSX OK hover-tooltip zone={zone_value!r} kills={live_overlay['kills']} mob={mob_value!r} CL={cl_value!r} items={items!r} attached_to_live_kill={already_counted}")
        notify("Loot logged",f"{zone_value} | Kill {live_overlay['kills']} | {live_overlay['last_drop']}")

def worker():
    global running
    while running:
        try:
            with state_lock:
                busy = calibrating
            if auto_enabled and not busy and calibration_complete():
                tick()
        except Exception as e:
            log(f"Scan error: {e!r}")
        time.sleep(float(cfg.get("scan_interval_seconds",0.6)))

def show_ocr_status(*_):
    try:
        win = find_window()
        if not win:
            message_box("EnB Droplist OCR Status", "Earth & Beyond window was not found.")
            return
        combat_metrics = target_combat_bar_metrics(win)
        combat_target = bool(combat_metrics["combat"])
        raw = {}
        for name,key in (("target","target_psm"),("loot","loot_psm"),("zone","zone_psm")):
            reg = absolute_region(win,name)
            raw[name] = "<NOT CALIBRATED>" if not reg else ocr(grab(reg), cfg["ocr"][key])

        fallback_mob, fallback_cl, target_fallback_raw = target_fallback_from_window(win)
        card_mob, card_cl, combat_card_raw = target_title_from_window(win)
        corpse_target = raw_target_is_corpse(target_fallback_raw)
        level_target = bool(card_cl)

        if level_target and card_mob:
            mob = card_mob
            cl = card_cl
        elif level_target and fallback_mob:
            mob = re.sub(r"^Corpse\s+of\s+", "", fallback_mob, flags=re.I).strip()
            cl = card_cl
        else:
            # No Level row = not a mob/enemy.
            mob = ""
            cl = ""

        raw_zone = normalize_zone_candidate(parse_zone(raw.get("zone","")))
        fallback_zone, map_fallback_raw = map_title_from_window(win)

        # F8 should show the last CONFIRMED live zone first. Raw calibrated OCR
        # is diagnostic only and must not replace a stable zone with garbage.
        if current_zone:
            zone = current_zone
        elif fallback_zone and plausible_zone_title(fallback_zone):
            zone = fallback_zone
        elif raw_zone and plausible_zone_title(raw_zone):
            zone = raw_zone
        else:
            zone = ""

        hover_item, hover_raw = read_hover_item(win)
        # Icon-grid OCR is diagnostic only in 1.1.9.
        items = [(hover_item, 1)] if hover_item else []
        item_text = "\n".join(f"- {n} x{q}" for n,q in items[:8]) if items else "<no item lines parsed>"

        text = (
            f"TARGET RAW:\n{raw.get('target') or '<blank>'}\n\n"
            f"PARSED MOB: {mob or '<none>'}\n"
            f"PARSED CL/LVL: {cl or '<none>'}\n"
            f"LEVEL TARGET: {'YES - enemy/mob' if level_target else 'NO - neutral/object'}\n"
            f"COMBAT BAR SIGNAL (diagnostic): {'YES' if combat_target else 'NO'}\n"
            f"BLUE SHIELD FILL (diagnostic): {combat_metrics['blue_frac']:.1%}\n"
            f"RED HP FILL (diagnostic): {combat_metrics['red_frac']:.1%}\n"
            f"CORPSE SIGNAL: {'YES' if corpse_target else 'NO'}\n"
            f"TARGET TITLE STRIP RAW:\n{target_fallback_raw or '<blank>'}\n"
            f"COMBAT CARD OCR RAW:\n{combat_card_raw or '<blank>'}\n\n"
            f"ZONE RAW:\n{raw.get('zone') or '<blank>'}\n"
            f"MAP TITLE STRIP RAW:\n{map_fallback_raw or '<blank>'}\n\n"
            f"CONFIRMED ZONE: {zone or '<none>'}\n\n"
            f"LOOT SLOT RAW (diagnostic only):\n{raw.get('loot') or '<blank>'}\n\n"
            f"HOVER TOOLTIP RAW:\n{hover_raw or '<hover a loot item first>'}\n\n"
            f"PARSED HOVER ITEM:\n{hover_item or '<none>'}\n\n"
            "For Zone: press M and leave the map open, then run this test. "
            "If a RAW section is blank or wrong, recalibrate that area."
        )
        log(f"OCR TEST target={raw.get('target')!r} mob={mob!r} cl={cl!r} "
            f"zone={raw.get('zone')!r} parsed_zone={zone!r} "
            f"loot_grid={raw.get('loot')!r} hover_raw={hover_raw!r} hover_item={hover_item!r}")
        message_box("EnB Droplist OCR Status / Test", text)
    except Exception as e:
        log(f"OCR status error: {e!r}")
        message_box("OCR Status failed", f"{type(e).__name__}: {e}")


def load_overlay_position():
    try:
        pos = cfg.get("overlay", {})
        return int(pos.get("x", 40)), int(pos.get("y", 40))
    except Exception:
        return 40, 40

def save_overlay_position(x, y):
    try:
        cfg.setdefault("overlay", {})
        cfg["overlay"]["x"] = int(x)
        cfg["overlay"]["y"] = int(y)
        CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"Overlay position save error: {e!r}")

def overlay_thread():
    try:
        root = tk.Tk()
        root.title("EnB Droplist Live")
        root.attributes("-topmost", True)
        try:
            root.attributes("-alpha", float(cfg.get("ui", {}).get("overlay_opacity", 0.72)))
        except Exception:
            root.attributes("-alpha", 0.72)
        root.overrideredirect(True)

        x, y = load_overlay_position()
        root.geometry(f"300x112+{x}+{y}")

        frame = tk.Frame(root, bd=1, relief="solid")
        frame.pack(fill="both", expand=True)

        zone_var = tk.StringVar(value="Zone: Unknown / not read")
        kills_var = tk.StringVar(value="Kills: 0")
        drop_var = tk.StringVar(value="Last drop: —")

        tk.Label(frame, textvariable=zone_var, anchor="w", font=("Segoe UI", 10, "bold")).pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(frame, textvariable=kills_var, anchor="w", font=("Segoe UI", 10)).pack(fill="x", padx=10, pady=2)
        tk.Label(frame, textvariable=drop_var, anchor="w", font=("Segoe UI", 10), wraplength=275, justify="left").pack(fill="x", padx=10, pady=(2, 8))

        drag = {"x": 0, "y": 0}
        visible = {"value": True}

        def drag_start(event):
            drag["x"] = event.x_root - root.winfo_x()
            drag["y"] = event.y_root - root.winfo_y()

        def drag_move(event):
            nx = event.x_root - drag["x"]
            ny = event.y_root - drag["y"]
            root.geometry(f"+{nx}+{ny}")

        def drag_end(_event):
            save_overlay_position(root.winfo_x(), root.winfo_y())

        for widget in (root, frame):
            widget.bind("<ButtonPress-1>", drag_start)
            widget.bind("<B1-Motion>", drag_move)
            widget.bind("<ButtonRelease-1>", drag_end)

        def poll():
            if overlay_stop_requested.is_set():
                save_overlay_position(root.winfo_x(), root.winfo_y())
                root.destroy()
                return

            if overlay_toggle_requested.is_set():
                overlay_toggle_requested.clear()
                visible["value"] = not visible["value"]
                if visible["value"]:
                    root.deiconify()
                    root.attributes("-topmost", True)
                else:
                    root.withdraw()

            zone_var.set(f"Zone: {live_overlay.get('zone') or 'Unknown / not read'}")
            kills_var.set(f"Kills: {int(live_overlay.get('kills', 0))}")
            drop_var.set(f"Last drop: {live_overlay.get('last_drop') or '—'}")
            root.after(250, poll)

        poll()
        root.mainloop()
    except Exception as e:
        log(f"Overlay error: {e!r}")

def toggle_overlay(*_):
    overlay_toggle_requested.set()

def hotkey_thread():
    try:
        user32 = ctypes.windll.user32
        hotkey_id = 0xB17
        vk_f8 = 0x77

        if not user32.RegisterHotKey(None, hotkey_id, 0, vk_f8):
            log("Overlay hotkey F8 could not be registered.")
            return

        msg = wintypes.MSG()
        wm_hotkey = 0x0312

        while running:
            result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if result <= 0:
                break
            if msg.message == wm_hotkey and msg.wParam == hotkey_id:
                overlay_toggle_requested.set()

        user32.UnregisterHotKey(None, hotkey_id)
    except Exception as e:
        log(f"Hotkey error: {e!r}")




def cursor_pos():
    try:
        pt = wintypes.POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return int(pt.x), int(pt.y)
    except Exception:
        return None

def point_in_region(pt, reg):
    if not pt or not reg:
        return False
    try:
        x, y = int(pt[0]), int(pt[1])
        if isinstance(reg, dict):
            left = int(reg["left"])
            top = int(reg["top"])
            right = left + int(reg["width"])
            bottom = top + int(reg["height"])
        else:
            left, top, right, bottom = [int(v) for v in reg]
        return left <= x <= right and top <= y <= bottom
    except Exception as e:
        log(f"point_in_region error: {e!r} pt={pt!r} reg={reg!r}")
        return False

def tooltip_capture_region(win):
    """
    Capture around the user's cursor while it is over the calibrated loot slots.
    EnB draws the item tooltip adjacent to the hovered icon.
    """
    pt = cursor_pos()
    if not pt:
        return None

    x, y = pt
    try:
        # pygetwindow coordinates are screen coordinates.
        sw = ctypes.windll.user32.GetSystemMetrics(0)
        sh = ctypes.windll.user32.GetSystemMetrics(1)
    except Exception:
        sw, sh = 1920, 1080

    left = max(0, x - 35)
    top = max(0, y - 85)
    right = min(sw, x + 330)
    bottom = min(sh, y + 155)
    if right - left < 80 or bottom - top < 50:
        return None
    return (left, top, right, bottom)

def preprocess_tooltip(img):
    """
    Tooltip text is green/bright on dark. grab() returns a cv2/numpy BGR image.
    """
    if img is None:
        return None
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    gray = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX)
    _, bw = cv2.threshold(gray, 105, 255, cv2.THRESH_BINARY)
    return bw

def ocr_tooltip(img):
    try:
        proc = preprocess_tooltip(img)
        return norm(pytesseract.image_to_string(proc, config="--psm 6"))
    except Exception as e:
        log(f"Tooltip OCR error: {e!r}")
        return ""

def parse_tooltip_item(text):
    """
    Extract the item name from an EnB hover tooltip.

    Example:
      Nova Go-Gel
      Structure 100%
      Quality 100%
    => Nova Go-Gel
    """
    raw_lines = [norm(x) for x in str(text or "").replace("\r", "\n").split("\n")]
    lines = [x for x in raw_lines if x]

    reject = re.compile(
        r"^(?:"
        r"structure|quality|durability|condition|range|damage|energy|"
        r"reload|capacity|level|tech\s*level|manufacturer|race|class|"
        r"tradable|stack|value|credits?|required|restriction"
        r")\b",
        re.I,
    )

    for line in lines:
        line = re.sub(r"^[\[\]{}()|:;.,'\"`~_+=*<>!?\\/\-]+\s*", "", line)
        line = re.sub(r"\s+", " ", line).strip()

        if not line or reject.search(line):
            continue
        if re.fullmatch(r"[\d\s%+./:_\-]+", line):
            continue
        if re.search(r"\b(?:100%|0%|structure|quality)\b", line, re.I):
            continue
        # Real names need at least two letters.
        if len(re.findall(r"[A-Za-z]", line)) < 2:
            continue
        # Reject OCR icon garbage with too many symbols.
        alnum = len(re.findall(r"[A-Za-z0-9]", line))
        if alnum / max(len(line), 1) < 0.55:
            continue
        return line[:100]

    return ""


def canonical_item_image_path(item_name):
    item_name = norm(item_name)
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", item_name).strip("_")[:55] or "item"
    suffix = hashlib.sha1(item_name.lower().encode("utf-8")).hexdigest()[:10]
    return ITEM_IMAGE_DIR / f"{safe}_{suffix}.png"

def get_or_save_item_image(win, item_name):
    """
    Save one canonical icon image for a unique item name.
    Subsequent drops reuse the same PNG and do not write another file.
    """
    try:
        path = canonical_item_image_path(item_name)
        if path.exists():
            return str(path)

        pt = cursor_pos()
        if not pt:
            return ""

        x, y = int(pt[0]), int(pt[1])
        half = 38

        try:
            sw = ctypes.windll.user32.GetSystemMetrics(0)
            sh = ctypes.windll.user32.GetSystemMetrics(1)
        except Exception:
            sw, sh = 1920, 1080

        left = max(0, x - half)
        top = max(0, y - half)
        right = min(sw, x + half)
        bottom = min(sh, y + half)

        if right - left < 30 or bottom - top < 30:
            return ""

        icon_img = grab((left, top, right, bottom))
        if icon_img is None or getattr(icon_img, "size", 0) == 0:
            return ""

        tmp = path.with_suffix(".tmp.png")
        cv2.imwrite(str(tmp), icon_img)

        if not path.exists():
            tmp.replace(path)
            log(f"ITEM IMAGE SAVED item={item_name!r} path={str(path)!r}")
        elif tmp.exists():
            tmp.unlink()

        return str(path)
    except Exception as e:
        log(f"Item image save error item={item_name!r}: {e!r}")
        return ""

def read_hover_item(win):
    """
    Only reads a tooltip while the user's own mouse is inside the calibrated
    loot region. No cursor movement/clicking is performed.
    """
    loot_reg = absolute_region(win, "loot")
    pt = cursor_pos()
    if not point_in_region(pt, loot_reg):
        return "", ""

    cap = tooltip_capture_region(win)
    if not cap:
        return "", ""

    img = grab(cap)
    raw = ocr_tooltip(img)
    return parse_tooltip_item(raw), raw

def update_hover_item(win):
    global hover_item_candidate, hover_item_reads, hover_items_seen, hover_item_images

    item, raw = read_hover_item(win)
    if not item:
        hover_item_candidate = ""
        hover_item_reads = 0
        return ""

    if item == hover_item_candidate:
        hover_item_reads += 1
    else:
        hover_item_candidate = item
        hover_item_reads = 1

    # Two agreeing reads suppress one-frame tooltip noise.
    if hover_item_reads < 2:
        return ""

    if item not in hover_items_seen:
        hover_items_seen.append(item)
        log(f"HOVER ITEM: {item!r} raw={raw!r}")

    image_path = get_or_save_item_image(win, item)
    if image_path:
        hover_item_images[item] = image_path

    # Live means live: show the stable item as soon as it is recognised.
    live_overlay["last_drop"] = item
    return item

def reset_loot_session():
    global hover_item_candidate, hover_item_reads, hover_items_seen, hover_item_images
    global loot_session_active, loot_session_logged
    hover_item_candidate = ""
    hover_item_reads = 0
    hover_items_seen = []
    hover_item_images = {}
    loot_session_active = False
    loot_session_logged = False

def loot_region_has_activity(raw_text):
    """
    The slots themselves are image-heavy, so their OCR is not used as item text.
    We only use a loose non-empty signal to tell whether a corpse/loot window is
    probably present. Tooltip recognition is the authoritative item source.
    """
    s = norm(raw_text)
    if not s:
        return False
    # Require at least a small amount of visible OCR signal.
    return len(re.sub(r"\s+", "", s)) >= 2


def map_key_thread():
    """Passively watch the M key without stealing it from Earth & Beyond."""
    global map_zone_capture_until, candidate_zone, candidate_zone_reads
    try:
        user32 = ctypes.windll.user32
        VK_M = 0x4D
        was_down = False

        while running:
            down = bool(user32.GetAsyncKeyState(VK_M) & 0x8000)
            if down and not was_down:
                # Give the game a moment to render the map. Keep sampling for
                # several seconds, so slow map animation/OCR still works.
                candidate_zone=""; candidate_zone_reads=0
                map_zone_capture_until=time.time()+4.0
                log("M key detected: map-zone OCR window opened for 4 seconds; zone vote reset.")
            was_down = down
            time.sleep(0.03)
    except Exception as e:
        log(f"Map key watcher error: {e!r}")

def map_zone_capture_active():
    return time.time() <= map_zone_capture_until


def toggle_pause(icon_obj=None,item=None):
    global auto_enabled
    auto_enabled = not auto_enabled
    notify(
        "EnB Drop Logger",
        "Automatic logging resumed." if auto_enabled else "Automatic logging paused."
    )

def open_folder(*_):
    subprocess.Popen(["explorer", str(BASE)])

def exit_app(icon_obj=None,item=None):
    global running
    running = False
    try:
        icon.stop()
    except Exception:
        pass


def install_update(manifest):
    global running
    try:
        ver = manifest.get("version", "?")
        message_box("EnB Droplist",
                    f"Downloading and installing update {ver}.\n\n"
                    "EnB Droplist will close and restart automatically.")
        auto_updater.launch_install(manifest, BASE, BASE / "run_logger_tray.bat")
        running = False
        try:
            icon.stop()
        except Exception:
            pass
    except Exception as e:
        log(f"Update install error: {e!r}")
        message_box("Update failed", f"{type(e).__name__}: {e}\n\nSee logger_status.txt.")

def choose_update_zip(title):
    root=tk.Tk(); root.withdraw()
    try:
        root.attributes("-topmost",True)
        return filedialog.askopenfilename(title=title,filetypes=[("EnB Droplist update","*.zip"),("ZIP files","*.zip")])
    finally: root.destroy()

def manual_update_from_zip(*_):
    path=choose_update_zip("Select EnB Droplist.zip for manual update")
    if not path: return
    try:
        info=auto_updater.inspect_update_zip(path)
        if not ask_yes_no("Manual Update",f"Valid EnB Droplist ZIP.\n\nVersion: {info['version']}\nSHA-256: {info['sha256']}\n\nInstall now?\n\nDatabase, config, captures and item images are preserved."): return
        auto_updater.launch_local_install(path,BASE,BASE/"run_logger_tray.bat")
        global running; running=False
        try: icon.stop()
        except Exception: pass
    except Exception as e:
        log(f"Manual update error: {e!r}"); message_box("Manual Update failed",str(e),0x10)

def repair_from_zip(*_):
    """
    Online Check / Repair: no file picker.
    Downloads the newest verified release automatically and reinstalls program
    files while update_helper preserves user data.
    """
    def work():
        try:
            log("Check / Repair: downloading latest verified release...")
            manifest = auto_updater.get_latest_manifest(timeout=10)
            ver = str(manifest.get("version", "?"))
            sha = str(manifest.get("sha256", ""))
            source = str(manifest.get("_manifest_source", ""))

            if not ask_yes_no(
                "Check / Repair Files",
                f"Repair EnB Droplist automatically from the latest verified release?\n\n"
                f"Release: {ver}\n"
                f"SHA-256: {sha}\n\n"
                "No folder or ZIP selection is required.\n"
                "Database, config, captures, data and item images are preserved."
            ):
                return

            manifest = auto_updater.launch_online_repair(BASE, BASE / "run_logger_tray.bat")
            log(f"Check / Repair started from {manifest.get('_manifest_source','release source')}")

            global running
            running = False
            try:
                icon.stop()
            except Exception:
                pass

        except Exception as e:
            log(f"Online repair error: {e!r}")
            message_box(
                "Check / Repair failed",
                f"Automatic repair could not download a verified release.\n\n"
                f"{type(e).__name__}: {e}\n\n"
                "You can still use 'Manual Update from ZIP' as an offline fallback.",
                0x10
            )

    threading.Thread(target=work, daemon=True).start()


def check_updates(manual=False):
    def work():
        try:
            manifest = auto_updater.check_for_update()
            if not manifest:
                msg = f"You already have the latest version ({auto_updater.CURRENT_VERSION})."
                log(msg)
                if manual:
                    message_box("EnB Droplist - Update", msg)
                return

            ver = str(manifest.get("version", "?"))
            notes = str(manifest.get("release_notes", "")).strip()
            log(f"Update available: {ver}")

            if not manual:
                notify("EnB Droplist update available",
                       f"Version {ver} is available. Use Check for Update to install.")
                return

            prompt = (f"EnB Droplist {ver} is available.\n\n"
                      f"Current version: {auto_updater.CURRENT_VERSION}\n\n")
            if notes:
                prompt += f"What's new:\n{notes[:600]}\n\n"
            prompt += "Install this update now?"

            if ask_yes_no("EnB Droplist - Update available", prompt):
                install_update(manifest)
            else:
                log(f"User postponed update {ver}.")
                message_box("EnB Droplist", "Update postponed.")
        except Exception as e:
            log(f"Update check error: {e!r}")
            if manual:
                message_box("Update check failed",
                            f"Could not check soulbound.se.\n\n{type(e).__name__}: {e}")
    threading.Thread(target=work, daemon=True).start()

def icon_image():
    im = Image.new("RGB",(64,64),(20,35,55))
    d = ImageDraw.Draw(im)
    d.ellipse((8,8,56,56), outline=(220,230,240), width=4)
    d.text((18,20),"E&B",fill=(255,255,255))
    return im

menu = pystray.Menu(
    pystray.MenuItem("Pause / Resume", toggle_pause),
    pystray.MenuItem("OCR Status / Test", show_ocr_status),
    pystray.MenuItem("Live Overlay (F8)", toggle_overlay),
    pystray.MenuItem("Guided Calibration", guided_calibration),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem(
        "Recalibrate Target",
        lambda *_: single_calibration(
            "target",
            "TARGET: select mob name / CL, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Loot",
        lambda *_: single_calibration(
            "loot",
            "LOOT: select corpse item list, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Map Zone",
        lambda *_: single_calibration(
            "zone",
            "MAP ZONE: press M first, then select the zone/sector name, ENTER to save"
        )
    ),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem("Check for Update", lambda *_: check_updates(True)),
    pystray.MenuItem("Manual Update from ZIP", manual_update_from_zip),
    pystray.MenuItem("Check / Repair Files (Automatic)", repair_from_zip),
    pystray.MenuItem("Open Logger Folder", open_folder),
    pystray.MenuItem("Exit", exit_app)
)

icon = pystray.Icon(
    "EnBDopList",
    icon_image(),
    "EnB Droplist",
    menu
)

log("Tray logger 1.1.33 started.")
threading.Thread(target=map_key_thread, daemon=True).start()
threading.Thread(target=overlay_thread, daemon=True).start()
threading.Thread(target=hotkey_thread, daemon=True).start()
threading.Thread(target=lambda: (time.sleep(1), show_update_complete_if_needed()), daemon=True).start()
threading.Thread(target=worker, daemon=True).start()

def delayed_update_check():
    time.sleep(5)
    check_updates(False)
threading.Thread(target=delayed_update_check, daemon=True).start()

if not calibration_complete():
    def delayed_first_run():
        time.sleep(2)
        notify("EnB Drop Logger", "First run: starting one-time calibration.")
        guided_calibration()
    threading.Thread(target=delayed_first_run, daemon=True).start()

icon.run()
overlay_stop_requested.set()
log("Tray logger 1.1.33 stopped.")

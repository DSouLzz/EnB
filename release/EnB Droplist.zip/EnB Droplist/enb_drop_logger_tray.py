"""
EnB Droplist — Background Tray Edition v2

Fixes:
- Calibration runs in a separate process, so OpenCV selection cannot freeze the tray app.
- Successful loot captures show a tray notification.
"""
from __future__ import annotations
import json, re, time, hashlib, threading, subprocess, sys
from datetime import datetime
from pathlib import Path

import cv2
import mss
import numpy as np
import pytesseract
import pygetwindow as gw
from openpyxl import load_workbook
from PIL import Image, ImageDraw
import pystray
import auto_updater

BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config.json"
LOG_PATH = BASE / "logger_status.txt"
CAPTURE_DIR = BASE / "captures"
CAPTURE_DIR.mkdir(exist_ok=True)

with CFG_PATH.open("r", encoding="utf-8") as f:
    cfg = json.load(f)

pytesseract.pytesseract.tesseract_cmd = cfg["ocr"]["tesseract_cmd"]

running = True
auto_enabled = bool(cfg["behavior"].get("automatic", True))
calibrating = False
state_lock = threading.Lock()

current_target = ""
current_target_cl = ""
current_zone = ""
last_target_seen_at = 0.0

candidate_target = ""
candidate_target_cl = ""
candidate_target_reads = 0
candidate_zone = ""
candidate_zone_reads = 0
candidate_loot_text = ""
candidate_loot_reads = 0
last_logged_loot_hash = ""
last_log_time = 0.0

def reload_config():
    global cfg
    try:
        with CFG_PATH.open("r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as e:
        log(f"Config reload error: {e!r}")

def log(msg):
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(f"[{stamp}] {msg}\n")
    except Exception:
        pass

def notify(title, msg):
    try:
        icon.notify(msg, title)
    except Exception as e:
        log(f"Notification error: {e!r}")
    log(f"{title}: {msg}")

def find_window():
    needle = cfg["window_title_contains"].lower()
    wins = [
        w for w in gw.getAllWindows()
        if needle in (w.title or "").lower() and w.width > 0 and w.height > 0
    ]
    return wins[0] if wins else None

def grab(region):
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

def absolute_region(win, name):
    r = cfg["regions"].get(name)
    if not r:
        return None
    return {
        "left": int(win.left + r["left"]),
        "top": int(win.top + r["top"]),
        "width": max(1, int(r["width"])),
        "height": max(1, int(r["height"]))
    }

def prep(img, scale=2):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 31, 9
    )

def ocr(img, psm):
    txt = pytesseract.image_to_string(prep(img), config=f"--psm {psm}")
    return "\n".join(x.strip() for x in txt.splitlines() if x.strip())

def norm(s):
    return re.sub(r"\s+", " ", s or "").strip(" |[]-:")

def parse_target(text):
    clean = norm(text)
    if not clean:
        return "", ""
    cl = ""
    m = re.search(r"\b(?:CL|Combat\s*Level|Combat)\s*[:\-]?\s*(\d{1,3})\b", clean, re.I)
    if m:
        cl = m.group(1)
        clean = norm(clean[:m.start()] + " " + clean[m.end():])
    clean = re.sub(r"\b(?:Target|Hull|Shield)\b\s*:?", "", clean, flags=re.I)
    clean = norm(clean)
    return (clean[:80], cl) if 2 <= len(clean) <= 80 else ("", cl)

def parse_zone(text):
    clean = norm(text)
    clean = re.sub(r"^(?:Sector|Zone|Location)\s*[:\-]\s*", "", clean, flags=re.I)
    return clean if 2 <= len(clean) <= 80 else ""

def parse_loot(text):
    rows, seen = [], set()
    for raw in text.splitlines():
        line = norm(raw)
        if len(line) < 2:
            continue
        if re.search(
            r"\b(?:loot|cargo|close|take all|inventory|credits?|capacity|free space)\b",
            line, re.I
        ):
            continue
        qty, item = 1, line
        m = re.match(r"^(\d+)\s*[xX]\s+(.+)$", line)
        if m:
            qty, item = int(m.group(1)), m.group(2)
        else:
            m = re.match(r"^(.+?)\s+[xX]\s*(\d+)$", line)
            if m:
                item, qty = m.group(1), int(m.group(2))
        item = norm(item)
        if item and item.lower() not in seen:
            seen.add(item.lower())
            rows.append((item[:120], qty))
    return rows

def calibration_complete():
    return all(cfg["regions"].get(x) for x in ("target","loot","zone"))

def run_calibration_step(name, prompt):
    global calibrating
    with state_lock:
        if calibrating:
            notify("EnB Drop Logger", "Calibration is already running.")
            return False
        calibrating = True

    try:
        notify("Calibration", f"Select the {name} area in Earth & Beyond.")
        python_exe = sys.executable

        # When the tray runs under pythonw.exe, launch helper with python.exe
        # so OpenCV's window has a normal GUI-capable child process.
        if python_exe.lower().endswith("pythonw.exe"):
            candidate = python_exe[:-5] + ".exe"
            if Path(candidate).exists():
                python_exe = candidate

        result = subprocess.run(
            [python_exe, str(BASE / "calibrate_helper.py"), name, prompt],
            cwd=str(BASE),
            timeout=300,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )

        if result.returncode == 0:
            reload_config()
            notify("Calibration saved", f"{name.title()} area saved.")
            return True
        elif result.returncode == 3:
            notify("Calibration failed", "Earth & Beyond window was not found.")
        elif result.returncode == 4:
            notify("Calibration cancelled", f"{name.title()} selection was cancelled.")
        else:
            notify("Calibration failed", f"{name.title()} helper returned code {result.returncode}.")
        return False

    except subprocess.TimeoutExpired:
        notify("Calibration cancelled", "Calibration timed out after 5 minutes.")
        return False
    except Exception as e:
        log(f"Calibration helper error: {e!r}")
        notify("Calibration failed", "See logger_status.txt for details.")
        return False
    finally:
        with state_lock:
            calibrating = False

def guided_calibration(*_):
    def work():
        if not run_calibration_step("target", "1/3 TARGET: select mob name / CL, ENTER to save"):
            return
        if not run_calibration_step("loot", "2/3 LOOT: select corpse item list, ENTER to save"):
            return
        if not run_calibration_step("zone", "3/3 ZONE: select sector/zone name, ENTER to save"):
            return
        notify("EnB Drop Logger", "Calibration complete. Automatic logging resumed.")
    threading.Thread(target=work, daemon=True).start()

def single_calibration(name, prompt):
    threading.Thread(
        target=lambda: run_calibration_step(name, prompt),
        daemon=True
    ).start()

def save_capture(images, mob):
    if not cfg["behavior"].get("save_capture_on_log", True):
        return ""
    imgs = [images.get("zone"), images.get("target"), images.get("loot")]
    imgs = [x for x in imgs if x is not None]
    if not imgs:
        return ""
    h = max(x.shape[0] for x in imgs)
    w = sum(x.shape[1] for x in imgs)
    canvas = np.zeros((h,w,3), dtype=np.uint8)
    pos = 0
    for im in imgs:
        canvas[:im.shape[0], pos:pos+im.shape[1]] = im
        pos += im.shape[1]
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe = re.sub(r"[^A-Za-z0-9_-]+","_",mob or "unknown")[:40]
    p = CAPTURE_DIR / f"{stamp}_{safe}.png"
    cv2.imwrite(str(p), canvas)
    return str(p)

def rebuild_summary(wb):
    kd, agg = {}, {}
    for row in wb["Kills"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        if mob:
            kd[mob] = kd.get(mob, 0) + 1

    for row in wb["Drops"].iter_rows(min_row=3, values_only=True):
        mob = str(row[2] or "").strip()
        item = str(row[4] or "").strip()
        try:
            qty = int(row[5] or 1)
        except Exception:
            qty = 1
        if mob and item:
            rec = agg.setdefault((mob,item), [0,0])
            rec[0] += 1
            rec[1] += qty

    # Replace the generated summary area cleanly. The starter workbook has
    # merged instruction rows below row 2; writing to those MergedCell objects
    # raises "value is read-only" in openpyxl. Unmerge/remove that area first.
    for merged in list(ws.merged_cells.ranges):
        if merged.min_row >= 3:
            ws.unmerge_cells(str(merged))
    if ws.max_row >= 3:
        ws.delete_rows(3, ws.max_row - 2)

    for (mob,item),(events,qty) in sorted(agg.items()):
        kills = kd.get(mob,0)
        ws.append([
            mob, item, events, kills,
            (events/kills if kills else 0),
            qty, "Observed sample"
        ])
        ws.cell(ws.max_row,5).number_format = "0.0%"

def append_rows(kill, drops):
    path = (BASE / cfg["excel_file"]).resolve()
    if not path.exists():
        notify("EnB Drop Logger", "Database XLSX is missing.")
        return False

    try:
        wb = load_workbook(path)
        wb["Kills"].append(kill)
        for r in drops:
            wb["Drops"].append(r)
        rebuild_summary(wb)
        wb.save(path)
        wb.close()
        return True
    except PermissionError:
        notify("Database is open", "Close the XLSX in OpenOffice Calc while logging.")
        return False
    except Exception as e:
        log(f"Workbook error: {e!r}")
        return False

def update_target(text):
    global candidate_target,candidate_target_cl,candidate_target_reads
    global current_target,current_target_cl,last_target_seen_at

    mob, cl = parse_target(text)
    if not mob:
        return

    if mob == candidate_target:
        candidate_target_reads += 1
        if cl:
            candidate_target_cl = cl
    else:
        candidate_target = mob
        candidate_target_cl = cl
        candidate_target_reads = 1

    if candidate_target_reads >= int(cfg["behavior"].get("stable_target_reads",2)):
        if mob != current_target:
            log(f"Target changed: {current_target!r} -> {mob!r}")
            current_target = mob
        if candidate_target_cl:
            current_target_cl = candidate_target_cl
        last_target_seen_at = time.time()

def update_zone(text):
    global candidate_zone,candidate_zone_reads,current_zone

    zone = parse_zone(text)
    if not zone:
        return

    if zone == candidate_zone:
        candidate_zone_reads += 1
    else:
        candidate_zone = zone
        candidate_zone_reads = 1

    if (
        candidate_zone_reads >= int(cfg["behavior"].get("stable_zone_reads",2))
        and zone != current_zone
    ):
        log(f"Zone changed: {current_zone!r} -> {zone!r}")
        current_zone = zone

def tick():
    global candidate_loot_text,candidate_loot_reads,last_logged_loot_hash,last_log_time

    win = find_window()
    if not win:
        return

    images, texts = {}, {}
    for name,key in (
        ("target","target_psm"),
        ("loot","loot_psm"),
        ("zone","zone_psm")
    ):
        reg = absolute_region(win,name)
        if not reg:
            return
        images[name] = grab(reg)
        texts[name] = ocr(images[name], cfg["ocr"][key])

    update_zone(texts["zone"])
    update_target(texts["target"])

    items = parse_loot(texts["loot"])
    if not items:
        candidate_loot_text = ""
        candidate_loot_reads = 0
        return

    canonical = "\n".join(f"{i}|{q}" for i,q in items)

    if canonical == candidate_loot_text:
        candidate_loot_reads += 1
    else:
        candidate_loot_text = canonical
        candidate_loot_reads = 1

    if candidate_loot_reads < int(cfg["behavior"].get("loot_stable_reads",2)):
        return

    sig = hashlib.sha1(canonical.lower().encode("utf-8")).hexdigest()
    if sig == last_logged_loot_hash:
        return

    now = time.time()
    if now - last_log_time < float(cfg["behavior"].get("loot_event_cooldown_seconds",2.0)):
        return

    if not current_target:
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    shot = save_capture(images,current_target)
    kill = [
        ts,current_zone,current_target,current_target_cl,
        len(items),shot,"Background automatic OCR"
    ]
    drops = [
        [
            ts,current_zone,current_target,current_target_cl,
            item,qty,"Review","automatic",
            "OCR; screenshot saved for verification"
        ]
        for item,qty in items
    ]

    if append_rows(kill,drops):
        last_logged_loot_hash = sig
        last_log_time = now
        log(f"Logged {current_zone} / {current_target}: {items}")

        # New in v2: visible confirmation during gameplay.
        total_qty = sum(qty for _, qty in items)
        unique_items = len(items)
        notify(
            f"Logged: {current_target}",
            f"{unique_items} item type{'s' if unique_items != 1 else ''}, "
            f"{total_qty} total item{'s' if total_qty != 1 else ''}"
        )

def worker():
    global running
    while running:
        try:
            with state_lock:
                busy = calibrating
            if auto_enabled and not busy and calibration_complete():
                tick()
        except Exception as e:
            log(f"Scan error: {e!r}")
        time.sleep(float(cfg.get("scan_interval_seconds",0.6)))

def toggle_pause(icon_obj=None,item=None):
    global auto_enabled
    auto_enabled = not auto_enabled
    notify(
        "EnB Drop Logger",
        "Automatic logging resumed." if auto_enabled else "Automatic logging paused."
    )

def open_folder(*_):
    subprocess.Popen(["explorer", str(BASE)])

def exit_app(icon_obj=None,item=None):
    global running
    running = False
    try:
        icon.stop()
    except Exception:
        pass


def install_update(manifest):
    global running
    try:
        ver = manifest.get("version", "?")
        notify("EnB Droplist", f"Installing update {ver}. The logger will restart.")
        auto_updater.launch_install(
            manifest,
            BASE,
            BASE / "run_logger_tray.bat"
        )
        running = False
        try:
            icon.stop()
        except Exception:
            pass
    except Exception as e:
        log(f"Update install error: {e!r}")
        notify("Update failed", "See logger_status.txt for details.")

def check_updates(manual=False):
    def work():
        try:
            if manual:
                notify("EnB Droplist", f"Checking for updates... Current version: {auto_updater.CURRENT_VERSION}")

            manifest = auto_updater.check_for_update()

            if manifest:
                ver = str(manifest.get("version", "?"))
                notes = str(manifest.get("release_notes", "")).strip()
                log(f"Update available: {ver}")

                if manual:
                    msg = f"Update {ver} is available."
                    if notes:
                        msg += f" {notes[:160]}"
                    notify("Update available", msg)
                else:
                    notify("EnB Droplist", f"Update {ver} found. Installing now.")

                install_update(manifest)
            else:
                msg = f"You already have the latest version ({auto_updater.CURRENT_VERSION})."
                log(msg)
                if manual:
                    notify("EnB Droplist", msg)

        except Exception as e:
            log(f"Update check error: {e!r}")
            if manual:
                notify("Update check failed", f"Could not check soulbound.se. {type(e).__name__}: {e}")

    threading.Thread(target=work, daemon=True).start()

def icon_image():
    im = Image.new("RGB",(64,64),(20,35,55))
    d = ImageDraw.Draw(im)
    d.ellipse((8,8,56,56), outline=(220,230,240), width=4)
    d.text((18,20),"E&B",fill=(255,255,255))
    return im

menu = pystray.Menu(
    pystray.MenuItem("Pause / Resume", toggle_pause),
    pystray.MenuItem("Guided Calibration", guided_calibration),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem(
        "Recalibrate Target",
        lambda *_: single_calibration(
            "target",
            "TARGET: select mob name / CL, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Loot",
        lambda *_: single_calibration(
            "loot",
            "LOOT: select corpse item list, ENTER to save"
        )
    ),
    pystray.MenuItem(
        "Recalibrate Zone",
        lambda *_: single_calibration(
            "zone",
            "ZONE: select sector/zone name, ENTER to save"
        )
    ),
    pystray.Menu.SEPARATOR,
    pystray.MenuItem("Check for Update", lambda *_: check_updates(True)),
    pystray.MenuItem("Open Logger Folder", open_folder),
    pystray.MenuItem("Exit", exit_app)
)

icon = pystray.Icon(
    "EnBDopList",
    icon_image(),
    "EnB Droplist",
    menu
)

log("Tray logger v2 started.")
threading.Thread(target=worker, daemon=True).start()

def delayed_update_check():
    time.sleep(5)
    check_updates(False)
threading.Thread(target=delayed_update_check, daemon=True).start()

if not calibration_complete():
    def delayed_first_run():
        time.sleep(2)
        notify("EnB Drop Logger", "First run: starting one-time calibration.")
        guided_calibration()
    threading.Thread(target=delayed_first_run, daemon=True).start()

icon.run()
log("Tray logger v2 stopped.")

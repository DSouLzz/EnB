from __future__ import annotations
import json, hashlib, os, shutil, subprocess, sys, tempfile, urllib.request, ssl
import certifi
from pathlib import Path

APP_NAME = "EnB Droplist"
CURRENT_VERSION = "1.1.32"
MANIFEST_URL = "https://soulbound.se/EnB/Download/version.json"
FALLBACK_MANIFEST_URL = "https://raw.githubusercontent.com/DSouLzz/EnB/main/release/version.json"
FALLBACK_ZIP_URL = "https://raw.githubusercontent.com/DSouLzz/EnB/main/release/EnB%20Droplist.zip"

def _ssl_context():
    # Use certifi's current Mozilla CA bundle instead of depending on the
    # Python installation's bundled/default trust store. Verification stays ON.
    return ssl.create_default_context(cafile=certifi.where())

def _vtuple(v):
    parts = []
    for x in str(v).strip().split("."):
        try:
            parts.append(int(x))
        except Exception:
            parts.append(0)
    return tuple(parts)

def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().lower()

def _read_manifest_url(url, timeout=8):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": f"{APP_NAME}/{CURRENT_VERSION}", "Cache-Control": "no-cache"}
    )
    with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as r:
        return json.loads(r.read().decode("utf-8"))

def get_latest_manifest(timeout=8):
    """
    Prefer soulbound.se, but automatically fall back to GitHub if the site is
    unreachable or returns an older manifest.
    """
    manifests = []
    errors = []
    for url in (MANIFEST_URL, FALLBACK_MANIFEST_URL):
        try:
            data = _read_manifest_url(url, timeout=timeout)
            data["_manifest_source"] = url
            manifests.append(data)
        except Exception as e:
            errors.append(f"{url}: {type(e).__name__}: {e}")

    if not manifests:
        raise RuntimeError("Could not read update manifest from soulbound.se or GitHub. " + " | ".join(errors))

    manifests.sort(key=lambda m: _vtuple(str(m.get("version", "0.0.0"))), reverse=True)
    return manifests[0]

def check_for_update(timeout=8):
    data = get_latest_manifest(timeout=timeout)
    remote = str(data.get("version", "0.0.0"))
    return data if _vtuple(remote) > _vtuple(CURRENT_VERSION) else None

def _download_file(url, dest, timeout=60):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": f"{APP_NAME}/{CURRENT_VERSION}", "Cache-Control": "no-cache"}
    )
    with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)

def download_and_stage(manifest, install_dir):
    expected = str(manifest.get("sha256", "")).lower().strip()
    primary = manifest.get("download_url") or "https://soulbound.se/EnB/Download/EnB%20Droplist.zip"

    # Always have GitHub raw as a second source. Do not duplicate if manifest already points there.
    urls = [primary]
    if FALLBACK_ZIP_URL not in urls:
        urls.append(FALLBACK_ZIP_URL)

    temp_dir = Path(tempfile.mkdtemp(prefix="enb_drop_update_"))
    zip_path = temp_dir / "EnB Droplist.zip"

    failures = []
    for url in urls:
        try:
            if zip_path.exists():
                zip_path.unlink()
            _download_file(url, zip_path)

            if not zip_path.exists() or zip_path.stat().st_size < 1000:
                raise RuntimeError("downloaded file is missing or unexpectedly small")

            actual = _sha256(zip_path)
            if expected and actual != expected:
                raise RuntimeError(
                    f"SHA-256 mismatch from {url}: expected {expected}, got {actual}"
                )

            # Also verify it is a healthy EnB package, not just matching bytes.
            inspect_update_zip(zip_path)

            helper_src = Path(install_dir) / "update_helper.py"
            if not helper_src.is_file():
                raise RuntimeError(f"Updater helper missing from installation: {helper_src}")

            helper_copy = temp_dir / "update_helper.py"
            shutil.copy2(helper_src, helper_copy)
            return zip_path, helper_copy

        except Exception as e:
            failures.append(f"{url}: {type(e).__name__}: {e}")

    raise RuntimeError(
        "Update download failed from both soulbound.se and GitHub.\n\n" +
        "\n".join(failures)
    )

def download_repair_package(install_dir):
    """
    Download the newest release even when the installed version is already current.
    Used by Check / Repair Files, so the user never needs to browse for a ZIP.
    """
    manifest = get_latest_manifest(timeout=10)
    zip_path, helper = download_and_stage(manifest, install_dir)
    return manifest, zip_path, helper

def launch_online_repair(install_dir, restart_bat):
    manifest, zip_path, helper = download_repair_package(install_dir)
    _launch_helper(helper, zip_path, install_dir, restart_bat, manifest.get("version", CURRENT_VERSION))
    return manifest

def inspect_update_zip(zip_path):
    import zipfile
    zip_path=Path(zip_path)
    if not zip_path.is_file(): raise RuntimeError("Selected update ZIP does not exist.")
    if not zipfile.is_zipfile(zip_path): raise RuntimeError("Selected file is not a valid ZIP archive.")
    with zipfile.ZipFile(zip_path,"r") as z:
        bad=z.testzip()
        if bad: raise RuntimeError(f"ZIP integrity check failed at: {bad}")
        names=[n.replace("\\","/") for n in z.namelist() if not n.endswith("/")]
        req=("enb_drop_logger_tray.py","auto_updater.py","update_helper.py")
        missing=[r for r in req if not any(n==r or n.endswith("/"+r) for n in names)]
        if missing: raise RuntimeError("Not an EnB Droplist update ZIP; missing: "+", ".join(missing))
        version="manual"
        av=[n for n in names if n=="app_version.json" or n.endswith("/app_version.json")]
        if av:
            try: version=str(json.loads(z.read(av[0]).decode("utf-8")).get("version") or version)
            except Exception: pass
    return {"version":version,"sha256":_sha256(zip_path)}

def _launch_helper(helper, zip_path, install_dir, restart_bat, version):
    python_exe=sys.executable
    if python_exe.lower().endswith("pythonw.exe"):
        candidate=python_exe[:-5]+".exe"
        if Path(candidate).exists(): python_exe=candidate
    subprocess.Popen([python_exe,str(helper),str(os.getpid()),str(zip_path),str(Path(install_dir).resolve()),str(Path(restart_bat).resolve()),str(version)],cwd=str(Path(install_dir).resolve()),creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))

def stage_local_zip(zip_path, install_dir):
    info=inspect_update_zip(zip_path)
    td=Path(tempfile.mkdtemp(prefix="enb_drop_manual_update_"))
    staged=td/"EnB Droplist.zip"; shutil.copy2(Path(zip_path),staged)
    helper=td/"update_helper.py"; shutil.copy2(Path(install_dir)/"update_helper.py",helper)
    return staged,helper,info

def launch_local_install(zip_path, install_dir, restart_bat):
    staged,helper,info=stage_local_zip(zip_path,install_dir)
    _launch_helper(helper,staged,install_dir,restart_bat,info["version"])
    return info

def launch_repair(zip_path, install_dir, restart_bat):
    return launch_local_install(zip_path,install_dir,restart_bat)

def launch_install(manifest, install_dir, restart_bat):
    zip_path, helper = download_and_stage(manifest, install_dir)
    _launch_helper(helper, zip_path, install_dir, restart_bat, manifest.get("version", "?"))

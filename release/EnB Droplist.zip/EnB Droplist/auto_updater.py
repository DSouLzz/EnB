from __future__ import annotations
import json, hashlib, os, shutil, subprocess, sys, tempfile, urllib.request, ssl
import certifi
from pathlib import Path

APP_NAME = "EnB Droplist"
CURRENT_VERSION = "1.1.9"
MANIFEST_URL = "https://soulbound.se/EnB/Download/version.json"

def _ssl_context():
    # Use certifi's current Mozilla CA bundle instead of depending on the
    # Python installation's bundled/default trust store. Verification stays ON.
    return ssl.create_default_context(cafile=certifi.where())

def _vtuple(v):
    parts = []
    for x in str(v).strip().split("."):
        try:
            parts.append(int(x))
        except Exception:
            parts.append(0)
    return tuple(parts)

def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().lower()

def check_for_update(timeout=8):
    req = urllib.request.Request(
        MANIFEST_URL,
        headers={"User-Agent": f"{APP_NAME}/{CURRENT_VERSION}"}
    )
    with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as r:
        data = json.loads(r.read().decode("utf-8"))
    remote = str(data.get("version", "0.0.0"))
    return data if _vtuple(remote) > _vtuple(CURRENT_VERSION) else None

def download_and_stage(manifest, install_dir):
    url = manifest.get("download_url") or "https://soulbound.se/EnB/Download/EnB%20Droplist.zip"
    expected = str(manifest.get("sha256", "")).lower().strip()

    temp_dir = Path(tempfile.mkdtemp(prefix="enb_dop_update_"))
    zip_path = temp_dir / "EnB Droplist.zip"

    req = urllib.request.Request(
        url,
        headers={"User-Agent": f"{APP_NAME}/{CURRENT_VERSION}"}
    )
    with urllib.request.urlopen(req, timeout=60, context=_ssl_context()) as r, open(zip_path, "wb") as f:
        shutil.copyfileobj(r, f)

    if expected:
        actual = _sha256(zip_path)
        if actual != expected:
            raise RuntimeError("Downloaded update failed SHA-256 verification.")

    # Copy updater helper outside install dir so it survives replacement.
    helper_src = Path(install_dir) / "update_helper.py"
    helper_copy = temp_dir / "update_helper.py"
    shutil.copy2(helper_src, helper_copy)
    return zip_path, helper_copy

def launch_install(manifest, install_dir, restart_bat):
    zip_path, helper = download_and_stage(manifest, install_dir)

    python_exe = sys.executable
    if python_exe.lower().endswith("pythonw.exe"):
        candidate = python_exe[:-5] + ".exe"
        if Path(candidate).exists():
            python_exe = candidate

    subprocess.Popen(
        [
            python_exe,
            str(helper),
            str(os.getpid()),
            str(zip_path),
            str(Path(install_dir).resolve()),
            str(Path(restart_bat).resolve()),
            str(manifest.get("version", "?"))
        ],
        cwd=str(Path(install_dir).resolve()),
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
    )
